import { useCallback, useEffect, useLayoutEffect, useRef, useState } from "react";

const easeOutCubic = (t: number) => 1 - Math.pow(1 - t, 3);

/** Tweens an array of numbers toward a target whenever the target changes. */
export function useTweenArray(target: number[], duration = 650): number[] {
  const [value, setValue] = useState<number[]>(() => target.map(() => 0));
  const currentRef = useRef<number[]>(target.map(() => 0));
  const frameRef = useRef<number | null>(null);
  const fromRef = useRef<number[]>(target.map(() => 0));

  useEffect(() => {
    const len = target.length;
    const from = new Array(len);
    const start = currentRef.current;
    for (let i = 0; i < len; i++) {
      const prev = i < start.length ? start[i] : 0;
      const next = Number.isFinite(target[i]) ? target[i] : 0;
      // if the previous value is wildly out of scale (filter switch), still animate
      from[i] = Number.isFinite(prev) ? prev : 0;
      if (Math.abs(next - prev) > Math.max(1e-6, Math.abs(next) * 40)) from[i] = 0;
    }
    fromRef.current = from;
    const t0 = performance.now();

    if (frameRef.current) cancelAnimationFrame(frameRef.current);

    const tick = (now: number) => {
      const t = Math.min(1, (now - t0) / duration);
      const e = easeOutCubic(t);
      const out = new Array(len);
      for (let i = 0; i < len; i++) {
        out[i] = from[i] + (target[i] - from[i]) * e;
      }
      currentRef.current = out;
      setValue(out);
      if (t < 1) frameRef.current = requestAnimationFrame(tick);
    };
    frameRef.current = requestAnimationFrame(tick);
    return () => {
      if (frameRef.current) cancelAnimationFrame(frameRef.current);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [JSON.stringify(target), duration]);

  return value;
}

/** Tweens a single scalar. */
export function useTweenValue(target: number, duration = 700): number {
  const arr = useTweenArray([target], duration);
  return arr[0] ?? 0;
}

/** Observe an element's pixel size. */
export function useMeasure<T extends HTMLElement>() {
  const ref = useRef<T | null>(null);
  const [size, setSize] = useState({ width: 0, height: 0 });

  useLayoutEffect(() => {
    const el = ref.current;
    if (!el) return;
    const update = () => {
      setSize({ width: el.clientWidth, height: el.clientHeight });
    };
    update();
    const ro = new ResizeObserver(update);
    ro.observe(el);
    return () => ro.disconnect();
  }, []);

  return [ref, size] as const;
}

/** Persisted dark / light theme. */
export function useTheme() {
  const [dark, setDark] = useState<boolean>(() => {
    if (typeof window === "undefined") return true;
    const stored = window.localStorage.getItem("flowgrid-theme");
    if (stored) return stored === "dark";
    return window.matchMedia?.("(prefers-color-scheme: dark)").matches ?? true;
  });

  useEffect(() => {
    const root = document.documentElement;
    root.classList.toggle("dark", dark);
    root.style.colorScheme = dark ? "dark" : "light";
    window.localStorage.setItem("flowgrid-theme", dark ? "dark" : "light");
  }, [dark]);

  const toggle = useCallback(() => setDark((d) => !d), []);
  return { dark, toggle };
}

/** Animated count-up for KPI numbers. */
export function useCountUp(target: number, duration = 800): number {
  return useTweenValue(target, duration);
}
