/* ------------------------------------------------------------------
   FlowGrid synthetic traffic telemetry
   Deterministic, seeded generator producing ~200 days of per-segment
   daily records (with 24h resolution) for an AI traffic network.
-------------------------------------------------------------------*/

export type VehicleKey = "cars" | "trucks" | "transit" | "emergency" | "micro";

export interface VehicleTypeMeta {
  key: VehicleKey;
  label: string;
  short: string;
  color: string;
  share: number;
}

export const VEHICLE_TYPES: VehicleTypeMeta[] = [
  { key: "cars", label: "Private cars", short: "Cars", color: "#6366f1", share: 0.61 },
  { key: "transit", label: "Public transit", short: "Transit", color: "#22d3ee", share: 0.16 },
  { key: "trucks", label: "Freight & logistics", short: "Freight", color: "#f59e0b", share: 0.13 },
  { key: "micro", label: "Micro-mobility", short: "Micro", color: "#34d399", share: 0.07 },
  { key: "emergency", label: "Emergency response", short: "Emergency", color: "#fb7185", share: 0.03 },
];

export interface Segment {
  id: string;
  name: string;
  short: string;
  district: string;
  kind: "Freeway" | "Arterial" | "Grid" | "Tunnel";
  lanes: number;
  lengthKm: number;
  baseVolume: number;
  freeFlow: number;
  capacity: number;
  bias: number;
  eventProne: boolean;
}

export const SEGMENTS: Segment[] = [
  {
    id: "crr", name: "Central Ring Expressway", short: "Central Ring", district: "Downtown",
    kind: "Freeway", lanes: 6, lengthKm: 18.4, baseVolume: 152000, freeFlow: 100, capacity: 168000, bias: 1.02, eventProne: false,
  },
  {
    id: "hbf", name: "Harbor Freeway I-95", short: "Harbor Fwy", district: "Waterfront",
    kind: "Freeway", lanes: 5, lengthKm: 24.1, baseVolume: 126500, freeFlow: 110, capacity: 145000, bias: 0.96, eventProne: false,
  },
  {
    id: "ngt", name: "Northgate Arterial", short: "Northgate", district: "North District",
    kind: "Arterial", lanes: 4, lengthKm: 9.6, baseVolume: 61200, freeFlow: 70, capacity: 68000, bias: 1.08, eventProne: false,
  },
  {
    id: "apc", name: "Airport Connector", short: "Airport Link", district: "Airport",
    kind: "Freeway", lanes: 4, lengthKm: 14.2, baseVolume: 74800, freeFlow: 100, capacity: 86000, bias: 0.88, eventProne: false,
  },
  {
    id: "otg", name: "Old Town Signal Grid", short: "Old Town Grid", district: "Old Town",
    kind: "Grid", lanes: 2, lengthKm: 6.3, baseVolume: 38400, freeFlow: 50, capacity: 41000, bias: 1.18, eventProne: false,
  },
  {
    id: "rse", name: "Riverside Expressway", short: "Riverside", district: "University",
    kind: "Freeway", lanes: 4, lengthKm: 16.8, baseVolume: 98600, freeFlow: 100, capacity: 108000, bias: 1.04, eventProne: false,
  },
  {
    id: "ind", name: "Industrial Spine Freight Route", short: "Industrial Spine", district: "Industrial",
    kind: "Arterial", lanes: 3, lengthKm: 12.5, baseVolume: 52300, freeFlow: 80, capacity: 56000, bias: 0.94, eventProne: false,
  },
  {
    id: "std", name: "Stadium District Loop", short: "Stadium Loop", district: "Stadium",
    kind: "Grid", lanes: 3, lengthKm: 5.1, baseVolume: 44100, freeFlow: 60, capacity: 47000, bias: 1.12, eventProne: true,
  },
];

export const DISTRICTS = Array.from(new Set(SEGMENTS.map((s) => s.district)));

export const SEGMENT_MAP: Record<string, Segment> = Object.fromEntries(
  SEGMENTS.map((s) => [s.id, s]),
);

export interface DayRecord {
  dayIndex: number;
  dateISO: string;
  ts: number;
  segmentId: string;
  vehicles: number;
  avgSpeed: number;
  travelTime: number;
  baselineTravelTime: number;
  congestion: number;
  interventions: number;
  incidents: number;
  resolved: number;
  co2SavedKg: number;
  accuracy: number;
  mix: Record<VehicleKey, number>;
  hVolume: number[];
  hWaitBefore: number[];
  hWaitAfter: number[];
  hSpeed: number[];
}

/* ---------------------------- helpers ---------------------------- */

function mulberry32(seed: number) {
  let a = seed >>> 0;
  return function () {
    a = (a + 0x6d2b79f5) >>> 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

const rand = mulberry32(0x51f3a7);
const gauss = () => {
  let u = 0;
  let v = 0;
  while (u === 0) u = rand();
  while (v === 0) v = rand();
  return Math.sqrt(-2 * Math.log(u)) * Math.cos(2 * Math.PI * v);
};
const clamp = (v: number, lo: number, hi: number) => Math.min(hi, Math.max(lo, v));

const toISO = (d: Date) =>
  `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;

export const DAYS = 210;

export interface DayMeta {
  dayIndex: number;
  dateISO: string;
  ts: number;
  label: string;      // Feb 14
  weekday: number;    // 0 Sun .. 6 Sat
  weekend: boolean;
}

const HOURLY_WEIGHTS = [
  0.19, 0.12, 0.09, 0.08, 0.11, 0.24, 0.46, 0.79, 1.06, 0.94, 0.77, 0.82,
  0.86, 0.84, 0.82, 0.93, 1.12, 1.18, 1.0, 0.81, 0.66, 0.51, 0.37, 0.26,
];
const H_WEIGHT_SUM = HOURLY_WEIGHTS.reduce((a, b) => a + b, 0);

const HOURLY_LOAD = [
  0.2, 0.15, 0.12, 0.11, 0.14, 0.27, 0.5, 0.76, 0.95, 0.83, 0.66, 0.61,
  0.63, 0.62, 0.66, 0.78, 0.98, 1.0, 0.86, 0.71, 0.59, 0.49, 0.38, 0.28,
];

export const HOUR_LABELS = Array.from({ length: 24 }, (_, h) =>
  `${String(h).padStart(2, "0")}:00`,
);

function buildDayMeta(): DayMeta[] {
  const out: DayMeta[] = [];
  const today = new Date();
  today.setHours(12, 0, 0, 0);
  for (let i = DAYS - 1; i >= 0; i--) {
    const d = new Date(today);
    d.setDate(today.getDate() - i);
    const weekday = d.getDay();
    out.push({
      dayIndex: DAYS - 1 - i,
      dateISO: toISO(d),
      ts: d.getTime(),
      label: d.toLocaleDateString("en-US", { month: "short", day: "numeric" }),
      weekday,
      weekend: weekday === 0 || weekday === 6,
    });
  }
  return out;
}

export const DAY_META = buildDayMeta();
const DAY_INDEX = new Map(DAY_META.map((d) => [d.dateISO, d]));

/* -------------------------- generation -------------------------- */

function buildRecords(): DayRecord[] {
  const records: DayRecord[] = [];
  const segmentStates = new Map<string, number>();

  for (const day of DAY_META) {
    // network-wide exogenous shocks, per day
    const rain = rand() < 0.11;
    const heatwave = rand() < 0.05;
    const seasonal = 1 + 0.055 * Math.sin((day.dayIndex / 365) * Math.PI * 2 + 1.1);

    for (const seg of SEGMENTS) {
      const st = segmentStates.get(seg.id) ?? 0.4;
      const next = clamp(st * 0.72 + 0.28 * (0.35 + 0.3 * gauss()), -0.4, 1.1);
      segmentStates.set(seg.id, next);

      const weekdayFactor = day.weekend
        ? seg.kind === "Grid" ? 0.62 : 0.83
        : 1 - 0.05 * Math.abs(3.5 - day.weekday) / 3.5;

      const eventBoost = seg.eventProne && rand() < 0.14 ? 1.32 + rand() * 0.2 : 1;
      const holiday = day.weekday === 1 && rand() < 0.05 ? 0.88 : 1;
      const growth = 1 + 0.00042 * day.dayIndex;

      const demand =
        seg.baseVolume *
        weekdayFactor *
        seasonal *
        growth *
        (rain ? 0.95 : 1) *
        (heatwave ? 0.97 : 1) *
        eventBoost *
        holiday *
        (1 + 0.055 * gauss() + 0.05 * next);

      const loadPressure = clamp(demand / seg.capacity, 0.35, 1.35);
      const weatherDrag = rain ? 0.9 : heatwave ? 0.95 : 1;
      const aiMaturity = 0.72 + 0.28 * clamp(day.dayIndex / (DAYS - 1), 0, 1);

      // ---- hourly decomposition
      const hVolume = new Array<number>(24);
      const hWaitBefore = new Array<number>(24);
      const hWaitAfter = new Array<number>(24);
      const hSpeed = new Array<number>(24);
      let speedAcc = 0;
      let improvementAcc = 0;

      for (let h = 0; h < 24; h++) {
        const w = HOURLY_WEIGHTS[h] / H_WEIGHT_SUM;
        const vol = demand * w * (1 + 0.03 * gauss());
        const load = clamp(
          HOURLY_LOAD[h] * loadPressure * seg.bias * weatherDrag * (1 + 0.05 * gauss()),
          0.08,
          1.6,
        );
        const cong = clamp(18 + load * 54 + 6 * gauss(), 4, 99);
        const speed = clamp(
          seg.freeFlow * (1 - 0.68 * Math.pow(cong / 100, 0.85)) * (1 + 0.02 * gauss()),
          8,
          seg.freeFlow,
        );
        const waitBefore = clamp(14 + Math.pow(cong / 100, 1.35) * 112 + 4 * gauss(), 8, 190);
        const improvement = clamp(
          (0.1 + 0.34 * (cong / 100)) * aiMaturity * (0.85 + 0.3 * rand()) * (rain ? 1.08 : 1),
          0.04,
          0.52,
        );

        hVolume[h] = Math.max(0, vol);
        hWaitBefore[h] = waitBefore;
        hWaitAfter[h] = waitBefore * (1 - improvement);
        hSpeed[h] = speed;
        speedAcc += speed * w;
        improvementAcc += improvement * w;
      }

      const avgSpeed = speedAcc * weatherDrag;
      const travelTime = (seg.lengthKm / avgSpeed) * 60;
      const baselineSpeed = avgSpeed * (1 - improvementAcc);
      const baselineTravelTime = (seg.lengthKm / baselineSpeed) * 60;
      const congestion = clamp(
        HOURLY_LOAD.reduce((a, b) => a + b, 0) / 24 * 100 * loadPressure * seg.bias * 0.92 + 6 * gauss(),
        5,
        99,
      );

      const incidentsRaw =
        (0.35 + (congestion / 100) * 3.4 + (rain ? 1.5 : 0)) * (seg.lengthKm / 12) * (1 + 0.5 * gauss());
      const incidents = Math.max(0, Math.round(incidentsRaw));
      const accuracy = clamp(0.886 + 0.055 * aiMaturity + 0.012 * gauss() - (rain ? 0.01 : 0), 0.8, 0.995);
      const resolved = Math.min(incidents, Math.round(incidents * clamp(0.7 + accuracy * 0.28 + 0.05 * gauss(), 0.5, 1)));
      const interventions = Math.round(
        (demand / 1200) * (0.45 + congestion / 130) * (0.6 + 0.7 * aiMaturity) * (1 + 0.18 * gauss()),
      );
      const co2SavedKg = Math.max(
        0,
        demand * (0.014 + 0.052 * improvementAcc) * (seg.kind === "Freeway" ? 1.15 : 0.9) * (1 + 0.08 * gauss()),
      );

      // ---- fleet mix with segment personality
      const truckBias = seg.district === "Industrial" || seg.district === "Airport" ? 1.9 : seg.kind === "Freeway" ? 1.15 : 0.55;
      const transitBias = seg.kind === "Grid" || seg.district === "University" ? 1.5 : 0.9;
      const microBias = seg.kind === "Grid" || seg.district === "University" ? 2.1 : 0.6;
      const emergencyBias = seg.kind === "Freeway" ? 1.4 : 0.85;
      const rawMix: Record<VehicleKey, number> = {
        cars: 1,
        trucks: VEHICLE_TYPES[2].share * truckBias,
        transit: VEHICLE_TYPES[1].share * transitBias,
        micro: VEHICLE_TYPES[3].share * microBias,
        emergency: VEHICLE_TYPES[4].share * emergencyBias,
      };
      const rawSum = rawMix.cars + rawMix.trucks + rawMix.transit + rawMix.micro + rawMix.emergency;
      const mix = {
        cars: Math.round((demand * rawMix.cars) / rawSum),
        trucks: Math.round((demand * rawMix.trucks) / rawSum),
        transit: Math.round((demand * rawMix.transit) / rawSum),
        micro: Math.round((demand * rawMix.micro) / rawSum),
        emergency: Math.round((demand * rawMix.emergency) / rawSum),
      };

      records.push({
        dayIndex: day.dayIndex,
        dateISO: day.dateISO,
        ts: day.ts,
        segmentId: seg.id,
        vehicles: Math.round(demand),
        avgSpeed,
        travelTime,
        baselineTravelTime,
        congestion,
        interventions,
        incidents,
        resolved,
        co2SavedKg,
        accuracy,
        mix,
        hVolume,
        hWaitBefore,
        hWaitAfter,
        hSpeed,
      });
    }
  }
  return records;
}

export const RECORDS = buildRecords();

/* -------------------------- aggregation -------------------------- */

export interface Filters {
  startISO: string;
  endISO: string;
  segmentIds: string[];
  vehicle: "all" | VehicleKey;
}

export interface Summary {
  days: number;
  vehicles: number;
  mix: Record<VehicleKey, number>;
  avgSpeed: number;
  travelTime: number;
  baselineTravelTime: number;
  congestion: number;
  interventions: number;
  incidents: number;
  resolved: number;
  resolutionRate: number;
  co2SavedKg: number;
  accuracy: number;
  vehicleHoursSaved: number;
  delaySavedSec: number;
  volumeFactor: number;
}

const EMPTY_MIX: Record<VehicleKey, number> = { cars: 0, trucks: 0, transit: 0, micro: 0, emergency: 0 };

export function filterRecords(records: DayRecord[], f: Pick<Filters, "startISO" | "endISO" | "segmentIds">) {
  const segs = new Set(f.segmentIds);
  return records.filter(
    (r) => r.dateISO >= f.startISO && r.dateISO <= f.endISO && segs.has(r.segmentId),
  );
}

export function summarize(records: DayRecord[], vehicle: "all" | VehicleKey = "all"): Summary {
  if (records.length === 0) {
    return {
      days: 0, vehicles: 0, mix: { ...EMPTY_MIX }, avgSpeed: 0, travelTime: 0,
      baselineTravelTime: 0, congestion: 0, interventions: 0, incidents: 0, resolved: 0,
      resolutionRate: 0, co2SavedKg: 0, accuracy: 0, vehicleHoursSaved: 0, delaySavedSec: 0,
      volumeFactor: 0,
    };
  }

  const mix = { ...EMPTY_MIX };
  let vehicles = 0;
  let speedW = 0;
  let congW = 0;
  let ttW = 0;
  let bttW = 0;
  let interventions = 0;
  let incidents = 0;
  let resolved = 0;
  let co2 = 0;
  let accW = 0;
  let savedMin = 0;
  const days = new Set<string>();

  for (const r of records) {
    const factor =
      vehicle === "all" ? 1 : r.mix[vehicle] / Math.max(1, r.vehicles);
    const vol = r.vehicles * factor;
    vehicles += vol;
    speedW += r.avgSpeed * vol;
    congW += r.congestion * vol;
    ttW += r.travelTime * vol;
    bttW += r.baselineTravelTime * vol;
    interventions += r.interventions * factor;
    incidents += r.incidents * factor;
    resolved += r.resolved * factor;
    co2 += r.co2SavedKg * factor;
    accW += r.accuracy * vol;
    savedMin += vol * (r.baselineTravelTime - r.travelTime);
    days.add(r.dateISO);
    if (vehicle === "all") {
      mix.cars += r.mix.cars;
      mix.trucks += r.mix.trucks;
      mix.transit += r.mix.transit;
      mix.micro += r.mix.micro;
      mix.emergency += r.mix.emergency;
    } else {
      mix[vehicle] += r.mix[vehicle] * 1;
    }
  }

  return {
    days: days.size,
    vehicles,
    mix,
    avgSpeed: vehicles ? speedW / vehicles : 0,
    travelTime: vehicles ? ttW / vehicles : 0,
    baselineTravelTime: vehicles ? bttW / vehicles : 0,
    congestion: vehicles ? congW / vehicles : 0,
    interventions,
    incidents,
    resolved,
    resolutionRate: incidents ? resolved / incidents : 0,
    co2SavedKg: co2,
    accuracy: vehicles ? accW / vehicles : 0,
    vehicleHoursSaved: savedMin / 60,
    delaySavedSec: vehicles ? ((bttW - ttW) / vehicles) * 60 : 0,
    volumeFactor: vehicle === "all" ? 1 : 1,
  };
}

export interface DayPoint {
  dateISO: string;
  label: string;
  vehicles: number;
  avgSpeed: number;
  congestion: number;
  interventions: number;
  incidents: number;
  co2SavedKg: number;
  vehicleHoursSaved: number;
  accuracy: number;
  delaySec: number;
}

export function dailySeries(records: DayRecord[], vehicle: "all" | VehicleKey = "all"): DayPoint[] {
  const buckets = new Map<string, DayRecord[]>();
  for (const r of records) {
    const arr = buckets.get(r.dateISO);
    if (arr) arr.push(r);
    else buckets.set(r.dateISO, [r]);
  }
  return Array.from(buckets.entries())
    .sort((a, b) => (a[0] < b[0] ? -1 : 1))
    .map(([dateISO, rows]) => {
      const s = summarize(rows, vehicle);
      const meta = DAY_INDEX.get(dateISO);
      return {
        dateISO,
        label: meta?.label ?? dateISO.slice(5),
        vehicles: s.vehicles,
        avgSpeed: s.avgSpeed,
        congestion: s.congestion,
        interventions: s.interventions,
        incidents: s.incidents,
        co2SavedKg: s.co2SavedKg,
        vehicleHoursSaved: s.vehicleHoursSaved,
        accuracy: s.accuracy,
        delaySec: s.delaySavedSec,
      };
    });
}

export interface HourlySeries {
  volume: number[];
  waitBefore: number[];
  waitAfter: number[];
  speed: number[];
  congestion: number[];
}

export function hourlySeries(records: DayRecord[], vehicle: "all" | VehicleKey = "all"): HourlySeries {
  const volume = new Array(24).fill(0);
  const wb = new Array(24).fill(0);
  const wa = new Array(24).fill(0);
  const sp = new Array(24).fill(0);
  const wVol = new Array(24).fill(0);
  const cong = new Array(24).fill(0);

  for (const r of records) {
    const factor = vehicle === "all" ? 1 : r.mix[vehicle] / Math.max(1, r.vehicles);
    for (let h = 0; h < 24; h++) {
      const v = r.hVolume[h] * factor;
      volume[h] += v;
      cong[h] += (HOURLY_LOAD[h] * 100 * (r.congestion / 60)) * v;
      sp[h] += r.hSpeed[h] * v;
      wb[h] += r.hWaitBefore[h] * v;
      wa[h] += r.hWaitAfter[h] * v;
      wVol[h] += v;
    }
  }

  return {
    volume: volume.map((v) => v / 1000),
    waitBefore: wb.map((v, h) => (wVol[h] ? v / wVol[h] : 0)),
    waitAfter: wa.map((v, h) => (wVol[h] ? v / wVol[h] : 0)),
    speed: sp.map((v, h) => (wVol[h] ? v / wVol[h] : 0)),
    congestion: cong.map((v, h) => (wVol[h] ? v / wVol[h] : 0)),
  };
}

export interface CorridorRow {
  id: string;
  name: string;
  short: string;
  district: string;
  kind: Segment["kind"];
  lanes: number;
  lengthKm: number;
  vehicles: number;
  avgSpeed: number;
  travelTime: number;
  baselineTravelTime: number;
  congestion: number;
  interventions: number;
  incidents: number;
  resolutionRate: number;
  co2SavedKg: number;
  vehicleHoursSaved: number;
  delaySavedSec: number;
  accuracy: number;
  volumeTrend: number;
  speedTrend: number;
  congestionTrend: number;
  status: "Optimized" | "Watch" | "Congested" | "Critical";
}

function statusOf(congestion: number, speed: number, freeFlow: number): CorridorRow["status"] {
  const ratio = freeFlow ? speed / freeFlow : 1;
  if (congestion > 78 || ratio < 0.38) return "Critical";
  if (congestion > 62 || ratio < 0.52) return "Congested";
  if (congestion > 46) return "Watch";
  return "Optimized";
}

export function corridorRows(
  current: DayRecord[],
  previous: DayRecord[],
  vehicle: "all" | VehicleKey = "all",
): CorridorRow[] {
  const byCur = new Map<string, DayRecord[]>();
  const byPrev = new Map<string, DayRecord[]>();
  for (const r of current) {
    const a = byCur.get(r.segmentId);
    if (a) a.push(r);
    else byCur.set(r.segmentId, [r]);
  }
  for (const r of previous) {
    const a = byPrev.get(r.segmentId);
    if (a) a.push(r);
    else byPrev.set(r.segmentId, [r]);
  }

  const rows: CorridorRow[] = [];
  for (const seg of SEGMENTS) {
    const cur = byCur.get(seg.id);
    if (!cur || cur.length === 0) continue;
    const s = summarize(cur, vehicle);
    const p = summarize(byPrev.get(seg.id) ?? [], vehicle);
    rows.push({
      id: seg.id,
      name: seg.name,
      short: seg.short,
      district: seg.district,
      kind: seg.kind,
      lanes: seg.lanes,
      lengthKm: seg.lengthKm,
      vehicles: s.vehicles,
      avgSpeed: s.avgSpeed,
      travelTime: s.travelTime,
      baselineTravelTime: s.baselineTravelTime,
      congestion: s.congestion,
      interventions: s.interventions,
      incidents: s.incidents,
      resolutionRate: s.resolutionRate,
      co2SavedKg: s.co2SavedKg,
      vehicleHoursSaved: s.vehicleHoursSaved,
      delaySavedSec: s.delaySavedSec,
      accuracy: s.accuracy,
      volumeTrend: pct(p.vehicles, s.vehicles),
      speedTrend: pct(p.avgSpeed, s.avgSpeed),
      congestionTrend: pct(p.congestion, s.congestion),
      status: statusOf(s.congestion, s.avgSpeed, seg.freeFlow),
    });
  }
  return rows;
}

/** % change of previous → current (guarded) */
export function pct(prev: number, cur: number): number {
  if (!prev || !isFinite(prev)) return 0;
  return ((cur - prev) / prev) * 100;
}

/** previous window of identical length, ending the day before `startISO` */
export function previousWindow(startISO: string, endISO: string) {
  const s = DAY_INDEX.get(startISO);
  const e = DAY_INDEX.get(endISO);
  if (!s || !e) return { startISO, endISO };
  const len = e.dayIndex - s.dayIndex;
  const ps = Math.max(0, s.dayIndex - len - 1);
  const pe = Math.max(0, s.dayIndex - 2);
  return { startISO: DAY_META[ps].dateISO, endISO: DAY_META[pe].dateISO };
}

export const RANGES = [
  { key: "7d", label: "7D", days: 7 },
  { key: "14d", label: "14D", days: 14 },
  { key: "30d", label: "30D", days: 30 },
  { key: "90d", label: "90D", days: 90 },
] as const;

export type RangeKey = (typeof RANGES)[number]["key"];

export function rangeToDates(days: number): { startISO: string; endISO: string } {
  const end = DAY_META[DAY_META.length - 1];
  const startIdx = Math.max(0, DAY_META.length - days);
  return { startISO: DAY_META[startIdx].dateISO, endISO: end.dateISO };
}

export function dayBounds() {
  return { min: DAY_META[0].dateISO, max: DAY_META[DAY_META.length - 1].dateISO };
}

export function activeDays(startISO: string, endISO: string): DayMeta[] {
  return DAY_META.filter((d) => d.dateISO >= startISO && d.dateISO <= endISO);
}

/* -------------------------- formatting -------------------------- */

export const fmtInt = (n: number) =>
  Math.round(n).toLocaleString("en-US", { maximumFractionDigits: 0 });

export function fmtCompact(n: number, digits = 1): string {
  const abs = Math.abs(n);
  if (abs >= 1e9) return `${(n / 1e9).toFixed(digits)}B`;
  if (abs >= 1e6) return `${(n / 1e6).toFixed(digits)}M`;
  if (abs >= 1e3) return `${(n / 1e3).toFixed(abs >= 1e4 ? 0 : digits)}k`;
  return `${Math.round(n)}`;
}

export const fmtPct = (n: number, digits = 1) => `${n >= 0 ? "" : "-"}${Math.abs(n).toFixed(digits)}%`;

export const fmtPct0 = (n: number, digits = 0) => `${(n * 100).toFixed(digits)}%`;

export function fmtDateRange(startISO: string, endISO: string) {
  const f = (iso: string) =>
    new Date(`${iso}T12:00:00`).toLocaleDateString("en-US", {
      month: "short",
      day: "numeric",
      year: "numeric",
    });
  return `${f(startISO)} – ${f(endISO)}`;
}

export const STATUS_STYLES: Record<CorridorRow["status"], string> = {
  Optimized:
    "bg-emerald-50 text-emerald-700 border-emerald-200 dark:bg-emerald-500/10 dark:text-emerald-300 dark:border-emerald-500/25",
  Watch:
    "bg-amber-50 text-amber-700 border-amber-200 dark:bg-amber-500/10 dark:text-amber-300 dark:border-amber-500/25",
  Congested:
    "bg-orange-50 text-orange-700 border-orange-200 dark:bg-orange-500/10 dark:text-orange-300 dark:border-orange-500/25",
  Critical:
    "bg-rose-50 text-rose-700 border-rose-200 dark:bg-rose-500/10 dark:text-rose-300 dark:border-rose-500/25",
};

export const STATUS_DOT: Record<CorridorRow["status"], string> = {
  Optimized: "bg-emerald-500",
  Watch: "bg-amber-500",
  Congested: "bg-orange-500",
  Critical: "bg-rose-500",
};

export { DAY_INDEX };
