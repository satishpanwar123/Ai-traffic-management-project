import { SEGMENTS } from "./trafficData";

/* ------------------------------------------------------------------
   Signalised intersection catalogue + traffic-engineering models
-------------------------------------------------------------------*/

export type Approach = "N" | "E" | "S" | "W";
export const APPROACHES: Approach[] = ["N", "E", "S", "W"];

export const APPROACH_LABEL: Record<Approach, string> = {
  N: "Northbound",
  E: "Eastbound",
  S: "Southbound",
  W: "Westbound",
};

export const APPROACH_SHORT: Record<Approach, string> = {
  N: "N",
  E: "E",
  S: "S",
  W: "W",
};

export type SignalMode = "adaptive" | "fixed" | "manual" | "flash" | "preempt";

export const MODE_META: Record<SignalMode, { label: string; hint: string; color: string }> = {
  adaptive: { label: "Adaptive AI", hint: "Controller retimes itself every cycle", color: "#10b981" },
  fixed: { label: "Fixed plan", hint: "Runs the stored timing plan unchanged", color: "#6366f1" },
  manual: { label: "Manual", hint: "Operator-controlled splits, no auto drift", color: "#f59e0b" },
  preempt: { label: "Emergency Pre-empt", hint: "Opticom priority hold for first responders", color: "#fb7185" },
  flash: { label: "Flash", hint: "All-red flash — incident or hardware fault", color: "#f43f5e" },
};

export interface SignalDef {
  id: string;
  name: string;
  corridorId: string;
  corridor: string;
  district: string;
  chainMeters: number; // distance along corridor for green-wave offsets
  approach: Record<Approach, { lanes: number; share: number }>;
  plan: { cycle: number; splits: Record<Approach, number>; offset: number };
  mode: SignalMode;
  hardware: number;
  transitPriority: boolean;
  pedPhase: boolean;
  group: string;
  baselineActions: number;
}

const STREETS: Record<string, [string, string][]> = {
  crr: [["Kingsway Blvd", "Harbor Ave"], ["Central Pkwy", "Union Sq"]],
  hbf: [["Dockside Rd", "Pier 9"], ["Quay St", "Lighthouse Ln"]],
  ngt: [["Northgate Way", "Alder St"], ["Summit Dr", "Birch Ave"]],
  apc: [["Terminal Access", "Cargo Row"], ["Skyport Blvd", "Rental Car Way"]],
  otg: [["Cobblestone St", "Old Mill Ln"], ["Cathedral Sq", "Weaver's Row"]],
  rse: [["University Ave", "River Rd"], ["College Dr", "Ferry Landing"]],
  ind: [["Foundry St", "Silo Rd"], ["Depot Ave", "Container Way"]],
  std: [["Arena Way", "Tailgate St"], ["Champions Blvd", "Turnstile Rd"]],
};

function mulberry32(seed: number) {
  let a = seed >>> 0;
  return function () {
    a = (a + 0x6d2b79f5) >>> 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

function buildSignals(): SignalDef[] {
  const rnd = mulberry32(0xa17c31);
  const out: SignalDef[] = [];
  let chain = 0;

  for (const seg of SEGMENTS) {
    const pairs = STREETS[seg.id] ?? [["Junction A", "Street 1"], ["Junction B", "Street 2"]];
    pairs.forEach(([a, b], idx) => {
      chain += 420 + Math.round(rnd() * 680);
      const lanesFor = (i: number) => Math.max(1, Math.min(3, Math.round(seg.lanes / 2) + (i === 0 ? 1 : 0) - (rnd() > 0.7 ? 1 : 0)));
      const rawShare = APPROACHES.map(() => 0.6 + rnd() * 0.8);
      const shareSum = rawShare.reduce((x, y) => x + y, 0);
      const splits = APPROACHES.map(() => 18 + rnd() * 14);
      const splitSum = splits.reduce((x, y) => x + y, 0);
      const splitMap = {} as Record<Approach, number>;
      APPROACHES.forEach((ap, i) => {
        splitMap[ap] = Math.round((splits[i] / splitSum) * 1000) / 10;
      });
      const approach = {} as Record<Approach, { lanes: number; share: number }>;
      APPROACHES.forEach((ap, i) => {
        approach[ap] = { lanes: lanesFor(i), share: rawShare[i] / shareSum };
      });

      out.push({
        id: `${seg.id}-s${idx + 1}`,
        name: `${a} & ${b}`,
        corridorId: seg.id,
        corridor: seg.short,
        district: seg.district,
        chainMeters: chain,
        approach,
        plan: {
          cycle: Math.round(70 + rnd() * 45),
          splits: splitMap,
          offset: Math.round(rnd() * 100),
        },
        mode: rnd() > 0.22 ? "adaptive" : rnd() > 0.45 ? "fixed" : "manual",
        hardware: Math.round((0.82 + rnd() * 0.18) * 100) / 100,
        transitPriority: rnd() > 0.4,
        pedPhase: rnd() > 0.15,
        group: `${seg.short} green wave`,
        baselineActions: Math.round(40 + rnd() * 160),
      });
    });
  }
  return out;
}

export const SIGNALS: SignalDef[] = buildSignals();
export const SIGNAL_MAP: Record<string, SignalDef> = Object.fromEntries(
  SIGNALS.map((s) => [s.id, s]),
);

/* --------------------------- flow model --------------------------- */

export const SATURATION_FLOW = 1900; // veh/h of green per lane
export const LOST_PER_PHASE = 6; // s (start-up lost time + all-red)

export interface Plan {
  cycle: number;
  splits: Record<Approach, number>;
  offset: number;
}

export function greenSeconds(plan: Plan, ap: Approach): number {
  const total = APPROACHES.reduce((a, k) => a + Math.max(1, plan.splits[k]), 0);
  const usable = Math.max(20, plan.cycle - APPROACHES.length * LOST_PER_PHASE);
  return (Math.max(1, plan.splits[ap]) / total) * usable;
}

export function lostTime() {
  return APPROACHES.length * LOST_PER_PHASE;
}

/** capacity in veh/h for one approach */
export function approachCapacity(lanes: number, g: number, cycle: number) {
  return SATURATION_FLOW * lanes * Math.max(0.02, g / cycle);
}

/** HCM/Webster-style control delay in s/veh */
export function approachDelay(
  v: number,
  cap: number,
  g: number,
  cycle: number,
  analysisH = 0.25,
): number {
  const ratio = Math.max(0.02, g / cycle);
  const x = Math.min(1.6, cap > 0 ? v / cap : 2);
  const d1 = (cycle * Math.pow(1 - ratio, 2)) / (2 * (1 - ratio * Math.min(x, 0.99)));
  const d2 =
    900 *
    analysisH *
    (x - 1 + Math.sqrt(Math.max(0, (x - 1) * (x - 1) + 4 * x / Math.max(1, cap * analysisH))));
  return Math.max(4, Math.min(220, d1 + Math.max(0, d2)));
}

export interface ApproachState {
  ap: Approach;
  demand: number;   // veh/h
  lanes: number;
  green: number;    // s
  capacity: number; // veh/h
  delay: number;    // s/veh
  queue: number;    // veh
  degree: number;   // v/c
}

export function evaluatePlan(
  def: SignalDef,
  plan: Plan,
  demandVeh: number,
): { per: ApproachState[]; avgDelay: number; los: LosKey; throughput: number; degree: number } {
  const per = APPROACHES.map((ap) => {
    const lanes = def.approach[ap].lanes;
    const share = def.approach[ap].share;
    const demand = demandVeh * share;
    const g = greenSeconds(plan, ap);
    const capacity = approachCapacity(lanes, g, plan.cycle);
    const delay = approachDelay(demand, capacity, g, plan.cycle);
    return {
      ap,
      demand,
      lanes,
      green: g,
      capacity,
      delay,
      queue: Math.max(0, (demand / 3600) * Math.min(delay, plan.cycle)),
      degree: capacity ? demand / capacity : 2,
    };
  });
  const totalDemand = per.reduce((a, p) => a + p.demand, 0) || 1;
  const avgDelay = per.reduce((a, p) => a + p.delay * p.demand, 0) / totalDemand;
  const throughput = per.reduce((a, p) => a + Math.min(p.demand, p.capacity), 0);
  return {
    per,
    avgDelay,
    los: losOf(avgDelay),
    throughput,
    degree: per.reduce((a, p) => Math.max(a, p.degree), 0),
  };
}

export type LosKey = "A" | "B" | "C" | "D" | "E" | "F";

export function losOf(delay: number): LosKey {
  if (delay < 10) return "A";
  if (delay < 20) return "B";
  if (delay < 35) return "C";
  if (delay < 55) return "D";
  if (delay < 80) return "E";
  return "F";
}

export const LOS_TONE: Record<LosKey, string> = {
  A: "bg-emerald-500/15 text-emerald-600 dark:text-emerald-300 border-emerald-500/30",
  B: "bg-emerald-500/10 text-emerald-600 dark:text-emerald-300 border-emerald-500/25",
  C: "bg-lime-500/10 text-lime-600 dark:text-lime-300 border-lime-500/25",
  D: "bg-amber-500/10 text-amber-600 dark:text-amber-300 border-amber-500/25",
  E: "bg-orange-500/10 text-orange-600 dark:text-orange-300 border-orange-500/25",
  F: "bg-rose-500/10 text-rose-600 dark:text-rose-300 border-rose-500/25",
};

export const PHASE_TONE: Record<Approach, string> = {
  N: "#22c55e",
  E: "#f59e0b",
  S: "#22c55e",
  W: "#f59e0b",
};

/* ------------------------- recommendation ------------------------- */

export interface Recommendation extends Plan {
  ySum: number;
  expectedDelay: number;
  note: string;
}

/** Webster optimal cycle + proportional green split. */
export function recommend(def: SignalDef, demandVeh: number, progressionSpeedKph = 52): Recommendation {
  const y = APPROACHES.map((ap) => {
    const d = demandVeh * def.approach[ap].share;
    return d / (SATURATION_FLOW * def.approach[ap].lanes);
  });
  const ySum = Math.min(0.94, y.reduce((a, b) => a + b, 0));
  const L = lostTime();
  const raw = ySum >= 0.9 ? 150 : (1.5 * L + 5) / (1 - ySum);
  const cycle = Math.round(Math.max(45, Math.min(135, raw)));
  const splits = {} as Record<Approach, number>;
  APPROACHES.forEach((ap, i) => {
    splits[ap] = Math.round((y[i] / (ySum || 1)) * 1000) / 10;
  });
  const offset = Math.round((def.chainMeters / (progressionSpeedKph / 3.6)) % cycle);
  const rec: Plan = { cycle, splits, offset };
  const ev = evaluatePlan(def, rec, demandVeh);
  const cur = evaluatePlan(def, def.plan, demandVeh);
  const note =
    ev.avgDelay < cur.avgDelay - 1
      ? `Rebalance green to demand (Y=${ySum.toFixed(2)}) — Webster cycle ${cycle}s`
      : ev.avgDelay > cur.avgDelay + 1
        ? `Current plan already near-optimal (Y=${ySum.toFixed(2)}) — keep plan`
        : `Plan is at parity (Y=${ySum.toFixed(2)}) — minor retune only`;
  return { ...rec, ySum, expectedDelay: ev.avgDelay, note };
}

/** phase timeline for the live controller */
export function phaseAt(plan: Plan, mode: SignalMode, t: number): { phase: Approach | null; remaining: number } {
  if (mode === "flash") return { phase: null, remaining: 0 };
  if (mode === "preempt") return { phase: null, remaining: 0 };
  const cycle = plan.cycle;
  const seq = APPROACHES.map((ap) => ({ ap, g: greenSeconds(plan, ap) }));
  let t0 = ((t + plan.offset) % cycle + cycle) % cycle;
  for (const s of seq) {
    if (t0 < s.g) return { phase: s.ap, remaining: s.g - t0 };
    t0 -= s.g;
  }
  return { phase: null, remaining: 0 };
}
