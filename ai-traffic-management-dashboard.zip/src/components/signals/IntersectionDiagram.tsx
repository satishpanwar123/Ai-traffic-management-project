import { APPROACHES, APPROACH_SHORT, PHASE_TONE, type Approach, type SignalDef } from "../../data/signals";

interface Props {
  def: SignalDef;
  phase: Approach | null;
  remaining: number;
  queues: Record<Approach, number>;
  splits: Record<Approach, number>;
  flashing: boolean;
  forced: Approach | null;
  emergencyApproach?: Approach | null;
  emergencyUnit?: string;
}

/** Schematic four-way intersection with live phase lights and queue rendering. */
export function IntersectionDiagram({
  def,
  phase,
  remaining,
  queues,
  splits,
  flashing,
  forced,
  emergencyApproach = null,
  emergencyUnit,
}: Props) {
  const W = 420;
  const H = 300;
  const roadHalf = 34;

  const arm = (ap: Approach) => {
    const cars = Math.min(8, Math.round((queues[ap] ?? 0) / 3));
    const isEVP = emergencyApproach === ap;
    const active = phase === ap || (forced === ap && phase !== null) || isEVP;
    const color = flashing ? "#f43f5e" : isEVP ? "#38bdf8" : active ? "#22c55e" : "#ef4444";
    const carsE: React.ReactNode[] = [];
    for (let i = 0; i < cars; i++) {
      if (ap === "N") {
        carsE.push(
          <rect key={i} x={W / 2 - 22} y={H / 2 + roadHalf + 22 + i * 17} width={17} height={12} rx={3.5}
            fill={active ? "#34d399" : "#64748b"} opacity={0.95} />,
        );
      } else if (ap === "S") {
        carsE.push(
          <rect key={i} x={W / 2 + 6} y={H / 2 - roadHalf - 34 - i * 17} width={17} height={12} rx={3.5}
            fill={active ? "#34d399" : "#64748b"} opacity={0.95} />,
        );
      } else if (ap === "E") {
        carsE.push(
          <rect key={i} x={W / 2 - roadHalf - 30 - i * 19} y={H / 2 + 6} width={13} height={17} rx={3.5}
            fill={active ? "#34d399" : "#64748b"} opacity={0.95} />,
        );
      } else {
        carsE.push(
          <rect key={i} x={W / 2 + roadHalf + 18 + i * 19} y={H / 2 - 23} width={13} height={17} rx={3.5}
            fill={active ? "#34d399" : "#64748b"} opacity={0.95} />,
        );
      }
    }
    return { color, cars, carsE, active };
  };

  const arms = Object.fromEntries(APPROACHES.map((ap) => [ap, arm(ap)])) as Record<
    Approach,
    ReturnType<typeof arm>
  >;

  const labelPos: Record<Approach, { x: number; y: number }> = {
    N: { x: W / 2 + roadHalf + 6, y: H - 16 },
    S: { x: W / 2 - roadHalf - 6, y: 18 },
    E: { x: 26, y: H / 2 + roadHalf + 16 },
    W: { x: W - 26, y: H / 2 - roadHalf - 12 },
  };

  return (
    <svg viewBox={`0 0 ${W} ${H}`} className="w-full touch-none select-none" style={{ maxHeight: 320 }}>
      <defs>
        <linearGradient id="roadGrad" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor="#94a3b8" stopOpacity="0.35" />
          <stop offset="100%" stopColor="#64748b" stopOpacity="0.25" />
        </linearGradient>
      </defs>

      {/* blocks / scenery */}
      {[
        [8, 8, W / 2 - roadHalf - 20, H / 2 - roadHalf - 20],
        [W / 2 + roadHalf + 12, 8, W / 2 - roadHalf - 20, H / 2 - roadHalf - 20],
        [8, H / 2 + roadHalf + 12, W / 2 - roadHalf - 20, H / 2 - roadHalf - 20],
        [W / 2 + roadHalf + 12, H / 2 + roadHalf + 12, W / 2 - roadHalf - 20, H / 2 - roadHalf - 20],
      ].map(([x, y, w, h], i) => (
        <rect key={i} x={x} y={y} width={w} height={h} rx={8} className="fill-slate-200/70 dark:fill-white/[0.04]" />
      ))}

      {/* roads */}
      <rect x={0} y={H / 2 - roadHalf} width={W} height={roadHalf * 2} fill="url(#roadGrad)" />
      <rect x={W / 2 - roadHalf} y={0} width={roadHalf * 2} height={H} fill="url(#roadGrad)" />

      {/* centre lines */}
      <line x1={0} y1={H / 2} x2={W} y2={H / 2} stroke="#fbbf24" strokeWidth={1.5} strokeDasharray="14 10" opacity={0.55} />
      <line x1={W / 2} y1={0} x2={W / 2} y2={H} stroke="#fbbf24" strokeWidth={1.5} strokeDasharray="14 10" opacity={0.55} />

      {/* stop bars + crosswalks */}
      {APPROACHES.map((ap) => {
        const a = arms[ap];
        const barColor = a.color;
        if (ap === "N")
          return (
            <g key={ap}>
              <rect x={W / 2 - roadHalf + 2} y={H / 2 + roadHalf + 14} width={roadHalf * 2 - 4} height={4} rx={2} fill={barColor} />
              <line x1={W / 2 - roadHalf} y1={H / 2 + roadHalf + 8} x2={W / 2 + roadHalf} y2={H / 2 + roadHalf + 8} className="stroke-slate-400/70" strokeWidth={4} strokeDasharray="3 4" />
            </g>
          );
        if (ap === "S")
          return (
            <g key={ap}>
              <rect x={W / 2 - roadHalf + 2} y={H / 2 - roadHalf - 18} width={roadHalf * 2 - 4} height={4} rx={2} fill={barColor} />
              <line x1={W / 2 - roadHalf} y1={H / 2 - roadHalf - 8} x2={W / 2 + roadHalf} y2={H / 2 - roadHalf - 8} className="stroke-slate-400/70" strokeWidth={4} strokeDasharray="3 4" />
            </g>
          );
        if (ap === "E")
          return (
            <g key={ap}>
              <rect x={W / 2 - roadHalf - 14} y={H / 2 - roadHalf + 2} width={4} height={roadHalf * 2 - 4} rx={2} fill={barColor} />
              <line x1={W / 2 - roadHalf - 8} y1={H / 2 - roadHalf} x2={W / 2 - roadHalf - 8} y2={H / 2 + roadHalf} className="stroke-slate-400/70" strokeWidth={4} strokeDasharray="3 4" />
            </g>
          );
        return (
          <g key={ap}>
            <rect x={W / 2 + roadHalf + 10} y={H / 2 - roadHalf + 2} width={4} height={roadHalf * 2 - 4} rx={2} fill={barColor} />
            <line x1={W / 2 + roadHalf + 8} y1={H / 2 - roadHalf} x2={W / 2 + roadHalf + 8} y2={H / 2 + roadHalf} className="stroke-slate-400/70" strokeWidth={4} strokeDasharray="3 4" />
          </g>
        );
      })}

      {/* queued vehicles */}
      {APPROACHES.map((ap) => arms[ap].carsE)}

      {/* signal heads */}
      {APPROACHES.map((ap) => {
        const a = arms[ap];
        const p: Record<Approach, { x: number; y: number }> = {
          N: { x: W / 2 + roadHalf + 22, y: H / 2 + roadHalf + 20 },
          S: { x: W / 2 - roadHalf - 30, y: H / 2 - roadHalf - 46 },
          E: { x: W / 2 - roadHalf - 30, y: H / 2 + roadHalf + 14 },
          W: { x: W / 2 + roadHalf + 22, y: H / 2 - roadHalf - 34 },
        };
        const on = a.color === "#22c55e" ? "#22c55e" : a.color;
        return (
          <g key={`h-${ap}`}>
            <rect x={p[ap].x - 5} y={p[ap].y - 5} width={12} height={30} rx={5} className="fill-slate-700 dark:fill-slate-900" />
            <circle cx={p[ap].x + 1} cy={p[ap].y} r={3.4} fill={on === "#22c55e" ? "transparent" : "#ef4444"} opacity={on === "#22c55e" ? 0.25 : 1} />
            <circle cx={p[ap].x + 1} cy={p[ap].y + 10} r={3.4} fill={on === "#22c55e" ? "transparent" : "#f59e0b"} opacity={on === "#22c55e" ? 0.25 : 0.9} />
            <circle cx={p[ap].x + 1} cy={p[ap].y + 20} r={3.4} fill={on === "#22c55e" ? "#22c55e" : "transparent"} opacity={on === "#22c55e" ? 1 : 0.25} />
          </g>
        );
      })}

      {/* labels */}
      {APPROACHES.map((ap) => {
        const l = labelPos[ap];
        const a = arms[ap];
        return (
          <g key={`l-${ap}`}>
            <rect x={l.x - 34} y={l.y - 11} width={68} height={22} rx={7} className="fill-white/90 dark:fill-ink-800/90" />
            <text x={l.x} y={l.y + 4} textAnchor="middle" className="fill-slate-700 text-[11px] font-bold dark:fill-slate-200">
              {APPROACH_SHORT[ap]} · {a.cars > 0 ? `${a.cars * 3} veh` : "clear"}
            </text>
            <circle cx={l.x - 26} cy={l.y} r={3.4} fill={PHASE_TONE[ap]} opacity={phase === ap ? 1 : 0.25} />
          </g>
        );
      })}

      {/* active emergency vehicle sprite when EVP is active */}
      {emergencyApproach && (
        <g>
          {/* strobe glow ring */}
          <circle cx={W / 2} cy={H / 2} r={48} className="fill-rose-500/15 animate-ping" />
          {/* Emergency vehicle sprite crossing */}
          <g
            transform={
              emergencyApproach === "N"
                ? `translate(${W / 2 - 14}, ${H / 2 + roadHalf - 12})`
                : emergencyApproach === "S"
                  ? `translate(${W / 2 + 2}, ${H / 2 - roadHalf - 4}) rotate(180 8 10)`
                  : emergencyApproach === "E"
                    ? `translate(${W / 2 - roadHalf - 8}, ${H / 2 + 2}) rotate(90 12 8)`
                    : `translate(${W / 2 + roadHalf + 8}, ${H / 2 - 14}) rotate(-90 12 8)`
            }
          >
            <rect x={0} y={0} width={20} height={13} rx={3} fill="#ef4444" stroke="#fff" strokeWidth={1} />
            <rect x={3} y={2} width={5} height={9} rx={1} fill="#f8fafc" />
            <circle cx={14} cy={3.5} r={2.2} fill="#3b82f6" />
            <circle cx={14} cy={9.5} r={2.2} fill="#ef4444" />
          </g>
        </g>
      )}

      {/* phase banner */}
      <g>
        <rect
          x={emergencyApproach ? W / 2 - 82 : W / 2 - 62}
          y={H / 2 - 14}
          width={emergencyApproach ? 164 : 124}
          height={28}
          rx={9}
          className={
            emergencyApproach
              ? "fill-rose-600 dark:fill-rose-600"
              : "fill-white/85 dark:fill-ink-900/85"
          }
        />
        <text
          x={W / 2}
          y={H / 2 + 4}
          textAnchor="middle"
          className={
            emergencyApproach
              ? "fill-white text-[11px] font-extrabold tracking-wide"
              : "fill-slate-800 text-[11px] font-extrabold dark:fill-slate-100"
          }
        >
          {emergencyApproach
            ? `🚨 EVP · ${APPROACH_SHORT[emergencyApproach]} PRIORITY`
            : flashing
              ? "ALL-RED FLASH"
              : phase
                ? `${APPROACH_SHORT[phase]} GREEN`
                : "ALL RED"}
        </text>
      </g>
      <g>
        <rect
          x={emergencyApproach ? W / 2 - 76 : W / 2 - 52}
          y={H / 2 + 17}
          width={emergencyApproach ? 152 : 104}
          height={18}
          rx={7}
          className="fill-slate-900/80 dark:fill-white/10"
        />
        <text
          x={W / 2}
          y={H / 2 + 30}
          textAnchor="middle"
          className={
            emergencyApproach
              ? "fill-rose-300 text-[10px] font-bold tnum"
              : "fill-emerald-300 text-[10px] font-bold tnum"
          }
        >
          {emergencyApproach
            ? emergencyUnit
              ? `${emergencyUnit} · ${remaining.toFixed(0)}s hold`
              : `Opticom hold ${remaining.toFixed(0)}s`
            : phase
              ? `${remaining.toFixed(1)}s to change`
              : `cycle ${def.plan.cycle}s`}
        </text>
      </g>
      <text x={8} y={H - 6} className="fill-slate-400 text-[9px] font-medium dark:fill-slate-500">
        green split {APPROACHES.map((ap) => `${APPROACH_SHORT[ap]} ${Math.round(splits[ap])}%`).join("  ·  ")}
      </text>
    </svg>
  );
}
