import { useEffect, useMemo, useRef, useState } from "react";
import {
  APPROACHES,
  APPROACH_LABEL,
  APPROACH_SHORT,
  LOS_TONE,
  MODE_META,
  SIGNALS,
  evaluatePlan,
  greenSeconds,
  losOf,
  phaseAt,
  recommend,
  type Approach,
  type Plan,
  type SignalDef,
  type SignalMode,
} from "../../data/signals";
import type { DayRecord } from "../../data/trafficData";
import { fmtCompact, fmtInt } from "../../data/trafficData";
import { Delta, Panel, PanelHeader, Segmented } from "../ui";
import { IntersectionDiagram } from "./IntersectionDiagram";
import { cn } from "../../utils/cn";

type Ctrl = {
  mode: SignalMode;
  plan: Plan;
  transitPriority: boolean;
  pedPhase: boolean;
  forced: { ap: Approach; until: number } | null;
  emergency: { ap: Approach; unit: string; until: number } | null;
};

const SCENARIOS = [
  { key: "night", label: "Overnight", hour: 3 },
  { key: "am", label: "AM peak", hour: 8 },
  { key: "mid", label: "Midday", hour: 11.5 },
  { key: "pm", label: "PM peak", hour: 17.5 },
  { key: "event", label: "Event", hour: 19.25 },
] as const;

const INTERSECTION_SHARE = 0.33;
const PROGRESSION_DEFAULT = 52;

function initialControls(): Record<string, Ctrl> {
  return Object.fromEntries(
    SIGNALS.map((s) => [
      s.id,
      {
        mode: s.mode,
        plan: { cycle: s.plan.cycle, splits: { ...s.plan.splits }, offset: s.plan.offset },
        transitPriority: s.transitPriority,
        pedPhase: s.pedPhase,
        forced: null,
        emergency: null,
      },
    ]),
  );
}

function rebalance(splits: Record<Approach, number>, changed: Approach, value: number) {
  const others = APPROACHES.filter((a) => a !== changed);
  const rest = Math.max(4, 100 - value);
  const otherSum = others.reduce((a, k) => a + splits[k], 0) || 1;
  const next = { ...splits, [changed]: Math.round(value * 10) / 10 } as Record<Approach, number>;
  others.forEach((k) => {
    next[k] = Math.round((splits[k] / otherSum) * rest * 10) / 10;
  });
  return next;
}

function clockString(startHour: number, simTime: number) {
  const total = (startHour * 3600 + simTime) % 86400;
  const h = Math.floor(total / 3600);
  const m = Math.floor((total % 3600) / 60);
  const s = Math.floor(total % 60);
  return `${String(h).padStart(2, "0")}:${String(m).padStart(2, "0")}:${String(s).padStart(2, "0")}`;
}

interface LogEntry {
  id: number;
  clock: string;
  msg: string;
  kind: "apply" | "mode" | "force" | "coord" | "info" | "evp";
}

const LOG_TONE: Record<LogEntry["kind"], string> = {
  apply: "text-emerald-600 dark:text-emerald-400",
  mode: "text-indigo-600 dark:text-indigo-300",
  force: "text-amber-600 dark:text-amber-300",
  coord: "text-cyan-600 dark:text-cyan-300",
  info: "text-slate-500 dark:text-slate-400",
  evp: "text-rose-600 dark:text-rose-400 font-bold",
};

export function SignalControl({ records }: { records: DayRecord[] }) {
  const [controls, setControls] = useState<Record<string, Ctrl>>(initialControls);
  const [selectedId, setSelectedId] = useState<string>(SIGNALS[0].id);
  const [scenario, setScenario] = useState<(typeof SCENARIOS)[number]["key"]>("pm");
  const [simTime, setSimTime] = useState(0);
  const [running, setRunning] = useState(true);
  const [speed, setSpeed] = useState(2);
  const [progression, setProgression] = useState(PROGRESSION_DEFAULT);
  const [waves, setWaves] = useState<Record<string, boolean>>({});
  const [evpModalOpen, setEvpModalOpen] = useState(false);
  const [evpUnit, setEvpUnit] = useState("Engine 14 (Fire/Rescue)");
  const [evpCorridorId, setEvpCorridorId] = useState(SIGNALS[0].corridorId);
  const [evpApproach, setEvpApproach] = useState<Approach>("N");
  const [log, setLog] = useState<LogEntry[]>([
    { id: 0, clock: "17:30:00", msg: "Controller group synced · 16 intersections online", kind: "info" },
  ]);
  const logId = useRef(1);

  /* ---------------- demand model from the analytics filters ---------------- */

  const corridorHourly = useMemo(() => {
    const sums = new Map<string, number[]>();
    const counts = new Map<string, number>();
    const seen = new Set<string>();
    for (const r of records) {
      const arr = sums.get(r.segmentId) ?? new Array(24).fill(0);
      for (let h = 0; h < 24; h++) arr[h] += r.hVolume[h];
      sums.set(r.segmentId, arr);
      const key = `${r.segmentId}|${r.dateISO}`;
      if (!seen.has(key)) {
        seen.add(key);
        counts.set(r.segmentId, (counts.get(r.segmentId) ?? 0) + 1);
      }
    }
    const out = new Map<string, number[]>();
    sums.forEach((arr, id) => {
      const n = Math.max(1, counts.get(id) ?? 1);
      out.set(id, arr.map((v) => v / n));
    });
    return out;
  }, [records]);

  const startHour = SCENARIOS.find((s) => s.key === scenario)!.hour;
  const hour = (startHour + simTime / 3600) % 24;
  const hourBucket = Math.floor(hour);

  const demandFor = (corridorId: string) => {
    const arr = corridorHourly.get(corridorId);
    if (!arr || arr.every((v) => v === 0)) return 900;
    const h0 = Math.floor(hour) % 24;
    const h1 = (h0 + 1) % 24;
    const frac = hour - Math.floor(hour);
    return (arr[h0] * (1 - frac) + arr[h1] * frac) * INTERSECTION_SHARE;
  };

  /* ------------------------------ sim loop ------------------------------ */

  const stateRef = useRef({ controls, speed, demandFor });
  stateRef.current = { controls, speed, demandFor };

  useEffect(() => {
    if (!running) return;
    const id = setInterval(() => {
      const snap = stateRef.current;
      const step = snap.speed;
      const t = simTimeRef.current + step;
      simTimeRef.current = t;
      setSimTime(t);

      setQueues((prev) => {
        const next: Record<string, Record<Approach, number>> = {};
        for (const def of SIGNALS) {
          const ctrl = snap.controls[def.id];
          const demand = snap.demandFor(def.corridorId);
          const isEvpActive = ctrl.emergency && ctrl.emergency.until > t;
          const { phase } = phaseAt(ctrl.plan, ctrl.mode, t);
          const activePhase = isEvpActive ? ctrl.emergency!.ap : phase;
          const cur = prev[def.id];
          const out = {} as Record<Approach, number>;
          for (const ap of APPROACHES) {
            const arrive = (demand * def.approach[ap].share) / 3600 * step * (1 + 0.18 * Math.sin((t + ap.charCodeAt(0) * 37) / 9));
            let served = 0;
            if (ctrl.mode !== "flash" && activePhase === ap) {
              const g = isEvpActive ? ctrl.plan.cycle : greenSeconds(ctrl.plan, ap);
              served = (1900 * def.approach[ap].lanes * (isEvpActive ? 1.0 : g / ctrl.plan.cycle)) / 3600 * step;
            }
            const base = cur ? cur[ap] : 4;
            out[ap] = Math.max(0, Math.min(64, base + arrive - served));
          }
          next[def.id] = out;
        }
        return next;
      });
    }, 250);
    return () => clearInterval(id);
  }, [running]);

  const simTimeRef = useRef(0);
  const [queues, setQueues] = useState<Record<string, Record<Approach, number>>>({});

  // adaptive controllers drift toward the AI recommendation every ~12 sim-seconds
  useEffect(() => {
    if (!running) return;
    const id = setInterval(() => {
      setControls((prev) => {
        let changed = false;
        const next = { ...prev };
        for (const def of SIGNALS) {
          const ctrl = prev[def.id];
          if (ctrl.mode !== "adaptive") continue;
          const rec = recommend(def, demandFor(def.corridorId), progression);
          const blend = (a: number, b: number, k = 0.16) => Math.round((a + (b - a) * k) * 10) / 10;
          const splits = { ...ctrl.plan.splits };
          for (const ap of APPROACHES) splits[ap] = blend(splits[ap], rec.splits[ap]);
          next[def.id] = {
            ...ctrl,
            plan: {
              cycle: blend(ctrl.plan.cycle, rec.cycle, 0.12),
              splits,
              offset: blend(ctrl.plan.offset, rec.offset, 0.1),
            },
          };
          changed = true;
        }
        return changed ? next : prev;
      });
    }, 2600);
    return () => clearInterval(id);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [running, progression, records]);

  /* ----------------------------- actions ----------------------------- */

  const pushLog = (msg: string, kind: LogEntry["kind"]) =>
    setLog((l) =>
      [{ id: logId.current++, clock: clockString(startHour, simTime), msg, kind }, ...l].slice(0, 40),
    );

  const patchCtrl = (id: string, patch: Partial<Ctrl>) =>
    setControls((prev) => ({ ...prev, [id]: { ...prev[id], ...patch } }));

  const setMode = (id: string, mode: SignalMode) => {
    patchCtrl(id, { mode });
    pushLog(`${SIGNAL_MAP[id].name} → ${MODE_META[mode].label}`, "mode");
  };

  const applyRec = (id: string) => {
    const def = SIGNAL_MAP[id];
    const rec = recommend(def, demandFor(def.corridorId), progression);
    patchCtrl(id, { plan: { cycle: rec.cycle, splits: { ...rec.splits }, offset: rec.offset }, mode: "fixed" });
    pushLog(
      `AI plan applied at ${def.name} · cycle ${rec.cycle}s · target ${rec.expectedDelay.toFixed(1)}s/veh`,
      "apply",
    );
  };

  const applyAllAdaptive = () => {
    const active = SIGNALS.filter((s) => controls[s.id].mode !== "flash");
    setControls((prev) => {
      const next = { ...prev };
      for (const def of active) {
        const rec = recommend(def, demandFor(def.corridorId), progression);
        next[def.id] = { ...next[def.id], plan: { cycle: rec.cycle, splits: { ...rec.splits }, offset: rec.offset }, mode: "adaptive" };
      }
      return next;
    });
    pushLog(`Network-wide AI optimisation pushed to ${active.length} intersections`, "apply");
  };

  const flashAll = () => {
    setControls((prev) => {
      const next = { ...prev };
      for (const def of SIGNALS) next[def.id] = { ...next[def.id], mode: "flash" };
      return next;
    });
    pushLog("Emergency all-red flash engaged network-wide", "force");
  };

  const forceGreen = (id: string, ap: Approach) => {
    patchCtrl(id, { forced: { ap, until: simTime + 30 }, mode: "manual" });
    pushLog(`${APPROACH_LABEL[ap]} priority forced at ${SIGNAL_MAP[id].name} (30s)`, "force");
  };

  const dispatchCorridorEvp = (corridorId: string, ap: Approach, unit: string) => {
    const members = SIGNALS.filter((s) => s.corridorId === corridorId);
    const duration = 45;
    setControls((prev) => {
      const next = { ...prev };
      for (const def of members) {
        next[def.id] = {
          ...next[def.id],
          mode: "preempt",
          emergency: { ap, unit, until: simTime + duration },
        };
      }
      return next;
    });
    pushLog(
      `🚨 ${unit} Opticom corridor wave locked on ${members[0]?.corridor} (${APPROACH_LABEL[ap]} green, ${duration}s hold)`,
      "evp",
    );
    setEvpModalOpen(false);
  };

  const triggerIntersectionEvp = (id: string, ap: Approach, unit = "Engine 14 (Fire/Rescue)") => {
    patchCtrl(id, {
      mode: "preempt",
      emergency: { ap, unit, until: simTime + 35 },
    });
    pushLog(`🚨 Emergency Pre-empt locked at ${SIGNAL_MAP[id].name} (${APPROACH_LABEL[ap]}, ${unit})`, "evp");
  };

  const clearAllEvp = () => {
    setControls((prev) => {
      const next = { ...prev };
      for (const def of SIGNALS) {
        if (next[def.id].emergency || next[def.id].mode === "preempt") {
          next[def.id] = {
            ...next[def.id],
            mode: "adaptive",
            emergency: null,
          };
        }
      }
      return next;
    });
    pushLog("All emergency pre-emptions released · returned to Adaptive AI", "info");
  };

  const toggleWave = (corridorId: string) => {
    const on = !waves[corridorId];
    setWaves((w) => ({ ...w, [corridorId]: on }));
    const members = SIGNALS.filter((s) => s.corridorId === corridorId);
    if (on) {
      setControls((prev) => {
        const next = { ...prev };
        for (const def of members) {
          const cycle = next[def.id].plan.cycle;
          const offset = Math.round(((def.chainMeters / (progression / 3.6)) % cycle + cycle) % cycle);
          next[def.id] = { ...next[def.id], plan: { ...next[def.id].plan, offset } };
        }
        return next;
      });
      pushLog(`Green wave armed on ${members[0]?.corridor} @ ${progression} km/h`, "coord");
    } else {
      pushLog(`Green wave released on ${members[0]?.corridor}`, "coord");
    }
  };

  /* ----------------------------- derived ----------------------------- */

  const selected = SIGNAL_MAP[selectedId];
  const ctrl = controls[selectedId];
  const demand = demandFor(selected.corridorId);
  const evalNow = useMemo(
    () => evaluatePlan(selected, ctrl.plan, demand),
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [selected, ctrl.plan, demand.toFixed(0)],
  );
  const rec = useMemo(() => recommend(selected, demand, progression), [selected, demand.toFixed(0), progression]);
  const evalRec = useMemo(() => evaluatePlan(selected, rec, demand), [selected, rec, demand.toFixed(0)]);
  const evalCurPlan = useMemo(() => evaluatePlan(selected, selected.plan, demand), [selected, demand.toFixed(0)]);

  const isSelectedEvp = ctrl.emergency && ctrl.emergency.until > simTime;
  const phase = phaseAt(ctrl.plan, ctrl.mode, simTime);
  const simPhase = isSelectedEvp
    ? ctrl.emergency!.ap
    : ctrl.forced && ctrl.forced.until > simTime
      ? ctrl.forced.ap
      : phase.phase;

  const activeEvpSignals = SIGNALS.filter(
    (s) => controls[s.id].emergency && controls[s.id].emergency!.until > simTime,
  );

  const listRows = useMemo(
    () =>
      SIGNALS.map((def) => {
        const c = controls[def.id];
        const ev = evaluatePlan(def, c.plan, demandFor(def.corridorId));
        const ph = phaseAt(c.plan, c.mode, simTime);
        const evp = c.emergency && c.emergency.until > simTime ? c.emergency : null;
        return {
          def,
          ctrl: c,
          ev,
          phase: evp ? evp.ap : ph.phase,
          remaining: evp ? evp.until - simTime : ph.remaining,
          evp,
        };
      }),
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [controls, hourBucket, Math.floor(simTime / 4), records],
  );

  const network = useMemo(() => {
    let delaySum = 0;
    let demandSum = 0;
    let served = 0;
    let arrival = 0;
    let adaptive = 0;
    let flash = 0;
    let actions = 0;
    let maxQueue = 0;
    for (const row of listRows) {
      delaySum += row.ev.avgDelay * row.ev.throughput;
      demandSum += row.ev.throughput;
      served += Math.min(row.ev.throughput, row.ev.throughput);
      arrival += row.ev.throughput;
      if (row.ctrl.mode === "adaptive") adaptive++;
      if (row.ctrl.mode === "flash") flash++;
      actions += row.def.baselineActions;
      maxQueue = Math.max(maxQueue, ...APPROACHES.map((ap) => queues[row.def.id]?.[ap] ?? 0));
    }
    const avgDelay = demandSum ? delaySum / demandSum : 0;
    return {
      count: listRows.length,
      avgDelay,
      los: losOf(avgDelay),
      adaptive,
      flash,
      actions,
      maxQueue,
      demandSum,
      servedSum: served + arrival - arrival,
    };
  }, [listRows, queues]);

  const savedHours = Math.max(
    0,
    ((evalCurPlan.avgDelay - evalNow.avgDelay) / 3600) * evalNow.throughput * 24,
  );

  /* ------------------------------ render ------------------------------ */

  return (
    <div className="space-y-4">
      {/* toolbar */}
      <Panel className="flex flex-col gap-3 lg:flex-row lg:items-center lg:justify-between">
        <div className="flex flex-wrap items-center gap-2 sm:gap-3">
          <span className="flex items-center gap-1.5 text-[11px] font-semibold uppercase tracking-wider text-slate-400">
            <span className="relative flex h-2 w-2">
              <span className={cn("absolute h-full w-full rounded-full", running ? "live-dot bg-emerald-400" : "bg-slate-400")} />
              <span className={cn("relative h-2 w-2 rounded-full", running ? "bg-emerald-500" : "bg-slate-400")} />
            </span>
            Sim
          </span>
          <span className="rounded-xl border border-slate-200 bg-slate-100/70 px-2.5 py-1.5 text-xs font-bold text-slate-700 tnum dark:border-white/10 dark:bg-white/[0.05] dark:text-slate-100">
            {clockString(startHour, simTime)}
          </span>
          <div className="max-w-full overflow-x-auto">
            <Segmented
              size="sm"
              options={SCENARIOS.map((s) => ({ key: s.key, label: s.label }))}
              value={scenario}
              onChange={(k) => {
                setScenario(k);
                setSimTime(0);
                simTimeRef.current = 0;
                setQueues({});
              }}
            />
          </div>
          <div className="flex items-center gap-1.5 rounded-xl border border-slate-200 bg-slate-100/70 px-2 py-1 text-[11px] font-medium text-slate-500 dark:border-white/10 dark:bg-white/[0.05] dark:text-slate-400">
            Speed
            <input
              type="range"
              min={1}
              max={12}
              value={speed}
              onChange={(e) => setSpeed(Number(e.target.value))}
              className="range w-20"
            />
            <span className="w-9 text-right font-bold text-slate-700 tnum dark:text-slate-200">{speed}×</span>
          </div>
          <button
            type="button"
            onClick={() => setRunning((r) => !r)}
            className="inline-flex items-center gap-1.5 rounded-xl border border-slate-200 px-2.5 py-1.5 text-[11px] font-semibold text-slate-600 transition-colors hover:border-indigo-300 hover:text-indigo-600 dark:border-white/10 dark:text-slate-300"
          >
            {running ? (
              <svg viewBox="0 0 24 24" className="h-3.5 w-3.5" fill="currentColor">
                <rect x="7" y="5" width="3.5" height="14" rx="1" />
                <rect x="13.5" y="5" width="3.5" height="14" rx="1" />
              </svg>
            ) : (
              <svg viewBox="0 0 24 24" className="h-3.5 w-3.5" fill="currentColor">
                <path d="M8 5.5v13l11-6.5-11-6.5Z" />
              </svg>
            )}
            {running ? "Pause" : "Resume"}
          </button>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <button
            type="button"
            onClick={() => setEvpModalOpen(true)}
            className="inline-flex items-center gap-1.5 rounded-xl border border-rose-300 bg-gradient-to-r from-rose-600 to-red-600 px-3 py-1.5 text-[11px] font-bold text-white shadow-md shadow-rose-500/30 transition-transform hover:-translate-y-px"
          >
            <span className="relative flex h-2 w-2">
              <span className="live-dot absolute inline-flex h-full w-full rounded-full bg-rose-200" />
              <span className="relative inline-flex h-2 w-2 rounded-full bg-white" />
            </span>
            Emergency Signal Pre-empt
          </button>
          <button
            type="button"
            onClick={applyAllAdaptive}
            className="inline-flex items-center gap-1.5 rounded-xl bg-gradient-to-r from-indigo-600 to-violet-600 px-3 py-1.5 text-[11px] font-bold text-white shadow-md shadow-indigo-500/25 transition-transform hover:-translate-y-px"
          >
            <svg viewBox="0 0 24 24" className="h-3.5 w-3.5" fill="none" stroke="currentColor" strokeWidth={2} strokeLinecap="round">
              <path d="M12 3v3m0 12v3M3 12h3m12 0h3M7 7l2 2m6 6 2 2m0-10-2 2m-6 6-2 2" />
            </svg>
            Optimise all signals
          </button>
          <button
            type="button"
            onClick={flashAll}
            className="inline-flex items-center gap-1.5 rounded-xl border border-rose-200 bg-rose-50 px-3 py-1.5 text-[11px] font-bold text-rose-600 transition-colors hover:bg-rose-100 dark:border-rose-400/25 dark:bg-rose-500/10 dark:text-rose-300"
          >
            All-red flash
          </button>
        </div>
      </Panel>

      {/* Active emergency pre-emption banner */}
      {activeEvpSignals.length > 0 && (
        <div className="flex flex-wrap items-center justify-between gap-3 rounded-2xl border border-rose-400/40 bg-gradient-to-r from-rose-500/15 via-red-500/10 to-rose-500/15 px-4 py-2.5 text-xs text-rose-700 shadow-sm dark:text-rose-200">
          <div className="flex items-center gap-2.5 font-bold">
            <span className="flex h-6 w-6 items-center justify-center rounded-lg bg-rose-600 text-white shadow">
              🚨
            </span>
            <span>
              EMERGENCY VEHICLE PRE-EMPTION ACTIVE ON {activeEvpSignals.length} INTERSECTION
              {activeEvpSignals.length > 1 ? "S" : ""}
            </span>
            <span className="hidden sm:inline font-normal text-rose-600/90 dark:text-rose-300/80">
              — Opticom corridor green hold clearing emergency route
            </span>
          </div>
          <button
            type="button"
            onClick={clearAllEvp}
            className="rounded-xl border border-rose-300 bg-white px-3 py-1 text-[11px] font-bold text-rose-700 shadow-sm transition-colors hover:bg-rose-50 dark:border-rose-400/30 dark:bg-rose-500/20 dark:text-white"
          >
            Release EVP &amp; return to AI
          </button>
        </div>
      )}

      {/* Emergency dispatch popup modal */}
      {evpModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4 backdrop-blur-sm animate-fade">
          <div className="w-full max-w-md rounded-2xl border border-rose-300/50 bg-white p-5 shadow-2xl dark:border-white/10 dark:bg-ink-900">
            <div className="flex items-center justify-between border-b border-slate-200/70 pb-3 dark:border-white/10">
              <div className="flex items-center gap-2.5">
                <span className="flex h-9 w-9 items-center justify-center rounded-xl bg-rose-600 text-lg text-white shadow-md">
                  🚨
                </span>
                <div>
                  <h3 className="text-sm font-bold text-slate-900 dark:text-white">
                    Emergency Signal Pre-emption
                  </h3>
                  <p className="text-[11px] text-slate-500 dark:text-slate-400">
                    Opticom acoustic / IR corridor green wave
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setEvpModalOpen(false)}
                className="rounded-lg p-1 text-slate-400 hover:bg-slate-100 dark:hover:bg-white/10"
              >
                ✕
              </button>
            </div>

            <div className="mt-4 space-y-3">
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-200">
                Responding Unit
                <select
                  value={evpUnit}
                  onChange={(e) => setEvpUnit(e.target.value)}
                  className="mt-1 w-full rounded-xl border border-slate-200 bg-slate-50 px-3 py-2 text-xs font-semibold text-slate-800 outline-none dark:border-white/10 dark:bg-white/[0.04] dark:text-slate-100"
                >
                  <option value="Engine 14 (Fire/Rescue)">Engine 14 · Heavy Rescue (Fire)</option>
                  <option value="Ladder 07 (Fire Hook)">Ladder 07 · High-Rise Unit (Fire)</option>
                  <option value="Medic 08 (ALS Ambulance)">Medic 08 · Code 3 Ambulance</option>
                  <option value="Unit 312 (Police Tactical)">Unit 312 · Police Emergency Escort</option>
                </select>
              </label>

              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-200">
                Corridor Route
                <select
                  value={evpCorridorId}
                  onChange={(e) => setEvpCorridorId(e.target.value)}
                  className="mt-1 w-full rounded-xl border border-slate-200 bg-slate-50 px-3 py-2 text-xs font-semibold text-slate-800 outline-none dark:border-white/10 dark:bg-white/[0.04] dark:text-slate-100"
                >
                  {Array.from(new Set(SIGNALS.map((s) => s.corridorId))).map((cid) => {
                    const first = SIGNALS.find((s) => s.corridorId === cid)!;
                    return (
                      <option key={cid} value={cid}>
                        {first.corridor} ({first.district} · {SIGNALS.filter((s) => s.corridorId === cid).length} signals)
                      </option>
                    );
                  })}
                </select>
              </label>

              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-200">
                Priority Approach Direction
                <div className="mt-1.5 grid grid-cols-4 gap-1.5">
                  {APPROACHES.map((ap) => (
                    <button
                      key={ap}
                      type="button"
                      onClick={() => setEvpApproach(ap)}
                      className={cn(
                        "rounded-xl border py-2 text-center text-xs font-bold transition-all",
                        evpApproach === ap
                          ? "border-rose-600 bg-rose-600 text-white shadow-sm"
                          : "border-slate-200 bg-slate-50 text-slate-600 hover:border-rose-300 dark:border-white/10 dark:bg-white/[0.04] dark:text-slate-300",
                      )}
                    >
                      {APPROACH_SHORT[ap]} · {APPROACH_LABEL[ap].slice(0, 5)}
                    </button>
                  ))}
                </div>
              </label>
            </div>

            <div className="mt-5 flex items-center justify-end gap-2 border-t border-slate-200/70 pt-3 dark:border-white/10">
              <button
                type="button"
                onClick={() => setEvpModalOpen(false)}
                className="rounded-xl border border-slate-200 px-3.5 py-1.5 text-xs font-semibold text-slate-500 hover:bg-slate-100 dark:border-white/10 dark:text-slate-400"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={() => dispatchCorridorEvp(evpCorridorId, evpApproach, evpUnit)}
                className="rounded-xl bg-gradient-to-r from-rose-600 to-red-600 px-4 py-2 text-xs font-bold text-white shadow-md shadow-rose-500/25 transition-transform hover:-translate-y-px"
              >
                🚨 Engage Emergency Green Wave (45s)
              </button>
            </div>
          </div>
        </div>
      )}

      {/* network strip */}
      <div className="grid grid-cols-2 gap-3 lg:grid-cols-3 2xl:grid-cols-6">
        {[
          { label: "Intersections", value: fmtInt(network.count), sub: `${network.adaptive} adaptive · ${network.flash} in flash`, color: "#6366f1" },
          { label: "Avg control delay", value: `${network.avgDelay.toFixed(1)} s`, sub: `network LOS ${network.los}`, color: "#22d3ee" },
          { label: "Served demand", value: `${fmtCompact(network.demandSum)} veh/h`, sub: "cleared at green time", color: "#34d399" },
          { label: "Longest queue", value: `${fmtInt(network.maxQueue)} veh`, sub: "worst approach on network", color: "#f59e0b" },
          { label: "AI retimings today", value: fmtCompact(network.actions), sub: "green splits + offsets", color: "#a855f7" },
          { label: "Selected-signal gain", value: `${savedHours.toFixed(1)} h/day`, sub: "vs stored timing plan", color: "#10b981" },
        ].map((s, i) => (
          <div key={s.label} className="panel p-3 animate-rise" style={{ animationDelay: `${i * 45}ms` }}>
            <div className="flex items-center gap-2">
              <span className="h-2 w-2 rounded-full" style={{ background: s.color }} />
              <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400">{s.label}</span>
            </div>
            <div className="mt-1.5 text-lg font-bold tracking-tight text-slate-900 tnum dark:text-white">{s.value}</div>
            <div className="text-[10px] text-slate-500 dark:text-slate-400">{s.sub}</div>
          </div>
        ))}
      </div>

      <div className="grid gap-4 xl:grid-cols-[330px_1fr]">
        {/* signal list */}
        <Panel padded={false} className="overflow-hidden">
          <div className="border-b border-slate-200/70 px-4 py-3 dark:border-white/[0.06]">
            <h3 className="text-[15px] font-semibold tracking-tight text-slate-900 dark:text-slate-100">
              Signal inventory
            </h3>
            <p className="mt-0.5 text-xs text-slate-500 dark:text-slate-400">
              {listRows.length} controllers · {SIGNALS.filter((s) => controls[s.id].mode === "adaptive").length} on adaptive AI
            </p>
          </div>
          <ul className="max-h-[560px] divide-y divide-slate-100 overflow-y-auto dark:divide-white/[0.05]">
            {listRows.map(({ def, ctrl: c, ev, phase: ph, remaining, evp }) => {
              const active = def.id === selectedId;
              return (
                <li key={def.id}>
                  <button
                    type="button"
                    onClick={() => setSelectedId(def.id)}
                    className={cn(
                      "w-full px-4 py-2.5 text-left transition-colors",
                      active ? "bg-indigo-50/80 dark:bg-indigo-500/10" : "hover:bg-slate-50 dark:hover:bg-white/[0.03]",
                    )}
                  >
                    <div className="flex items-center justify-between gap-2">
                      <span className="flex min-w-0 items-center gap-2">
                        <span
                          className="h-2 w-2 shrink-0 rounded-full transition-colors"
                          style={{ background: c.mode === "flash" ? "#f43f5e" : ph ? "#22c55e" : "#94a3b8" }}
                        />
                        <span className="min-w-0">
                          <span className="block truncate text-xs font-semibold text-slate-800 dark:text-slate-100">
                            {def.name}
                          </span>
                          <span className="block truncate text-[10px] text-slate-400 dark:text-slate-500">
                            {def.corridor} · {def.district}
                          </span>
                        </span>
                      </span>
                      <span className="flex shrink-0 items-center gap-1.5">
                        <span className={cn("rounded-md border px-1.5 py-0.5 text-[10px] font-bold", LOS_TONE[ev.los])}>
                          {ev.los}
                        </span>
                        <span className="w-11 text-right text-[10px] font-semibold text-slate-500 tnum dark:text-slate-400">
                          {ev.avgDelay.toFixed(0)}s
                        </span>
                      </span>
                    </div>
                    <div className="mt-1.5 flex items-center gap-2">
                      <span
                        className="rounded px-1.5 py-0.5 text-[9px] font-bold uppercase tracking-wide"
                        style={{ background: `${MODE_META[c.mode].color}1f`, color: MODE_META[c.mode].color }}
                      >
                        {MODE_META[c.mode].label}
                      </span>
                      <span className="text-[10px] text-slate-400 tnum dark:text-slate-500">
                        C{c.plan.cycle}s · {ph ? `${APPROACH_SHORT[ph]} ${remaining.toFixed(0)}s` : "all red"}
                      </span>
                      <span className="ml-auto flex gap-1">
                        {evp && (
                          <span className="animate-pulse rounded bg-rose-600 px-1.5 text-[9px] font-extrabold text-white">
                            🚨 EVP {APPROACH_SHORT[evp.ap]}
                          </span>
                        )}
                        {c.transitPriority && (
                          <span className="rounded bg-cyan-500/15 px-1 text-[9px] font-bold text-cyan-600 dark:text-cyan-300">TSP</span>
                        )}
                        {c.pedPhase && (
                          <span className="rounded bg-violet-500/15 px-1 text-[9px] font-bold text-violet-600 dark:text-violet-300">PED</span>
                        )}
                        {def.hardware < 0.9 && (
                          <span className="rounded bg-amber-500/15 px-1 text-[9px] font-bold text-amber-600 dark:text-amber-300">HW</span>
                        )}
                      </span>
                    </div>
                  </button>
                </li>
              );
            })}
          </ul>
        </Panel>

        <div className="space-y-4">
          {/* live intersection */}
          <Panel>
            <PanelHeader
              title={selected.name}
              subtitle={`${selected.corridor} · ${selected.district} · controller ${selected.id.toUpperCase()} · demand ${fmtInt(demand)} veh/h`}
              right={
                <div className="flex items-center gap-2">
                  <span className={cn("rounded-lg border px-2 py-1 text-[10px] font-bold", LOS_TONE[evalNow.los])}>
                    LOS {evalNow.los}
                  </span>
                  <Delta
                    value={evalCurPlan.avgDelay ? ((evalNow.avgDelay - evalCurPlan.avgDelay) / evalCurPlan.avgDelay) * 100 : 0}
                    invert
                  />
                </div>
              }
            />
            <div className="mt-4 grid gap-4 lg:grid-cols-[minmax(0,1fr)_240px]">
              <div className="rounded-2xl border border-slate-200/70 bg-slate-50/60 p-2 dark:border-white/[0.06] dark:bg-white/[0.02]">
                <IntersectionDiagram
                  def={selected}
                  phase={simPhase}
                  remaining={
                    ctrl.emergency && ctrl.emergency.until > simTime
                      ? ctrl.emergency.until - simTime
                      : ctrl.forced && ctrl.forced.until > simTime
                        ? ctrl.forced.until - simTime
                        : phase.remaining
                  }
                  queues={queues[selectedId] ?? { N: 0, E: 0, S: 0, W: 0 }}
                  splits={ctrl.plan.splits}
                  flashing={ctrl.mode === "flash"}
                  forced={ctrl.forced && ctrl.forced.until > simTime ? ctrl.forced.ap : null}
                  emergencyApproach={ctrl.emergency && ctrl.emergency.until > simTime ? ctrl.emergency.ap : null}
                  emergencyUnit={ctrl.emergency?.unit}
                />
              </div>

              <div className="space-y-2.5">
                {evalNow.per.map((p) => {
                  const isGreen = simPhase === p.ap;
                  const fill = Math.min(100, p.degree * 100);
                  return (
                    <div key={p.ap} className="rounded-xl border border-slate-200/80 p-2.5 dark:border-white/[0.07]">
                      <div className="flex items-center justify-between">
                        <span className="flex items-center gap-1.5 text-[11px] font-bold text-slate-700 dark:text-slate-200">
                          <span
                            className="h-2 w-2 rounded-full transition-colors"
                            style={{ background: isGreen ? "#22c55e" : ctrl.mode === "flash" ? "#f43f5e" : "#ef4444" }}
                          />
                          {APPROACH_LABEL[p.ap]}
                        </span>
                        <span className="text-[11px] font-semibold text-slate-500 tnum dark:text-slate-400">
                          {p.green.toFixed(0)}s green
                        </span>
                      </div>
                      <div className="mt-1.5 h-1.5 overflow-hidden rounded-full bg-slate-200/70 dark:bg-white/10">
                        <div
                          className={cn("h-full rounded-full transition-[width] duration-500", p.degree > 0.9 ? "bg-rose-500" : p.degree > 0.75 ? "bg-amber-500" : "bg-emerald-500")}
                          style={{ width: `${fill}%` }}
                        />
                      </div>
                      <div className="mt-1 flex items-center justify-between text-[10px] text-slate-400 tnum dark:text-slate-500">
                        <span>{fmtInt(p.demand)} veh/h · v/c {p.degree.toFixed(2)}</span>
                        <span className={cn("font-semibold", p.delay > 55 ? "text-rose-500" : p.delay > 35 ? "text-amber-500" : "text-emerald-500")}>
                          {p.delay.toFixed(0)}s delay
                        </span>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          </Panel>

          <div className="grid gap-4 lg:grid-cols-2">
            {/* plan editor */}
            <Panel>
              <PanelHeader
                title="Timing plan editor"
                subtitle="Changes take effect on the next cycle"
                right={
                  <Segmented
                    size="sm"
                    options={(Object.keys(MODE_META) as SignalMode[]).map((m) => ({ key: m, label: MODE_META[m].label }))}
                    value={ctrl.mode}
                    onChange={(m) => setMode(selectedId, m)}
                  />
                }
              />
              <p className="mt-2 text-[11px] text-slate-500 dark:text-slate-400">{MODE_META[ctrl.mode].hint}</p>

              <div className="mt-3 space-y-3">
                <Slider
                  label="Cycle length"
                  value={ctrl.plan.cycle}
                  min={40}
                  max={150}
                  step={1}
                  unit="s"
                  onChange={(v) => patchCtrl(selectedId, { plan: { ...ctrl.plan, cycle: v } })}
                  hint={`lost time ${APPROACHES.length * 6}s · usable ${Math.max(0, ctrl.plan.cycle - APPROACHES.length * 6)}s`}
                />
                <Slider
                  label="Coordination offset"
                  value={ctrl.plan.offset}
                  min={0}
                  max={Math.max(1, ctrl.plan.cycle - 1)}
                  step={1}
                  unit="s"
                  onChange={(v) => patchCtrl(selectedId, { plan: { ...ctrl.plan, offset: v } })}
                  hint="shift relative to the corridor master clock"
                />
                {APPROACHES.map((ap) => (
                  <Slider
                    key={ap}
                    label={`${APPROACH_LABEL[ap]} green`}
                    value={ctrl.plan.splits[ap]}
                    min={5}
                    max={70}
                    step={0.5}
                    unit="%"
                    accent={simPhase === ap ? "#22c55e" : undefined}
                    onChange={(v) => patchCtrl(selectedId, { plan: { ...ctrl.plan, splits: rebalance(ctrl.plan.splits, ap, v) } })}
                    hint={`${greenSeconds(ctrl.plan, ap).toFixed(1)}s · ${fmtInt(evalNow.per.find((p) => p.ap === ap)!.demand)} veh/h`}
                  />
                ))}
              </div>

              <div className="mt-3 flex flex-wrap items-center gap-2">
                <Toggle
                  label="Transit priority"
                  on={ctrl.transitPriority}
                  onClick={() => {
                    patchCtrl(selectedId, { transitPriority: !ctrl.transitPriority });
                    pushLog(`Transit signal priority ${!ctrl.transitPriority ? "enabled" : "disabled"} · ${selected.name}`, "mode");
                  }}
                />
                <Toggle
                  label="Pedestrian phase"
                  on={ctrl.pedPhase}
                  onClick={() => patchCtrl(selectedId, { pedPhase: !ctrl.pedPhase })}
                />
                {APPROACHES.map((ap) => (
                  <button
                    key={`force-${ap}`}
                    type="button"
                    onClick={() => forceGreen(selectedId, ap)}
                    className="rounded-lg border border-slate-200 px-2 py-1 text-[10px] font-semibold text-slate-500 transition-colors hover:border-amber-300 hover:text-amber-600 dark:border-white/10 dark:text-slate-400"
                  >
                    Force {APPROACH_SHORT[ap]}
                  </button>
                ))}
              </div>

              {/* Emergency pre-emption row */}
              <div className="mt-2.5 flex flex-wrap items-center justify-between gap-1.5 rounded-xl border border-rose-200/80 bg-rose-50/60 p-2 dark:border-rose-400/25 dark:bg-rose-500/10">
                <span className="text-[10px] font-bold text-rose-700 dark:text-rose-200">
                  🚨 Instant Emergency Pre-empt:
                </span>
                <div className="flex flex-wrap gap-1">
                  {APPROACHES.map((ap) => {
                    const isEvpThis = ctrl.emergency && ctrl.emergency.ap === ap && ctrl.emergency.until > simTime;
                    return (
                      <button
                        key={`evp-${ap}`}
                        type="button"
                        onClick={() => triggerIntersectionEvp(selectedId, ap, "Engine 14 (Fire/Rescue)")}
                        className={cn(
                          "rounded-lg px-2 py-1 text-[10px] font-bold transition-all",
                          isEvpThis
                            ? "bg-rose-600 text-white shadow-sm"
                            : "border border-rose-300 bg-white text-rose-700 hover:bg-rose-100 dark:border-rose-400/30 dark:bg-rose-500/20 dark:text-rose-200",
                        )}
                      >
                        {isEvpThis ? "🚨 ACTIVE " : ""}EVP {APPROACH_SHORT[ap]}
                      </button>
                    );
                  })}
                </div>
              </div>
            </Panel>

            {/* recommendation */}
            <Panel>
              <PanelHeader
                title="AI retiming recommendation"
                subtitle="Webster optimal cycle + demand-proportional green split"
                right={
                  <span className="rounded-lg bg-violet-500/10 px-2 py-1 text-[10px] font-bold text-violet-600 dark:text-violet-300">
                    Y = {rec.ySum.toFixed(2)}
                  </span>
                }
              />
              <p className="mt-2 rounded-xl bg-slate-100/70 px-3 py-2 text-[11px] leading-relaxed text-slate-600 dark:bg-white/[0.04] dark:text-slate-300">
                {rec.note}
              </p>

              <div className="mt-3 grid grid-cols-3 gap-2">
                {[
                  { k: "Cycle", now: `${ctrl.plan.cycle}s`, rec: `${rec.cycle}s` },
                  { k: "Delay", now: `${evalNow.avgDelay.toFixed(1)}s`, rec: `${evalRec.avgDelay.toFixed(1)}s` },
                  { k: "LOS", now: evalNow.los, rec: evalRec.los },
                ].map((m) => (
                  <div key={m.k} className="rounded-xl border border-slate-200/80 p-2 text-center dark:border-white/[0.07]">
                    <div className="text-[10px] font-bold uppercase tracking-wider text-slate-400">{m.k}</div>
                    <div className="mt-1 text-[11px] text-slate-400 line-through tnum dark:text-slate-500">{m.now}</div>
                    <div className="text-sm font-bold text-slate-900 tnum dark:text-white">{m.rec}</div>
                  </div>
                ))}
              </div>

              <div className="mt-3 space-y-1.5">
                {APPROACHES.map((ap) => (
                  <div key={ap} className="flex items-center gap-2">
                    <span className="w-14 text-[11px] font-semibold text-slate-500 dark:text-slate-400">
                      {APPROACH_SHORT[ap]} green
                    </span>
                    <span className="relative h-3 flex-1 overflow-hidden rounded-full bg-slate-200/70 dark:bg-white/[0.07]">
                      <span
                        className="absolute inset-y-0 left-0 rounded-full bg-slate-400/60"
                        style={{ width: `${ctrl.plan.splits[ap]}%` }}
                      />
                      <span
                        className="absolute inset-y-0 left-0 rounded-full bg-gradient-to-r from-indigo-500 to-violet-500 transition-[width] duration-500"
                        style={{ width: `${rec.splits[ap]}%` }}
                      />
                    </span>
                    <span className="w-14 text-right text-[11px] font-bold text-slate-700 tnum dark:text-slate-200">
                      {rec.splits[ap].toFixed(1)}%
                    </span>
                  </div>
                ))}
              </div>

              <div className="mt-3 grid grid-cols-2 gap-2 text-[11px]">
                <div className="rounded-xl bg-emerald-50 px-3 py-2 dark:bg-emerald-500/10">
                  <div className="text-[10px] font-bold uppercase tracking-wider text-emerald-700/70 dark:text-emerald-300/70">
                    Delay change
                  </div>
                  <div className="text-base font-bold text-emerald-700 tnum dark:text-emerald-300">
                    {evalNow.avgDelay ? (((evalRec.avgDelay - evalNow.avgDelay) / evalNow.avgDelay) * 100).toFixed(1) : "0.0"}%
                  </div>
                </div>
                <div className="rounded-xl bg-indigo-50 px-3 py-2 dark:bg-indigo-500/10">
                  <div className="text-[10px] font-bold uppercase tracking-wider text-indigo-700/70 dark:text-indigo-300/70">
                    Throughput gain
                  </div>
                  <div className="text-base font-bold text-indigo-700 tnum dark:text-indigo-300">
                    {evalNow.throughput ? (((evalRec.throughput - evalNow.throughput) / evalNow.throughput) * 100).toFixed(1) : "0.0"}%
                  </div>
                </div>
              </div>

              <div className="mt-3 flex flex-wrap gap-2">
                <button
                  type="button"
                  onClick={() => applyRec(selectedId)}
                  className="flex-1 rounded-xl bg-gradient-to-r from-indigo-600 to-violet-600 px-3 py-2 text-[11px] font-bold text-white shadow-md shadow-indigo-500/25 transition-transform hover:-translate-y-px"
                >
                  Apply to {selected.name}
                </button>
                <button
                  type="button"
                  onClick={() => {
                    patchCtrl(selectedId, { plan: { cycle: selected.plan.cycle, splits: { ...selected.plan.splits }, offset: selected.plan.offset } });
                    pushLog(`Stored plan restored at ${selected.name}`, "info");
                  }}
                  className="rounded-xl border border-slate-200 px-3 py-2 text-[11px] font-semibold text-slate-500 transition-colors hover:border-slate-300 dark:border-white/10 dark:text-slate-400"
                >
                  Restore stored
                </button>
              </div>
            </Panel>
          </div>

          {/* green wave */}
          <Panel>
            <PanelHeader
              title="Corridor coordination · green wave"
              subtitle="Offsets derived from link distance and progression speed"
              right={
                <label className="flex items-center gap-2 rounded-xl border border-slate-200 bg-slate-100/70 px-2.5 py-1 text-[11px] font-medium text-slate-500 dark:border-white/10 dark:bg-white/[0.05] dark:text-slate-400">
                  Progression
                  <input
                    type="range"
                    min={35}
                    max={70}
                    value={progression}
                    onChange={(e) => setProgression(Number(e.target.value))}
                    className="range w-24"
                  />
                  <span className="w-12 text-right font-bold text-slate-700 tnum dark:text-slate-200">{progression} km/h</span>
                </label>
              }
            />
            <div className="mt-4 space-y-3">
              {Array.from(new Set(SIGNALS.map((s) => s.corridorId))).map((cid) => {
                const members = SIGNALS.filter((s) => s.corridorId === cid);
                const maxChain = Math.max(...members.map((m) => m.chainMeters));
                const on = !!waves[cid];
                return (
                  <div key={cid} className="rounded-2xl border border-slate-200/80 p-3 dark:border-white/[0.07]">
                    <div className="flex flex-wrap items-center justify-between gap-2">
                      <span className="text-xs font-bold text-slate-800 dark:text-slate-100">{members[0].corridor}</span>
                      <div className="flex items-center gap-2">
                        <span className="text-[10px] text-slate-400 tnum dark:text-slate-500">
                          {(maxChain / 1000).toFixed(1)} km · {members.length} signals
                        </span>
                        <Toggle label={on ? "Armed" : "Independent"} on={on} onClick={() => toggleWave(cid)} />
                      </div>
                    </div>
                    <div className="relative mt-3 h-12">
                      <div className="absolute inset-x-0 top-5 h-1 rounded-full bg-slate-200 dark:bg-white/10" />
                      {on && (
                        <div
                          className="absolute top-3.5 h-4 rounded-full bg-emerald-400/25 blur-[2px]"
                          style={{
                            width: `${(120 / maxChain) * 100}%`,
                            left: `${((simTime * (progression / 3.6)) % maxChain / maxChain) * 100}%`,
                            transition: "left 220ms linear",
                          }}
                        />
                      )}
                      {members.map((m) => {
                        const c = controls[m.id];
                        const ph = phaseAt(c.plan, c.mode, simTime);
                        const green = ph.phase === "N" || ph.phase === "S";
                        const left = (m.chainMeters / maxChain) * 100;
                        return (
                          <button
                            key={m.id}
                            type="button"
                            onClick={() => setSelectedId(m.id)}
                            title={`${m.name} · offset ${c.plan.offset}s`}
                            className="absolute -translate-x-1/2 text-center"
                            style={{ left: `${left}%`, top: 0 }}
                          >
                            <span
                              className={cn(
                                "mx-auto block h-6 w-6 rounded-lg border-2 transition-colors duration-200",
                                c.mode === "flash"
                                  ? "border-rose-400 bg-rose-400/20"
                                  : green
                                    ? "border-emerald-400 bg-emerald-400/25"
                                    : "border-slate-300 bg-slate-200/60 dark:border-white/15 dark:bg-white/[0.06]",
                              )}
                            />
                            <span className="mt-0.5 block whitespace-nowrap text-[9px] font-medium text-slate-400 dark:text-slate-500">
                              {c.plan.offset}s
                            </span>
                          </button>
                        );
                      })}
                    </div>
                  </div>
                );
              })}
            </div>
          </Panel>

          {/* event log */}
          <Panel>
            <PanelHeader title="Controller event log" subtitle="Operator actions and AI retimings" />
            <ul className="mt-3 max-h-[220px] space-y-1.5 overflow-y-auto pr-1">
              {log.map((l) => (
                <li key={l.id} className="flex items-start gap-2 rounded-lg border border-slate-100 px-2.5 py-1.5 dark:border-white/[0.06]">
                  <span className="shrink-0 text-[10px] font-bold text-slate-400 tnum dark:text-slate-500">{l.clock}</span>
                  <span className={cn("text-[11px] font-medium", LOG_TONE[l.kind])}>{l.msg}</span>
                </li>
              ))}
            </ul>
          </Panel>
        </div>
      </div>
    </div>
  );
}

const SIGNAL_MAP = Object.fromEntries(SIGNALS.map((s) => [s.id, s])) as Record<string, SignalDef>;

/* --------------------------- small controls --------------------------- */

function Slider({
  label,
  value,
  min,
  max,
  step,
  unit,
  onChange,
  hint,
  accent,
}: {
  label: string;
  value: number;
  min: number;
  max: number;
  step: number;
  unit: string;
  onChange: (v: number) => void;
  hint?: string;
  accent?: string;
}) {
  return (
    <div>
      <div className="flex items-baseline justify-between gap-2">
        <span className="text-[11px] font-semibold text-slate-600 dark:text-slate-300">{label}</span>
        <span className="text-[11px] font-bold tnum" style={{ color: accent ?? "#6366f1" }}>
          {value.toFixed(step < 1 ? 1 : 0)}
          {unit}
        </span>
      </div>
      <input
        type="range"
        min={min}
        max={max}
        step={step}
        value={value}
        onChange={(e) => onChange(Number(e.target.value))}
        className="range mt-1 w-full"
        style={accent ? ({ accentColor: accent } as React.CSSProperties) : undefined}
      />
      {hint && <div className="mt-0.5 text-[10px] text-slate-400 dark:text-slate-500">{hint}</div>}
    </div>
  );
}

function Toggle({ label, on, onClick }: { label: string; on: boolean; onClick: () => void }) {
  return (
    <button
      type="button"
      onClick={onClick}
      className={cn(
        "inline-flex items-center gap-1.5 rounded-xl border px-2.5 py-1 text-[10px] font-bold transition-colors",
        on
          ? "border-emerald-300 bg-emerald-50 text-emerald-700 dark:border-emerald-400/30 dark:bg-emerald-500/10 dark:text-emerald-300"
          : "border-slate-200 text-slate-400 dark:border-white/10 dark:text-slate-500",
      )}
    >
      <span className={cn("h-1.5 w-1.5 rounded-full", on ? "bg-emerald-500" : "bg-slate-300 dark:bg-white/20")} />
      {label}
    </button>
  );
}
