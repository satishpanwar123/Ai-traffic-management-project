import { useMemo, useState } from "react";
import { HOUR_LABELS, SEGMENT_MAP, type DayRecord } from "../data/trafficData";
import { useMeasure } from "../hooks/useChartHooks";

const WEEKDAYS = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"];

const STOPS: { t: number; c: [number, number, number] }[] = [
  { t: 0, c: [16, 185, 129] },
  { t: 0.34, c: [132, 204, 22] },
  { t: 0.55, c: [250, 204, 21] },
  { t: 0.72, c: [249, 115, 22] },
  { t: 1, c: [225, 29, 72] },
];

function colorFor(t: number): string {
  const v = Math.max(0, Math.min(1, t));
  let a = STOPS[0];
  let b = STOPS[STOPS.length - 1];
  for (let i = 0; i < STOPS.length - 1; i++) {
    if (v >= STOPS[i].t && v <= STOPS[i + 1].t) {
      a = STOPS[i];
      b = STOPS[i + 1];
      break;
    }
  }
  const f = (v - a.t) / (b.t - a.t || 1);
  const c = a.c.map((ch, i) => Math.round(ch + (b.c[i] - ch) * f));
  return `rgb(${c[0]} ${c[1]} ${c[2]})`;
}

interface Cell {
  speedRatio: number;
  volume: number;
}

export function CongestionHeatmap({ records }: { records: DayRecord[] }) {
  const [hover, setHover] = useState<{ r: number; c: number; x: number; y: number } | null>(null);
  const [ref, { width }] = useMeasure<HTMLDivElement>();

  const { grid } = useMemo(() => {
    const sums: Cell[][] = Array.from({ length: 7 }, () =>
      Array.from({ length: 24 }, () => ({ speedRatio: 0, volume: 0 })),
    );
    for (const r of records) {
      const seg = SEGMENT_MAP[r.segmentId];
      if (!seg) continue;
      const wd = (new Date(r.ts).getDay() + 6) % 7;
      for (let h = 0; h < 24; h++) {
        const v = r.hVolume[h];
        const cell = sums[wd][h];
        cell.speedRatio += (r.hSpeed[h] / seg.freeFlow) * v;
        cell.volume += v;
      }
    }
    let maxRatio = 0;
    const grid = sums.map((row) =>
      row.map((cell) => {
        const ratio = cell.volume ? cell.speedRatio / cell.volume : 0;
        maxRatio = Math.max(maxRatio, 1 - ratio);
        return { ratio, volume: cell.volume };
      }),
    );
    return { grid, maxRatio };
  }, [records]);

  const w = Math.max(320, width || 720);
  const compact = w < 620;

  const hoveredCell = hover ? grid[hover.r]?.[hover.c] : null;

  return (
    <div className="relative" ref={ref}>
      <div className="overflow-x-auto">
        <div className="min-w-[520px]">
          <div className="grid grid-cols-[42px_repeat(24,minmax(0,1fr))] gap-[3px]">
            <div />
            {HOUR_LABELS.map((l, h) => (
              <div
                key={l}
                className="text-center text-[8px] font-medium text-slate-400 dark:text-slate-500"
              >
                {h % (compact ? 6 : 3) === 0 ? String(h).padStart(2, "0") : ""}
              </div>
            ))}

            {grid.map((row, r) => (
              <div key={WEEKDAYS[r]} className="contents">
                <div className="flex items-center justify-end pr-1.5 text-[9px] font-semibold text-slate-400 dark:text-slate-500">
                  {WEEKDAYS[r]}
                </div>
                {row.map((cell, c) => {
                  const congestion = 1 - cell.ratio;
                  return (
                    <button
                      key={c}
                      type="button"
                      onPointerEnter={(e) => {
                        const rect = e.currentTarget.getBoundingClientRect();
                        const host = e.currentTarget.closest(".relative")?.getBoundingClientRect();
                        setHover({
                          r,
                          c,
                          x: rect.left - (host?.left ?? 0) + rect.width / 2,
                          y: rect.top - (host?.top ?? 0),
                        });
                      }}
                      onPointerLeave={() => setHover(null)}
                      className="h-[18px] rounded-[3px] transition-all duration-200 hover:z-10 hover:scale-[1.35] hover:ring-2 hover:ring-slate-900/20 dark:hover:ring-white/40"
                      style={{
                        background: colorFor(congestion / 0.62),
                        opacity: cell.volume ? 1 : 0.12,
                      }}
                      aria-label={`${WEEKDAYS[r]} ${HOUR_LABELS[c]} congestion ${(congestion * 100).toFixed(0)}%`}
                    />
                  );
                })}
              </div>
            ))}
          </div>
        </div>
      </div>

      {hover && hoveredCell && (
        <div
          className="pointer-events-none absolute z-30 -translate-x-1/2 -translate-y-full rounded-lg border border-slate-200 bg-white px-2.5 py-1.5 text-[11px] shadow-xl dark:border-white/10 dark:bg-ink-800"
          style={{ left: hover.x, top: hover.y - 6 }}
        >
          <div className="font-semibold text-slate-700 dark:text-slate-200">
            {WEEKDAYS[hover.r]} · {HOUR_LABELS[hover.c]}
          </div>
          <div className="text-slate-500 tnum dark:text-slate-400">
            flow efficiency {(hoveredCell.ratio * 100).toFixed(0)}% of free-flow ·{" "}
            {fmtV(hoveredCell.volume)} veh
          </div>
        </div>
      )}

      <div className="mt-3 flex flex-wrap items-center justify-between gap-2">
        <div className="flex items-center gap-2 text-[10px] font-medium text-slate-400 dark:text-slate-500">
          <span>Free-flow</span>
          <span
            className="h-2 w-28 rounded-full"
            style={{ background: `linear-gradient(90deg, ${colorFor(0)}, ${colorFor(0.35)}, ${colorFor(0.6)}, ${colorFor(1)})` }}
          />
          <span>Gridlock</span>
        </div>
        <span className="text-[10px] text-slate-400 dark:text-slate-500">
          Cell = volume-weighted flow efficiency · hover for detail
        </span>
      </div>
    </div>
  );
}

function fmtV(n: number) {
  if (n >= 1e6) return `${(n / 1e6).toFixed(2)}M`;
  if (n >= 1e3) return `${(n / 1e3).toFixed(0)}k`;
  return Math.round(n).toString();
}
