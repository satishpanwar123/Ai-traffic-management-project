import { useEffect, useMemo, useState } from "react";
import { STATUS_DOT, fmtCompact, type CorridorRow } from "../data/trafficData";
import { useTweenArray } from "../hooks/useChartHooks";
import { Segmented } from "./ui";
import { cn } from "../utils/cn";

type Metric = "saved" | "vehicles" | "congestion";

const METRICS: { key: Metric; label: string; unit: string; pick: (r: CorridorRow) => number; fmt: (n: number) => string }[] = [
  {
    key: "saved",
    label: "Time saved",
    unit: "veh-hours",
    pick: (r) => r.vehicleHoursSaved,
    fmt: (n) => `${fmtCompact(n)} h`,
  },
  { key: "vehicles", label: "Throughput", unit: "vehicles", pick: (r) => r.vehicles, fmt: (n) => fmtCompact(n) },
  { key: "congestion", label: "Congestion", unit: "index", pick: (r) => r.congestion, fmt: (n) => n.toFixed(0) },
];

const BAR_COLOR: Record<CorridorRow["status"], string> = {
  Optimized: "#10b981",
  Watch: "#f59e0b",
  Congested: "#f97316",
  Critical: "#f43f5e",
};

const ACTIONS = [
  "Green split retimed",
  "Ramp meter recalibrated",
  "Transit priority granted",
  "Adaptive speed limit",
  "Queue spillback cleared",
  "Emergency pre-emption",
  "Pedestrian phase extended",
];

export function CorridorRanking({
  rows,
  allRows,
  activeIds,
  onToggle,
}: {
  rows: CorridorRow[];
  /** full catalogue (all corridors) so excluded rows stay clickable */
  allRows: CorridorRow[];
  activeIds: string[];
  onToggle: (id: string) => void;
}) {
  const [metric, setMetric] = useState<Metric>("saved");
  const m = METRICS.find((x) => x.key === metric)!;

  const catalogue = useMemo(() => {
    if (allRows.length >= rows.length) return allRows;
    const extra = allRows.filter((r) => !rows.some((x) => x.id === r.id));
    return [...rows, ...extra];
  }, [rows, allRows]);

  const sorted = useMemo(
    () => [...catalogue].sort((a, b) => m.pick(b) - m.pick(a)),
    [catalogue, m],
  );

  const values = useMemo(() => sorted.map((r) => m.pick(r)), [sorted, m]);
  const tw = useTweenArray(values, 700);
  const max = Math.max(...values, 1);

  return (
    <div>
      <div className="mb-3 flex items-center justify-between gap-2">
        <Segmented
          size="sm"
          options={METRICS.map((x) => ({ key: x.key, label: x.label }))}
          value={metric}
          onChange={setMetric}
        />
        <span className="text-[10px] font-medium uppercase tracking-wider text-slate-400">{m.unit}</span>
      </div>

      <ul className="space-y-2">
        {sorted.map((r, i) => {
          const off = !activeIds.includes(r.id);
          return (
            <li key={r.id}>
              <button
                type="button"
                onClick={() => onToggle(r.id)}
                title={off ? "Add to filters" : "Remove from filters"}
                className={cn(
                  "group flex w-full items-center gap-3 rounded-xl px-2 py-1.5 text-left transition-all duration-300",
                  off ? "opacity-40 hover:opacity-70" : "hover:bg-slate-100/70 dark:hover:bg-white/[0.05]",
                )}
              >
                <span className={cn("h-2 w-2 shrink-0 rounded-full", STATUS_DOT[r.status])} />
                <span className="w-[104px] shrink-0 truncate text-[11px] font-semibold text-slate-700 dark:text-slate-200 sm:w-[120px]">
                  {r.short}
                </span>
                <span className="relative h-3.5 min-w-0 flex-1 overflow-hidden rounded-full bg-slate-200/60 dark:bg-white/[0.07]">
                  <span
                    className="absolute inset-y-0 left-0 rounded-full transition-[width,opacity] duration-300"
                    style={{
                      width: `${((tw[i] ?? 0) / max) * 100}%`,
                      background: `linear-gradient(90deg, ${BAR_COLOR[r.status]}aa, ${BAR_COLOR[r.status]})`,
                    }}
                  />
                </span>
                <span className="w-[62px] shrink-0 text-right text-[11px] font-semibold text-slate-800 tnum dark:text-slate-100">
                  {m.fmt(values[i] ?? 0)}
                </span>
              </button>
            </li>
          );
        })}
      </ul>

      <p className="mt-3 text-[10px] leading-relaxed text-slate-400 dark:text-slate-500">
        Tip: click a corridor to toggle it in the active filters — every card, chart and table row
        recomputes instantly.
      </p>
    </div>
  );
}

/* ------------------------- AI control plane ------------------------- */

function hash(str: string) {
  let h = 2166136261;
  for (let i = 0; i < str.length; i++) {
    h ^= str.charCodeAt(i);
    h = Math.imul(h, 16777619);
  }
  return Math.abs(h);
}

export function AiControlPlane({
  accuracy,
  resolutionRate,
  delaySavedSec,
  interventions,
  corridors,
  dayCount,
}: {
  accuracy: number;
  resolutionRate: number;
  delaySavedSec: number;
  interventions: number;
  corridors: CorridorRow[];
  dayCount: number;
}) {
  const [phase, setPhase] = useState(0);
  useEffect(() => {
    const t = setInterval(() => setPhase((p) => (p + 1) % 3), 2400);
    return () => clearInterval(t);
  }, []);

  const gauges = [
    { label: "Prediction accuracy", value: accuracy, display: `${(accuracy * 100).toFixed(1)}%`, color: "#6366f1" },
    { label: "Incident auto-clearance", value: resolutionRate, display: `${(resolutionRate * 100).toFixed(0)}%`, color: "#22d3ee" },
    { label: "Delay recovery vs baseline", value: Math.min(1, delaySavedSec / 120), display: `${delaySavedSec.toFixed(0)} s/veh`, color: "#34d399" },
  ];

  const feed = useMemo(() => {
    const top = [...corridors].sort((a, b) => b.interventions - a.interventions).slice(0, 4);
    return top.map((c, i) => {
      const h = hash(c.id + c.district);
      return {
        id: c.id,
        corridor: c.short,
        action: ACTIONS[(h + i * 3) % ACTIONS.length],
        detail:
          i % 3 === 0
            ? `cycle ${68 + (h % 24)}s · ${40 + (h % 30)}% green extension`
            : i % 3 === 1
              ? `${(h % 400) + 120} → ${(h % 400) + 220} veh/h`
              : `confidence ${(88 + (h % 11)).toFixed(0)}%`,
        gain: `${(c.delaySavedSec * (0.8 + ((h % 40) / 100))).toFixed(0)} s saved`,
        status: c.status,
      };
    });
  }, [corridors]);

  const perDay = dayCount ? interventions / dayCount : 0;

  return (
    <div className="flex h-full flex-col">
      <div className="space-y-3">
        {gauges.map((g) => (
          <div key={g.label}>
            <div className="mb-1 flex items-baseline justify-between gap-2">
              <span className="text-[11px] font-medium text-slate-500 dark:text-slate-400">{g.label}</span>
              <span className="text-xs font-bold text-slate-800 tnum dark:text-slate-100">{g.display}</span>
            </div>
            <div className="h-1.5 overflow-hidden rounded-full bg-slate-200/70 dark:bg-white/[0.08]">
              <div
                className="h-full rounded-full transition-[width] duration-700 ease-out"
                style={{ width: `${Math.min(100, g.value * 100)}%`, background: g.color }}
              />
            </div>
          </div>
        ))}
      </div>

      {/* adaptive signal cycle animation */}
      <div className="mt-4 rounded-xl border border-slate-200/80 bg-slate-50/70 p-3 dark:border-white/[0.07] dark:bg-white/[0.03]">
        <div className="mb-2 flex items-center justify-between">
          <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400">
            Adaptive cycle · live
          </span>
          <span className="flex items-center gap-1 text-[10px] font-semibold text-emerald-600 dark:text-emerald-400">
            <span className="relative flex h-1.5 w-1.5">
              <span className="live-dot absolute h-full w-full rounded-full bg-emerald-400" />
              <span className="relative h-1.5 w-1.5 rounded-full bg-emerald-500" />
            </span>
            streaming
          </span>
        </div>
        <div className="grid grid-cols-3 gap-2">
          {["N ↔ S", "E ↔ W", "Ped"].map((lbl, i) => (
            <div key={lbl} className="text-center">
              <div className="h-1.5 overflow-hidden rounded-full bg-slate-200 dark:bg-white/10">
                <div
                  className="h-full rounded-full transition-all duration-[2200ms] ease-in-out"
                  style={{
                    width: phase === i ? "100%" : phase === (i + 1) % 3 ? "38%" : "14%",
                    background: phase === i ? "#10b981" : phase === (i + 1) % 3 ? "#f59e0b" : "#94a3b8",
                  }}
                />
              </div>
              <span className="mt-1 block text-[9px] font-medium text-slate-400">{lbl}</span>
            </div>
          ))}
        </div>
      </div>

      <div className="mt-4 min-h-0 flex-1">
        <div className="mb-2 flex items-center justify-between">
          <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400">
            Recent AI decisions
          </span>
          <span className="text-[10px] font-semibold text-slate-400 tnum dark:text-slate-500">
            {perDay.toFixed(0)}/day
          </span>
        </div>
        <ul className="space-y-1.5">
          {feed.map((f) => (
            <li
              key={f.id}
              className="flex items-center gap-2 rounded-lg border border-slate-100 px-2 py-1.5 transition-colors hover:border-indigo-200 dark:border-white/[0.06] dark:hover:border-indigo-400/25"
            >
              <span className={cn("h-1.5 w-1.5 shrink-0 rounded-full", STATUS_DOT[f.status])} />
              <div className="min-w-0 flex-1">
                <div className="truncate text-[11px] font-semibold text-slate-700 dark:text-slate-200">
                  {f.action} · {f.corridor}
                </div>
                <div className="truncate text-[10px] text-slate-400 dark:text-slate-500">{f.detail}</div>
              </div>
              <span className="shrink-0 text-[10px] font-semibold text-emerald-600 tnum dark:text-emerald-400">
                {f.gain}
              </span>
            </li>
          ))}
        </ul>
      </div>
    </div>
  );
}
