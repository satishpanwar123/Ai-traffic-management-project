import type { ReactNode } from "react";
import { useCountUp } from "../hooks/useChartHooks";
import { Sparkline } from "./Sparkline";
import { cn } from "../utils/cn";
import { Delta } from "./ui";

export interface KpiDef {
  key: string;
  label: string;
  value: number;
  format: (n: number) => string;
  delta: number;
  invert?: boolean;
  spark: number[];
  color: string;
  icon: ReactNode;
  sub: ReactNode;
}

export function KpiCard({ kpi, delay = 0 }: { kpi: KpiDef; delay?: number }) {
  const animated = useCountUp(kpi.value, 850);

  return (
    <article
      className="panel panel-hover group relative overflow-hidden p-4 animate-rise"
      style={{ animationDelay: `${delay}ms` }}
    >
      <div
        className="pointer-events-none absolute -right-10 -top-14 h-32 w-32 rounded-full opacity-[0.13] blur-2xl transition-opacity duration-500 group-hover:opacity-25"
        style={{ background: kpi.color }}
      />
      <div className="flex items-start justify-between gap-2">
        <div className="flex items-center gap-2.5">
          <span
            className="flex h-9 w-9 items-center justify-center rounded-xl text-white shadow-sm"
            style={{ background: `linear-gradient(140deg, ${kpi.color}, ${kpi.color}b3)` }}
          >
            {kpi.icon}
          </span>
          <span className="text-xs font-semibold uppercase tracking-wider text-slate-500 dark:text-slate-400">
            {kpi.label}
          </span>
        </div>
        <Delta value={kpi.delta} invert={kpi.invert} />
      </div>

      <div className="mt-3 flex items-end justify-between gap-3">
        <span className="text-[26px] font-bold leading-none tracking-tight text-slate-900 tnum dark:text-white">
          {kpi.format(animated)}
        </span>
      </div>

      <div className="mt-1.5 text-[11px] leading-relaxed text-slate-500 dark:text-slate-400">{kpi.sub}</div>

      <div className="mt-2 -mx-1">
        <Sparkline values={kpi.spark} color={kpi.color} height={40} />
      </div>

      <div
        className={cn(
          "absolute inset-x-0 bottom-0 h-[2.5px] origin-left scale-x-0 transition-transform duration-500 group-hover:scale-x-100",
        )}
        style={{ background: `linear-gradient(90deg, ${kpi.color}00, ${kpi.color}, ${kpi.color}00)` }}
      />
    </article>
  );
}
