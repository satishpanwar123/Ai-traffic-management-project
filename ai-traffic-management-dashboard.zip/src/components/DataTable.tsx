import { useEffect, useMemo, useState } from "react";
import {
  STATUS_DOT,
  STATUS_STYLES,
  fmtCompact,
  fmtInt,
  type CorridorRow,
} from "../data/trafficData";
import { cn } from "../utils/cn";

type SortKey =
  | "name"
  | "vehicles"
  | "avgSpeed"
  | "travelTime"
  | "congestion"
  | "interventions"
  | "incidents"
  | "vehicleHoursSaved"
  | "co2SavedKg"
  | "status";

interface Column {
  key: SortKey;
  label: string;
  align?: "left" | "right";
  sortable?: boolean;
  width?: string;
  hideBelow?: string;
}

const COLUMNS: Column[] = [
  { key: "name", label: "Corridor", align: "left", sortable: true },
  { key: "vehicles", label: "Vehicles", align: "right", sortable: true },
  { key: "avgSpeed", label: "Avg speed", align: "right", sortable: true },
  { key: "travelTime", label: "Travel time", align: "right", sortable: true, hideBelow: "lg" },
  { key: "congestion", label: "Congestion", align: "right", sortable: true },
  { key: "interventions", label: "AI actions", align: "right", sortable: true, hideBelow: "md" },
  { key: "incidents", label: "Incidents", align: "right", sortable: true, hideBelow: "lg" },
  { key: "vehicleHoursSaved", label: "Hours saved", align: "right", sortable: true, hideBelow: "xl" },
  { key: "co2SavedKg", label: "CO₂ saved", align: "right", sortable: true, hideBelow: "xl" },
  { key: "status", label: "Status", align: "right", sortable: true },
];

const STATUS_ORDER: Record<CorridorRow["status"], number> = {
  Critical: 0,
  Congested: 1,
  Watch: 2,
  Optimized: 3,
};

const STATUS_FILTERS = ["All", "Optimized", "Watch", "Congested", "Critical"] as const;

export function DataTable({ rows }: { rows: CorridorRow[] }) {
  const [sortKey, setSortKey] = useState<SortKey>("congestion");
  const [dir, setDir] = useState<"asc" | "desc">("desc");
  const [query, setQuery] = useState("");
  const [status, setStatus] = useState<(typeof STATUS_FILTERS)[number]>("All");
  const [pageSize, setPageSize] = useState(8);
  const [page, setPage] = useState(0);

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();
    return rows.filter((r) => {
      const matchQ =
        !q || r.name.toLowerCase().includes(q) || r.district.toLowerCase().includes(q) || r.kind.toLowerCase().includes(q);
      const matchS = status === "All" || r.status === status;
      return matchQ && matchS;
    });
  }, [rows, query, status]);

  const sorted = useMemo(() => {
    const arr = [...filtered];
    arr.sort((a, b) => {
      let av: number | string;
      let bv: number | string;
      if (sortKey === "name") {
        av = a.name;
        bv = b.name;
      } else if (sortKey === "status") {
        av = STATUS_ORDER[a.status];
        bv = STATUS_ORDER[b.status];
      } else {
        av = a[sortKey] as number;
        bv = b[sortKey] as number;
      }
      if (typeof av === "string" && typeof bv === "string") {
        return dir === "asc" ? av.localeCompare(bv) : bv.localeCompare(av);
      }
      return dir === "asc" ? (av as number) - (bv as number) : (bv as number) - (av as number);
    });
    return arr;
  }, [filtered, sortKey, dir]);

  const pageCount = Math.max(1, Math.ceil(sorted.length / pageSize));
  const safePage = Math.min(page, pageCount - 1);
  const visible = sorted.slice(safePage * pageSize, safePage * pageSize + pageSize);

  useEffect(() => setPage(0), [query, status, pageSize, rows]);

  const maxVehicles = Math.max(...rows.map((r) => r.vehicles), 1);
  const maxCongestion = 100;

  const onSort = (key: SortKey) => {
    if (key === sortKey) setDir((d) => (d === "asc" ? "desc" : "asc"));
    else {
      setSortKey(key);
      setDir(key === "name" ? "asc" : "desc");
    }
  };

  const exportCsv = () => {
    const head = [
      "Corridor", "District", "Type", "Vehicles", "Avg speed (km/h)", "Travel time (min)",
      "Congestion index", "AI actions", "Incidents", "Resolution rate", "Vehicle-hours saved",
      "CO2 saved (kg)", "Status",
    ];
    const body = sorted.map((r) =>
      [
        r.name, r.district, r.kind, Math.round(r.vehicles), r.avgSpeed.toFixed(1),
        r.travelTime.toFixed(1), r.congestion.toFixed(1), Math.round(r.interventions),
        r.incidents, `${(r.resolutionRate * 100).toFixed(1)}%`, Math.round(r.vehicleHoursSaved),
        r.co2SavedKg.toFixed(0), r.status,
      ].join(","),
    );
    const blob = new Blob([[head.join(","), ...body].join("\n")], { type: "text/csv;charset=utf-8" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = "flowgrid-corridor-performance.csv";
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div>
      {/* toolbar */}
      <div className="mb-3 flex flex-wrap items-center justify-between gap-2">
        <div className="flex flex-1 flex-wrap items-center gap-2">
          <div className="relative min-w-[170px] flex-1 sm:max-w-[240px]">
            <svg viewBox="0 0 24 24" className="pointer-events-none absolute left-2.5 top-1/2 h-3.5 w-3.5 -translate-y-1/2 text-slate-400" fill="none" stroke="currentColor" strokeWidth={2} strokeLinecap="round">
              <circle cx="11" cy="11" r="7" />
              <path d="m20 20-3.5-3.5" />
            </svg>
            <input
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="Search corridor or district…"
              className="w-full rounded-xl border border-slate-200 bg-slate-100/60 py-1.5 pl-8 pr-2 text-xs text-slate-700 outline-none transition-colors placeholder:text-slate-400 focus:border-indigo-400 focus:bg-white dark:border-white/10 dark:bg-white/[0.04] dark:text-slate-200 dark:focus:border-indigo-400/60 dark:focus:bg-white/[0.07]"
            />
          </div>

          <div className="flex flex-wrap gap-1">
            {STATUS_FILTERS.map((s) => (
              <button
                key={s}
                type="button"
                onClick={() => setStatus(s)}
                className={cn(
                  "chip",
                  status === s
                    ? "border-indigo-300 bg-indigo-50 text-indigo-700 dark:border-indigo-400/40 dark:bg-indigo-500/15 dark:text-indigo-200"
                    : "border-slate-200 text-slate-500 hover:border-slate-300 dark:border-white/10 dark:text-slate-400",
                )}
              >
                {s !== "All" && <span className={cn("h-1.5 w-1.5 rounded-full", STATUS_DOT[s])} />}
                {s}
              </button>
            ))}
          </div>
        </div>

        <button
          type="button"
          onClick={exportCsv}
          className="inline-flex items-center gap-1.5 rounded-xl border border-slate-200 px-2.5 py-1.5 text-[11px] font-semibold text-slate-600 transition-colors hover:border-indigo-300 hover:text-indigo-600 dark:border-white/10 dark:text-slate-300 dark:hover:border-indigo-400/40 dark:hover:text-indigo-200"
        >
          <svg viewBox="0 0 24 24" className="h-3.5 w-3.5" fill="none" stroke="currentColor" strokeWidth={2} strokeLinecap="round" strokeLinejoin="round">
            <path d="M12 3v12m0 0 4-4m-4 4-4-4M4 19h16" />
          </svg>
          Export CSV
        </button>
      </div>

      {/* table */}
      <div className="-mx-4 overflow-x-auto px-4 sm:mx-0 sm:px-0">
        <table className="w-full min-w-[720px] border-separate border-spacing-0 text-left">
          <thead>
            <tr>
              {COLUMNS.map((c) => (
                <th
                  key={c.key}
                  scope="col"
                  className={cn(
                    "whitespace-nowrap border-b border-slate-200 bg-slate-50/80 px-3 py-2.5 text-[10px] font-bold uppercase tracking-wider text-slate-500 first:rounded-tl-xl last:rounded-tr-xl dark:border-white/[0.08] dark:bg-white/[0.03] dark:text-slate-400",
                    c.align === "right" ? "text-right" : "text-left",
                    c.hideBelow === "md" && "hidden md:table-cell",
                    c.hideBelow === "lg" && "hidden lg:table-cell",
                    c.hideBelow === "xl" && "hidden xl:table-cell",
                  )}
                >
                  <button
                    type="button"
                    onClick={() => onSort(c.key)}
                    className={cn(
                      "inline-flex items-center gap-1 transition-colors hover:text-indigo-600 dark:hover:text-indigo-300",
                      sortKey === c.key && "text-indigo-600 dark:text-indigo-300",
                    )}
                  >
                    {c.label}
                    <svg
                      viewBox="0 0 24 24"
                      className={cn(
                        "h-3 w-3 transition-all duration-200",
                        sortKey === c.key ? "opacity-100" : "opacity-25",
                        sortKey === c.key && dir === "asc" ? "rotate-180" : "",
                      )}
                      fill="none"
                      stroke="currentColor"
                      strokeWidth={2.6}
                      strokeLinecap="round"
                      strokeLinejoin="round"
                    >
                      <path d="m6 9 6 6 6-6" />
                    </svg>
                  </button>
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {visible.map((r, i) => (
              <tr
                key={r.id}
                className="group transition-colors hover:bg-indigo-50/50 dark:hover:bg-white/[0.035]"
                style={{ animation: `rise 0.35s cubic-bezier(0.16,1,0.3,1) ${i * 22}ms both` }}
              >
                {/* corridor */}
                <td className="border-b border-slate-100 px-3 py-2.5 dark:border-white/[0.05]">
                  <div className="flex items-center gap-2.5">
                    <span className={cn("h-8 w-1 shrink-0 rounded-full", STATUS_DOT[r.status])} />
                    <div className="min-w-0">
                      <div className="truncate text-xs font-semibold text-slate-800 dark:text-slate-100">
                        {r.name}
                      </div>
                      <div className="truncate text-[10px] text-slate-400 dark:text-slate-500">
                        {r.district} · {r.kind} · {r.lanes} lanes · {r.lengthKm} km
                      </div>
                    </div>
                  </div>
                </td>

                <td className="border-b border-slate-100 px-3 py-2.5 text-right dark:border-white/[0.05]">
                  <div className="text-xs font-semibold text-slate-800 tnum dark:text-slate-100">
                    {fmtCompact(r.vehicles)}
                  </div>
                  <div className="mt-1 ml-auto h-1 w-14 overflow-hidden rounded-full bg-slate-200/70 dark:bg-white/10">
                    <div
                      className="h-full rounded-full bg-indigo-500 transition-[width] duration-700"
                      style={{ width: `${(r.vehicles / maxVehicles) * 100}%` }}
                    />
                  </div>
                </td>

                <td className="border-b border-slate-100 px-3 py-2.5 text-right dark:border-white/[0.05]">
                  <span className="text-xs font-semibold text-slate-800 tnum dark:text-slate-100">
                    {r.avgSpeed.toFixed(1)}
                  </span>
                  <span className="ml-1 text-[10px] text-slate-400">km/h</span>
                </td>

                <td className="hidden border-b border-slate-100 px-3 py-2.5 text-right lg:table-cell dark:border-white/[0.05]">
                  <span className="text-xs font-medium text-slate-700 tnum dark:text-slate-200">
                    {r.travelTime.toFixed(1)} min
                  </span>
                  <div className="text-[10px] text-emerald-600 tnum dark:text-emerald-400">
                    −{(r.baselineTravelTime - r.travelTime).toFixed(1)} vs baseline
                  </div>
                </td>

                <td className="border-b border-slate-100 px-3 py-2.5 text-right dark:border-white/[0.05]">
                  <div className="flex items-center justify-end gap-2">
                    <span className="hidden h-1.5 w-16 overflow-hidden rounded-full bg-slate-200/70 dark:bg-white/10 sm:block">
                      <span
                        className={cn(
                          "block h-full rounded-full transition-[width] duration-700",
                          r.congestion > 70 ? "bg-rose-500" : r.congestion > 55 ? "bg-orange-500" : r.congestion > 42 ? "bg-amber-400" : "bg-emerald-500",
                        )}
                        style={{ width: `${(r.congestion / maxCongestion) * 100}%` }}
                      />
                    </span>
                    <span className="text-xs font-semibold text-slate-800 tnum dark:text-slate-100">
                      {r.congestion.toFixed(0)}
                    </span>
                  </div>
                </td>

                <td className="hidden border-b border-slate-100 px-3 py-2.5 text-right md:table-cell dark:border-white/[0.05]">
                  <span className="text-xs font-medium text-slate-700 tnum dark:text-slate-200">
                    {fmtInt(r.interventions)}
                  </span>
                </td>

                <td className="hidden border-b border-slate-100 px-3 py-2.5 text-right lg:table-cell dark:border-white/[0.05]">
                  <div className="text-xs font-medium text-slate-700 tnum dark:text-slate-200">
                    {fmtInt(r.incidents)}
                  </div>
                  <div className="text-[10px] text-slate-400 tnum dark:text-slate-500">
                    {(r.resolutionRate * 100).toFixed(0)}% cleared
                  </div>
                </td>

                <td className="hidden border-b border-slate-100 px-3 py-2.5 text-right xl:table-cell dark:border-white/[0.05]">
                  <span className="text-xs font-medium text-slate-700 tnum dark:text-slate-200">
                    {fmtCompact(r.vehicleHoursSaved)} h
                  </span>
                </td>

                <td className="hidden border-b border-slate-100 px-3 py-2.5 text-right xl:table-cell dark:border-white/[0.05]">
                  <span className="text-xs font-medium text-emerald-600 tnum dark:text-emerald-400">
                    {(r.co2SavedKg / 1000).toFixed(2)} t
                  </span>
                </td>

                <td className="border-b border-slate-100 px-3 py-2.5 text-right dark:border-white/[0.05]">
                  <span className={cn("chip justify-center", STATUS_STYLES[r.status])}>{r.status}</span>
                </td>
              </tr>
            ))}

            {visible.length === 0 && (
              <tr>
                <td colSpan={COLUMNS.length} className="px-3 py-10 text-center text-xs text-slate-400">
                  No corridors match “{query}”.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>

      {/* footer */}
      <div className="mt-3 flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-2 text-[11px] text-slate-500 dark:text-slate-400">
          <span className="tnum">
            {sorted.length === 0 ? 0 : safePage * pageSize + 1}–{Math.min(sorted.length, (safePage + 1) * pageSize)} of{" "}
            {sorted.length} corridors
          </span>
          <select
            value={pageSize}
            onChange={(e) => setPageSize(Number(e.target.value))}
            className="cursor-pointer rounded-lg border border-slate-200 bg-white px-1.5 py-0.5 text-[11px] font-medium text-slate-600 outline-none dark:border-white/10 dark:bg-white/[0.05] dark:text-slate-300"
          >
            {[5, 8, 20, 100].map((n) => (
              <option key={n} value={n}>
                {n === 100 ? "All" : `${n} / page`}
              </option>
            ))}
          </select>
        </div>

        <div className="flex items-center gap-1.5">
          <button
            type="button"
            disabled={safePage === 0}
            onClick={() => setPage(safePage - 1)}
            className="rounded-lg border border-slate-200 px-2 py-1 text-[11px] font-semibold text-slate-500 transition-colors disabled:opacity-35 enabled:hover:border-indigo-300 enabled:hover:text-indigo-600 dark:border-white/10 dark:text-slate-400"
          >
            Prev
          </button>
          <span className="px-1 text-[11px] font-semibold text-slate-500 tnum dark:text-slate-400">
            {safePage + 1}/{pageCount}
          </span>
          <button
            type="button"
            disabled={safePage >= pageCount - 1}
            onClick={() => setPage(safePage + 1)}
            className="rounded-lg border border-slate-200 px-2 py-1 text-[11px] font-semibold text-slate-500 transition-colors disabled:opacity-35 enabled:hover:border-indigo-300 enabled:hover:text-indigo-600 dark:border-white/10 dark:text-slate-400"
          >
            Next
          </button>
        </div>
      </div>
    </div>
  );
}


