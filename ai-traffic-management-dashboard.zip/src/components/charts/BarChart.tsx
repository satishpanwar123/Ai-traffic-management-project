import { useMemo, useState } from "react";
import { useMeasure, useTweenArray } from "../../hooks/useChartHooks";
import { ChartTooltip, Legend, type TooltipDatum } from "../ui";
import { niceTicks, shortNum } from "./chartMath";

export interface BarSeries {
  key: string;
  label: string;
  color: string;
  values: number[];
  format?: (v: number) => string;
}

const PAD = { top: 18, right: 14, bottom: 30, left: 44 };

export function BarChart({
  labels,
  series,
  height = 280,
  mode = "grouped",
  valueFormat = (v: number) => shortNum(v),
  axisFormat = (v: number) => shortNum(v),
  unit,
  peakRanges,
  tickStride,
}: {
  labels: string[];
  series: BarSeries[];
  height?: number;
  mode?: "grouped" | "stacked";
  valueFormat?: (v: number) => string;
  axisFormat?: (v: number) => string;
  unit?: string;
  peakRanges?: [number, number][];
  tickStride?: number;
}) {
  const [ref, { width }] = useMeasure<HTMLDivElement>();
  const [hover, setHover] = useState<number | null>(null);

  const n = labels.length;
  const flatAll = useMemo(() => series.flatMap((s) => s.values), [series]);
  const twFlat = useTweenArray(flatAll, 700);
  const tweened = useMemo(() => {
    const out: number[][] = [];
    let o = 0;
    for (const s of series) {
      out.push(twFlat.slice(o, o + s.values.length));
      o += s.values.length;
    }
    return out;
  }, [twFlat, series]);

  const w = Math.max(320, width || 640);
  const innerW = w - PAD.left - PAD.right;
  const innerH = height - PAD.top - PAD.bottom;

  const totals = useMemo(
    () =>
      Array.from({ length: n }, (_, i) =>
        series.reduce((acc, s) => acc + (s.values[i] ?? 0), 0),
      ),
    [series, n],
  );

  const scale = useMemo(() => {
    const vals = mode === "stacked" ? totals : series.flatMap((s) => s.values);
    const max = vals.length ? Math.max(...vals) : 1;
    return niceTicks(0, (max || 1) * 1.12, 4);
  }, [series, totals, mode, n]);

  const yAt = (v: number) => PAD.top + innerH - ((v - scale.min) / (scale.max - scale.min || 1)) * innerH;
  const band = n ? innerW / n : innerW;
  const groupPad = Math.min(12, band * 0.22);
  const barW = mode === "stacked" ? Math.max(3, band - groupPad) : Math.max(2, (band - groupPad) / Math.max(1, series.length));

  const stride = tickStride ?? (w < 420 ? 6 : w < 620 ? 4 : w < 900 ? 3 : 2);

  const rows: TooltipDatum[] =
    hover === null
      ? []
      : series.map((s) => ({
          label: s.label,
          value: (s.format ?? valueFormat)(s.values[hover] ?? 0),
          color: s.color,
        }));

  const delta =
    hover !== null && series.length === 2 && (series[1].values[hover] ?? 0) > 0
      ? ((series[0].values[hover] - series[1].values[hover]) / series[1].values[hover]) * 100
      : null;

  return (
    <div className="relative w-full" ref={ref}>
      <svg
        width={w}
        height={height}
        className="overflow-visible touch-none select-none"
        onPointerMove={(e) => {
          const rect = e.currentTarget.getBoundingClientRect();
          const mx = e.clientX - rect.left;
          const idx = Math.floor((mx - PAD.left) / band);
          setHover(idx >= 0 && idx < n ? idx : null);
        }}
        onPointerLeave={() => setHover(null)}
      >
        {scale.ticks.map((t) => (
          <g key={t}>
            <line
              x1={PAD.left}
              x2={w - PAD.right}
              y1={yAt(t)}
              y2={yAt(t)}
              className="stroke-slate-200/80 dark:stroke-white/[0.07]"
              strokeWidth={1}
              strokeDasharray={t === 0 ? undefined : "3 4"}
            />
            <text x={PAD.left - 8} y={yAt(t) + 3.5} textAnchor="end" className="fill-slate-400 text-[10px] dark:fill-slate-500">
              {axisFormat(t)}
            </text>
          </g>
        ))}
        {unit && (
          <text x={PAD.left - 8} y={PAD.top - 7} textAnchor="end" className="fill-slate-400 text-[9px] uppercase tracking-wider dark:fill-slate-500">
            {unit}
          </text>
        )}

        {/* peak shading */}
        {(peakRanges ?? []).map(([a, b], i) => (
          <rect
            key={i}
            x={PAD.left + a * band}
            y={PAD.top}
            width={(b - a + 1) * band}
            height={innerH}
            className="fill-amber-400/[0.07] dark:fill-amber-300/[0.06]"
            rx={8}
          />
        ))}

        {/* hover column */}
        {hover !== null && (
          <rect
            x={PAD.left + hover * band}
            y={PAD.top - 4}
            width={band}
            height={innerH + 4}
            rx={8}
            className="fill-slate-500/[0.07] dark:fill-white/[0.05]"
          />
        )}

        {Array.from({ length: n }, (_, i) => {
          const x0 = PAD.left + i * band;
          const base = PAD.top + innerH;
          const isHover = hover === i;
          return (
            <g key={i}>
              {mode === "stacked"
                ? (() => {
                    let acc = 0;
                    return series.map((s, si) => {
                      const v = tweened[si]?.[i] ?? 0;
                      const y1 = yAt(acc);
                      const y2 = yAt(acc + v);
                      acc += v;
                      return (
                        <rect
                          key={s.key}
                          x={x0 + groupPad / 2}
                          y={Math.min(y1, y2)}
                          width={barW}
                          height={Math.max(0, Math.abs(y2 - y1))}
                          rx={Math.min(4, barW / 2.4)}
                          fill={s.color}
                          opacity={hover === null || isHover ? 1 : 0.42}
                          className="transition-opacity duration-200"
                        />
                      );
                    });
                  })()
                : series.map((s, si2) => {
                    const v = tweened[si2]?.[i] ?? 0;
                    const h = Math.max(0, base - yAt(v));
                    return (
                      <rect
                        key={s.key}
                        x={x0 + groupPad / 2 + si2 * barW}
                        y={base - h}
                        width={barW - 1.5}
                        height={h}
                        rx={Math.min(4, (barW - 1.5) / 2.4)}
                        fill={s.color}
                        opacity={hover === null || isHover ? 1 : 0.42}
                        className="transition-opacity duration-200"
                      />
                    );
                  })}
              {i % stride === 0 && (
                <text x={x0 + band / 2} y={height - 9} textAnchor="middle" className="fill-slate-400 text-[10px] dark:fill-slate-500">
                  {labels[i]}
                </text>
              )}
            </g>
          );
        })}
      </svg>

      {hover !== null && (
        <ChartTooltip
          x={PAD.left + hover * band + band / 2}
          y={PAD.top + 6}
          width={w}
          title={labels[hover]}
          rows={rows}
          footer={
            delta !== null ? (
              <span>
                AI intervention effect:{" "}
                <b className={delta <= 0 ? "text-emerald-600 dark:text-emerald-400" : "text-rose-500"}>
                  {delta <= 0 ? "" : "+"}
                  {delta.toFixed(1)}%
                </b>{" "}
                vs baseline
              </span>
            ) : undefined
          }
        />
      )}

      <div className="mt-2">
        <Legend items={series.map((s) => ({ key: s.key, label: s.label, color: s.color }))} />
      </div>
    </div>
  );
}
