export interface Pt {
  x: number;
  y: number;
}

/** Smooth cardinal-spline path through points. */
export function linePath(pts: Pt[], tension = 0.18): string {
  if (pts.length === 0) return "";
  if (pts.length < 3) return `M ${pts.map((p) => `${p.x},${p.y}`).join(" L ")}`;
  let d = `M ${pts[0].x},${pts[0].y}`;
  for (let i = 0; i < pts.length - 1; i++) {
    const p0 = pts[i - 1] ?? pts[i];
    const p1 = pts[i];
    const p2 = pts[i + 1];
    const p3 = pts[i + 2] ?? p2;
    const c1x = p1.x + (p2.x - p0.x) * tension;
    const c1y = p1.y + (p2.y - p0.y) * tension;
    const c2x = p2.x - (p3.x - p1.x) * tension;
    const c2y = p2.y - (p3.y - p1.y) * tension;
    d += ` C ${c1x.toFixed(2)},${c1y.toFixed(2)} ${c2x.toFixed(2)},${c2y.toFixed(2)} ${p2.x.toFixed(2)},${p2.y.toFixed(2)}`;
  }
  return d;
}

export function niceTicks(min: number, max: number, count = 5) {
  if (!isFinite(min) || !isFinite(max)) return { min: 0, max: 1, ticks: [0, 1] };
  if (min === max) {
    if (min === 0) {
      min = 0;
      max = 1;
    } else {
      min = min * 0.9;
      max = max * 1.1;
    }
  }
  const span = max - min;
  const step0 = span / Math.max(1, count);
  const mag = Math.pow(10, Math.floor(Math.log10(step0 || 1)));
  const norm = step0 / mag;
  const step = (norm <= 1 ? 1 : norm <= 2 ? 2 : norm <= 2.5 ? 2.5 : norm <= 5 ? 5 : 10) * mag;
  const nMin = Math.floor(min / step) * step;
  const nMax = Math.ceil(max / step) * step;
  const ticks: number[] = [];
  for (let v = nMin; v <= nMax + step * 0.5; v += step) ticks.push(Number(v.toFixed(6)));
  return { min: nMin, max: nMax, ticks };
}

/** SVG donut arc path. */
export function arcPath(
  cx: number,
  cy: number,
  rOuter: number,
  rInner: number,
  start: number,
  end: number,
): string {
  const full = end - start >= Math.PI * 2 - 1e-6;
  const a0 = start;
  const a1 = full ? start + Math.PI * 2 - 1e-4 : end;
  const large = a1 - a0 > Math.PI ? 1 : 0;
  const x = (r: number, a: number) => cx + r * Math.cos(a - Math.PI / 2);
  const y = (r: number, a: number) => cy + r * Math.sin(a - Math.PI / 2);
  if (full) {
    return [
      `M ${x(rOuter, a0)},${y(rOuter, a0)}`,
      `A ${rOuter},${rOuter} 0 ${large} 1 ${x(rOuter, a1)},${y(rOuter, a1)}`,
      `L ${x(rInner, a1)},${y(rInner, a1)}`,
      `A ${rInner},${rInner} 0 ${large} 0 ${x(rInner, a0)},${y(rInner, a0)}`,
      "Z",
    ].join(" ");
  }
  return [
    `M ${x(rOuter, a0)},${y(rOuter, a0)}`,
    `A ${rOuter},${rOuter} 0 ${large} 1 ${x(rOuter, a1)},${y(rOuter, a1)}`,
    `L ${x(rInner, a1)},${y(rInner, a1)}`,
    `A ${rInner},${rInner} 0 ${large} 0 ${x(rInner, a0)},${y(rInner, a0)}`,
    "Z",
  ].join(" ");
}

export function shortNum(n: number, digits = 1): string {
  const abs = Math.abs(n);
  if (abs >= 1e9) return `${(n / 1e9).toFixed(digits)}B`;
  if (abs >= 1e6) return `${(n / 1e6).toFixed(digits)}M`;
  if (abs >= 1e4) return `${(n / 1e3).toFixed(0)}k`;
  if (abs >= 1e3) return `${(n / 1e3).toFixed(digits)}k`;
  if (abs >= 100) return n.toFixed(0);
  if (abs >= 10) return n.toFixed(digits === 1 ? 1 : 0);
  return n.toFixed(abs < 1 ? 2 : 1);
}

/** Pick evenly spaced tick indices for an x axis. */
export function pickTicks(len: number, desired: number): number[] {
  if (len <= 0) return [];
  const n = Math.max(2, Math.min(desired, len));
  const step = (len - 1) / (n - 1);
  const out = new Set<number>();
  for (let i = 0; i < n; i++) out.add(Math.round(i * step));
  if (out.size && len > 1) out.add(len - 1);
  return Array.from(out).sort((a, b) => a - b);
}
