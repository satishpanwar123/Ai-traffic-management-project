import { useId, useMemo, useState } from "react";
import { useMeasure, useTweenArray } from "../../hooks/useChartHooks";
import { ChartTooltip, Legend, type TooltipDatum } from "../ui";
import { linePath, niceTicks, pickTicks, shortNum, type Pt } from "./chartMath";

export interface LineSeries {
  key: string;
  label: string;
  color: string;
  values: number[];
  axis?: "left" | "right";
  kind?: "area" | "line";
  dashed?: boolean;
  format?: (v: number) => string;
}

const PAD = { top: 16, right: 52, bottom: 28, left: 46 };

export function LineChart({
  labels,
  series,
  height = 300,
  leftFormat = (v: number) => shortNum(v),
  rightFormat = (v: number) => v.toFixed(0),
  leftUnit,
  rightUnit,
  tickCount,
}: {
  labels: string[];
  series: LineSeries[];
  height?: number;
  leftFormat?: (v: number) => string;
  rightFormat?: (v: number) => string;
  leftUnit?: string;
  rightUnit?: string;
  tickCount?: number;
}) {
  const uid = useId().replace(/[:]/g, "");
  const [ref, { width }] = useMeasure<HTMLDivElement>();
  const [hover, setHover] = useState<number | null>(null);
  const [hidden, setHidden] = useState<Set<string>>(new Set());

  const visible = series.filter((s) => !hidden.has(s.key));
  const n = labels.length;

  // tween every series in one flat pass so filter changes morph smoothly
  const flatAll = useMemo(() => series.flatMap((s) => s.values), [series]);
  const twFlat = useTweenArray(flatAll, 700);
  const tweened = useMemo(() => {
    const out: number[][] = [];
    let o = 0;
    for (const s of series) {
      out.push(twFlat.slice(o, o + s.values.length));
      o += s.values.length;
    }
    return out;
  }, [twFlat, series]);

  const flat = useMemo(() => visible.flatMap((s) => s.values), [visible]);

  const w = Math.max(320, width || 640);
  const innerW = w - PAD.left - PAD.right;
  const innerH = height - PAD.top - PAD.bottom;

  const rightSeries = visible.filter((s) => s.axis === "right");
  const leftSeries = visible.filter((s) => s.axis !== "right");

  const scaleL = useMemo(() => {
    const vals = leftSeries.flatMap((s) => s.values).filter((v) => Number.isFinite(v));
    const max = vals.length ? Math.max(...vals) : 1;
    const min = vals.length ? Math.min(...vals, 0) : 0;
    return niceTicks(min, max * 1.06 || 1, 5);
  }, [leftSeries]);

  const scaleR = useMemo(() => {
    const vals = rightSeries.flatMap((s) => s.values).filter((v) => Number.isFinite(v));
    if (!vals.length) return { min: 0, max: 1, ticks: [] as number[] };
    let min = Math.min(...vals);
    let max = Math.max(...vals);
    const pad = (max - min) * 0.35 || Math.max(1, max * 0.2);
    return niceTicks(Math.max(0, min - pad), max + pad, 4);
  }, [rightSeries]);

  const xAt = (i: number) => (n <= 1 ? PAD.left + innerW / 2 : PAD.left + (i / (n - 1)) * innerW);
  const yL = (v: number) => PAD.top + innerH - ((v - scaleL.min) / (scaleL.max - scaleL.min || 1)) * innerH;
  const yR = (v: number) => PAD.top + innerH - ((v - scaleR.min) / (scaleR.max - scaleR.min || 1)) * innerH;

  const xTicks = useMemo(
    () => pickTicks(n, tickCount ?? (w < 520 ? 4 : w < 800 ? 6 : 8)),
    [n, w, tickCount],
  );

  const handleMove = (e: React.PointerEvent<SVGSVGElement>) => {
    const rect = e.currentTarget.getBoundingClientRect();
    const mx = e.clientX - rect.left;
    if (n === 0) return;
    const step = n > 1 ? innerW / (n - 1) : 0;
    const idx = Math.round((mx - PAD.left) / (step || 1));
    setHover(Math.max(0, Math.min(n - 1, idx)));
  };

  const tooltipRows: TooltipDatum[] =
    hover === null
      ? []
      : visible.map((s) => ({
          label: s.label,
          value: (s.format ?? (s.axis === "right" ? rightFormat : leftFormat))(s.values[hover] ?? 0),
          color: s.color,
        }));

  return (
    <div className="relative w-full" ref={ref}>
      {n === 0 || flat.length === 0 ? (
        <div
          className="flex items-center justify-center rounded-xl border border-dashed border-slate-200 text-xs text-slate-400 dark:border-white/10 dark:text-slate-500"
          style={{ height }}
        >
          No data for the selected filters
        </div>
      ) : (
        <>
          <svg
            width={w}
            height={height}
            className="overflow-visible touch-none select-none"
            onPointerMove={handleMove}
            onPointerLeave={() => setHover(null)}
          >
            <defs>
              {series.map((s) => (
                <linearGradient key={s.key} id={`${uid}-${s.key}`} x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor={s.color} stopOpacity={0.32} />
                  <stop offset="65%" stopColor={s.color} stopOpacity={0.08} />
                  <stop offset="100%" stopColor={s.color} stopOpacity={0} />
                </linearGradient>
              ))}
            </defs>

            {/* horizontal grid + left axis */}
            {scaleL.ticks.map((t) => (
              <g key={`gl-${t}`}>
                <line
                  x1={PAD.left}
                  x2={w - PAD.right}
                  y1={yL(t)}
                  y2={yL(t)}
                  className="stroke-slate-200/80 dark:stroke-white/[0.07]"
                  strokeWidth={1}
                  strokeDasharray={t === scaleL.min ? undefined : "3 4"}
                />
                <text
                  x={PAD.left - 8}
                  y={yL(t) + 3.5}
                  textAnchor="end"
                  className="fill-slate-400 text-[10px] dark:fill-slate-500"
                >
                  {leftFormat(t)}
                </text>
              </g>
            ))}
            {leftUnit && (
              <text x={PAD.left - 8} y={PAD.top - 6} textAnchor="end" className="fill-slate-400 text-[9px] uppercase tracking-wider dark:fill-slate-500">
                {leftUnit}
              </text>
            )}

            {/* right axis */}
            {rightSeries.length > 0 &&
              scaleR.ticks.map((t) => (
                <text
                  key={`gr-${t}`}
                  x={w - PAD.right + 8}
                  y={yR(t) + 3.5}
                  textAnchor="start"
                  className="fill-slate-400 text-[10px] dark:fill-slate-500"
                >
                  {rightFormat(t)}
                </text>
              ))}
            {rightSeries.length > 0 && rightUnit && (
              <text
                x={w - PAD.right + 8}
                y={PAD.top - 6}
                textAnchor="start"
                className="fill-slate-400 text-[9px] uppercase tracking-wider dark:fill-slate-500"
              >
                {rightUnit}
              </text>
            )}

            {/* x labels */}
            {xTicks.map((i) => (
              <text
                key={`x-${i}`}
                x={xAt(i)}
                y={height - 8}
                textAnchor={i === 0 ? "start" : i === n - 1 ? "end" : "middle"}
                className="fill-slate-400 text-[10px] dark:fill-slate-500"
              >
                {labels[i]}
              </text>
            ))}

            {/* crosshair */}
            {hover !== null && (
              <line
                x1={xAt(hover)}
                x2={xAt(hover)}
                y1={PAD.top - 6}
                y2={PAD.top + innerH}
                className="stroke-slate-400/70 dark:stroke-slate-500/70"
                strokeWidth={1}
                strokeDasharray="4 3"
              />
            )}

            {/* series */}
            {series.map((s, si) => {
              if (hidden.has(s.key)) return null;
              const tw = tweened[si] ?? s.values;
              const pts: Pt[] = tw.map((v, i) => ({ x: xAt(i), y: s.axis === "right" ? yR(v) : yL(v) }));
              const d = linePath(pts);
              return (
                <g key={s.key}>
                  {s.kind !== "line" && (
                    <path
                      d={`${d} L ${xAt(n - 1)},${PAD.top + innerH} L ${xAt(0)},${PAD.top + innerH} Z`}
                      fill={`url(#${uid}-${s.key})`}
                      className="transition-opacity duration-300"
                    />
                  )}
                  {n < 2 ? (
                    pts.map((p, pi) => (
                      <circle key={`pt-${pi}`} cx={p.x} cy={p.y} r={4.5} fill={s.color} stroke="white" strokeWidth={1.5} className="dark:stroke-ink-900" />
                    ))
                  ) : (
                    <path
                      d={d}
                      fill="none"
                      stroke={s.color}
                      strokeWidth={2.25}
                      strokeLinecap="round"
                      strokeDasharray={s.dashed ? "5 4" : undefined}
                      style={{ filter: `drop-shadow(0 6px 12px ${s.color}33)` }}
                    />
                  )}
                  {hover !== null && pts[hover] && (
                    <g>
                      <circle cx={pts[hover].x} cy={pts[hover].y} r={7} fill={s.color} opacity={0.18} />
                      <circle
                        cx={pts[hover].x}
                        cy={pts[hover].y}
                        r={3.6}
                        fill={s.color}
                        stroke="white"
                        strokeWidth={1.6}
                        className="dark:stroke-ink-900"
                      />
                    </g>
                  )}
                </g>
              );
            })}
          </svg>

          {hover !== null && (
            <ChartTooltip
              x={xAt(hover)}
              y={PAD.top + 10}
              width={w}
              title={labels[hover]}
              rows={tooltipRows}
              footer={rightSeries.length > 0 ? `${leftUnit ?? "left"} · ${rightUnit ?? "right"} axes` : undefined}
            />
          )}

          <div className="mt-2 flex items-center justify-between gap-3">
            <Legend
              items={series.map((s) => ({ key: s.key, label: s.label, color: s.color, dashed: s.dashed }))}
              hidden={hidden}
              onToggle={(k) =>
                setHidden((prev) => {
                  const next = new Set(prev);
                  if (next.has(k)) next.delete(k);
                  else if (next.size < series.length - 1) next.add(k);
                  return next;
                })
              }
            />
          </div>
        </>
      )}
    </div>
  );
}
