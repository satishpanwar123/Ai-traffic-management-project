import { useMemo, useState } from "react";
import { useTweenArray } from "../../hooks/useChartHooks";
import { arcPath } from "./chartMath";

export interface DonutSlice {
  key: string;
  label: string;
  color: string;
  value: number;
  hint?: string;
}

export function DonutChart({
  data,
  size = 200,
  thickness = 26,
  centerLabel,
  valueFormat,
  subFormat,
}: {
  data: DonutSlice[];
  size?: number;
  thickness?: number;
  centerLabel: string;
  valueFormat: (v: number) => string;
  subFormat?: (v: number) => string;
}) {
  const [hover, setHover] = useState<string | null>(null);

  const target = useMemo(() => data.map((d) => d.value), [data]);
  const tw = useTweenArray(target, 700);

  const total = target.reduce((a, b) => a + b, 0);
  const twTotal = tw.reduce((a, b) => a + b, 0) || 1;
  const cx = size / 2;
  const cy = size / 2;
  const rOuter = size / 2 - 4;
  const rInner = rOuter - thickness;

  const active = hover ? data.find((d) => d.key === hover) : null;
  const activeIdx = active ? data.findIndex((d) => d.key === active.key) : -1;

  let angle = 0;
  const arcs = data.map((d, i) => {
    const frac = total ? d.value / total : 0;
    const span = frac * Math.PI * 2;
    const pad = span > 0.02 ? 0.012 : 0;
    const start = angle + pad;
    const end = angle + span - pad;
    angle += span;
    return { d, i, start, end, frac, hovered: i === activeIdx };
  });

  return (
    <div className="flex flex-col items-center gap-4 sm:flex-row sm:items-center sm:gap-5">
      <div className="relative shrink-0" style={{ width: size, height: size }}>
        <svg width={size} height={size} className="touch-none select-none">
          {arcs.map(({ d, start, end, hovered }) => (
            <path
              key={d.key}
              d={arcPath(cx, cy, hovered ? rOuter + 5 : rOuter, rInner, start, Math.max(start + 0.0001, end))}
              fill={d.color}
              opacity={hover === null || hovered ? 1 : 0.34}
              className="cursor-pointer transition-opacity duration-200"
              onPointerEnter={() => setHover(d.key)}
              onPointerLeave={() => setHover(null)}
            />
          ))}
        </svg>
        <div className="pointer-events-none absolute inset-0 flex flex-col items-center justify-center text-center">
          <span className="text-[10px] font-semibold uppercase tracking-wider text-slate-400 dark:text-slate-500">
            {active ? active.label : centerLabel}
          </span>
          <span className="text-xl font-bold tracking-tight text-slate-900 tnum dark:text-white">
            {valueFormat(active ? active.value : total)}
          </span>
          <span className="text-[11px] text-slate-500 tnum dark:text-slate-400">
            {active
              ? `${((active.value / (total || 1)) * 100).toFixed(1)}% of total`
              : (subFormat ? subFormat(total) : "vehicles observed")}
          </span>
        </div>
      </div>

      <ul className="w-full min-w-0 space-y-1.5">
        {arcs.map(({ d, frac, i }) => (
          <li
            key={d.key}
            onPointerEnter={() => setHover(d.key)}
            onPointerLeave={() => setHover(null)}
            className="group flex cursor-pointer items-center gap-2.5 rounded-lg px-2 py-1.5 transition-colors hover:bg-slate-100/80 dark:hover:bg-white/[0.05]"
            style={{ opacity: hover === null || activeIdx === i ? 1 : 0.5 }}
          >
            <span className="h-2.5 w-2.5 shrink-0 rounded-full" style={{ background: d.color }} />
            <span className="min-w-0 flex-1 truncate text-xs font-medium text-slate-600 dark:text-slate-300">
              {d.label}
            </span>
            <span className="hidden min-[420px]:block h-1.5 w-16 overflow-hidden rounded-full bg-slate-200/80 dark:bg-white/10 sm:w-20">
              <span
                className="block h-full rounded-full transition-[width] duration-700 ease-out"
                style={{ width: `${(tw[i] / twTotal) * 100}%`, background: d.color }}
              />
            </span>
            <span className="w-14 text-right text-xs font-semibold text-slate-900 tnum dark:text-slate-100">
              {valueFormat(d.value)}
            </span>
            <span className="w-10 text-right text-[11px] text-slate-400 tnum dark:text-slate-500">
              {(frac * 100).toFixed(0)}%
            </span>
          </li>
        ))}
      </ul>
    </div>
  );
}
