import { useId, useMemo } from "react";
import { useTweenArray } from "../hooks/useChartHooks";
import { linePath, type Pt } from "./charts/chartMath";

export function Sparkline({
  values,
  color,
  height = 42,
  strokeWidth = 2,
  showArea = true,
}: {
  values: number[];
  color: string;
  height?: number;
  strokeWidth?: number;
  showArea?: boolean;
}) {
  const uid = useId().replace(/[:]/g, "");
  const target = useMemo(() => values, [values]);
  const tw = useTweenArray(target, 800);

  const W = 160;
  const H = height;
  const pad = 4;
  const min = Math.min(...target);
  const max = Math.max(...target);
  const span = max - min || 1;

  const pts: Pt[] = tw.map((v, i) => ({
    x: target.length > 1 ? pad + (i / (target.length - 1)) * (W - pad * 2) : W / 2,
    y: H - pad - ((v - min) / span) * (H - pad * 2),
  }));

  const d = linePath(pts, 0.16);

  return (
    <svg width="100%" height={H} viewBox={`0 0 ${W} ${H}`} preserveAspectRatio="none" className="overflow-visible">
      <defs>
        <linearGradient id={`sp-${uid}`} x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor={color} stopOpacity={0.34} />
          <stop offset="100%" stopColor={color} stopOpacity={0} />
        </linearGradient>
      </defs>
      {showArea && (
        <path
          d={`${d} L ${pts[pts.length - 1]?.x ?? W}, ${H} L ${pts[0]?.x ?? 0}, ${H} Z`}
          fill={`url(#sp-${uid})`}
        />
      )}
      <path d={d} fill="none" stroke={color} strokeWidth={strokeWidth} strokeLinecap="round" vectorEffect="non-scaling-stroke" />
      {pts.length > 0 && (
        <circle cx={pts[pts.length - 1].x} cy={pts[pts.length - 1].y} r={2.6} fill={color} />
      )}
    </svg>
  );
}
