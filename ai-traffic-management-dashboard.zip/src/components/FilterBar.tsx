import { useEffect, useRef, useState } from "react";
import {
  DAY_META,
  DISTRICTS,
  SEGMENTS,
  VEHICLE_TYPES,
  fmtCompact,
  type VehicleKey,
} from "../data/trafficData";
import { Segmented } from "./ui";
import { cn } from "../utils/cn";

export type RangeKey = "7d" | "14d" | "30d" | "90d" | "custom";

export interface FilterState {
  startISO: string;
  endISO: string;
  segmentIds: string[];
  vehicle: "all" | VehicleKey;
}

const RANGE_DAYS: Record<Exclude<RangeKey, "custom">, number> = {
  "7d": 7,
  "14d": 14,
  "30d": 30,
  "90d": 90,
};

function rangeKeyFor(startISO: string, endISO: string): RangeKey {
  const s = DAY_META.find((d) => d.dateISO === startISO);
  const e = DAY_META.find((d) => d.dateISO === endISO);
  if (!s || !e) return "custom";
  const len = e.dayIndex - s.dayIndex + 1;
  const endsToday = e.dateISO === DAY_META[DAY_META.length - 1].dateISO;
  for (const [k, days] of Object.entries(RANGE_DAYS)) {
    if (endsToday && len === days) return k as Exclude<RangeKey, "custom">;
  }
  return "custom";
}

export function FilterBar({
  state,
  onChange,
  onReset,
}: {
  state: FilterState;
  onChange: (next: FilterState) => void;
  onReset: () => void;
}) {
  const [open, setOpen] = useState(false);
  const wrapRef = useRef<HTMLDivElement>(null);
  const bounds = { min: DAY_META[0].dateISO, max: DAY_META[DAY_META.length - 1].dateISO };
  const activeRange = rangeKeyFor(state.startISO, state.endISO);
  const allSelected = state.segmentIds.length === SEGMENTS.length;

  useEffect(() => {
    if (!open) return;
    const onDown = (e: MouseEvent) => {
      if (!wrapRef.current?.contains(e.target as Node)) setOpen(false);
    };
    const onEsc = (e: KeyboardEvent) => e.key === "Escape" && setOpen(false);
    document.addEventListener("mousedown", onDown);
    document.addEventListener("keydown", onEsc);
    return () => {
      document.removeEventListener("mousedown", onDown);
      document.removeEventListener("keydown", onEsc);
    };
  }, [open]);

  const setRange = (key: RangeKey) => {
    if (key === "custom") return;
    const days = RANGE_DAYS[key];
    const end = DAY_META[DAY_META.length - 1];
    const start = DAY_META[Math.max(0, DAY_META.length - days)];
    onChange({ ...state, startISO: start.dateISO, endISO: end.dateISO });
  };

  const toggleSegment = (id: string) => {
    const has = state.segmentIds.includes(id);
    const next = has ? state.segmentIds.filter((s) => s !== id) : [...state.segmentIds, id];
    onChange({ ...state, segmentIds: next.length ? next : state.segmentIds });
  };

  const toggleDistrict = (district: string) => {
    const ids = SEGMENTS.filter((s) => s.district === district).map((s) => s.id);
    const allIn = ids.every((id) => state.segmentIds.includes(id));
    const next = allIn
      ? state.segmentIds.filter((id) => !ids.includes(id))
      : Array.from(new Set([...state.segmentIds, ...ids]));
    onChange({ ...state, segmentIds: next.length ? next : state.segmentIds });
  };

  const coveredVehicles = SEGMENTS.filter((s) => state.segmentIds.includes(s.id)).length;

  return (
    <div className="panel flex flex-col gap-3 p-3 lg:sticky lg:top-[72px] lg:z-30 lg:flex-row lg:items-center lg:justify-between lg:gap-4 lg:backdrop-blur-xl">
      {/* date range */}
      <div className="flex flex-wrap items-center gap-2 sm:gap-3">
        <div className="flex items-center gap-1.5 text-[11px] font-semibold uppercase tracking-wider text-slate-400 dark:text-slate-500">
          <span className="relative flex h-2 w-2">
            <span className="live-dot absolute inline-flex h-full w-full rounded-full bg-emerald-400" />
            <span className="relative inline-flex h-2 w-2 rounded-full bg-emerald-500" />
          </span>
          Live
        </div>

        <Segmented
          size="sm"
          options={[
            { key: "7d", label: "7D" },
            { key: "14d", label: "14D" },
            { key: "30d", label: "30D" },
            { key: "90d", label: "90D" },
          ]}
          value={activeRange === "custom" ? ("" as RangeKey) : (activeRange as Exclude<RangeKey, "custom">)}
          onChange={setRange}
        />

        <div className="flex items-center gap-1.5 rounded-xl border border-slate-200 bg-slate-100/60 px-2 py-1 dark:border-white/10 dark:bg-white/[0.04]">
          <input
            type="date"
            value={state.startISO}
            min={bounds.min}
            max={state.endISO}
            onChange={(e) => onChange({ ...state, startISO: e.target.value || bounds.min })}
            className="w-[104px] bg-transparent text-[11px] font-medium text-slate-700 outline-none dark:text-slate-200 [color-scheme:light] dark:[color-scheme:dark]"
          />
          <span className="text-slate-300 dark:text-slate-600">→</span>
          <input
            type="date"
            value={state.endISO}
            min={state.startISO}
            max={bounds.max}
            onChange={(e) => onChange({ ...state, endISO: e.target.value || bounds.max })}
            className="w-[104px] bg-transparent text-[11px] font-medium text-slate-700 outline-none dark:text-slate-200 [color-scheme:light] dark:[color-scheme:dark]"
          />
        </div>
      </div>

      <div className="flex flex-wrap items-center gap-2">
        {/* vehicle segment */}
        <label className="flex items-center gap-2 rounded-xl border border-slate-200 bg-slate-100/60 px-2.5 py-1.5 text-[11px] font-medium text-slate-500 dark:border-white/10 dark:bg-white/[0.04] dark:text-slate-400">
          Road user
          <select
            value={state.vehicle}
            onChange={(e) => onChange({ ...state, vehicle: e.target.value as "all" | VehicleKey })}
            className="cursor-pointer rounded-lg bg-transparent text-[11px] font-semibold text-slate-800 outline-none dark:text-slate-100"
          >
            <option value="all">All users</option>
            {VEHICLE_TYPES.map((v) => (
              <option key={v.key} value={v.key}>
                {v.label}
              </option>
            ))}
          </select>
        </label>

        {/* corridor picker */}
        <div className="relative" ref={wrapRef}>
          <button
            type="button"
            onClick={() => setOpen((o) => !o)}
            className={cn(
              "inline-flex items-center gap-2 rounded-xl border px-3 py-1.5 text-[11px] font-semibold transition-colors",
              allSelected
                ? "border-slate-200 bg-slate-100/60 text-slate-600 hover:border-indigo-300 dark:border-white/10 dark:bg-white/[0.04] dark:text-slate-300"
                : "border-indigo-300 bg-indigo-50 text-indigo-700 dark:border-indigo-400/30 dark:bg-indigo-500/15 dark:text-indigo-200",
            )}
          >
            <svg viewBox="0 0 24 24" className="h-3.5 w-3.5" fill="none" stroke="currentColor" strokeWidth={2} strokeLinecap="round">
              <path d="M3 6h18M6 12h12M10 18h4" />
            </svg>
            Corridors
            <span
              className={cn(
                "rounded-md px-1.5 py-0.5 text-[10px] tnum",
                allSelected
                  ? "bg-white text-slate-700 dark:bg-white/10 dark:text-slate-200"
                  : "bg-indigo-600 text-white",
              )}
            >
              {coveredVehicles}/{SEGMENTS.length}
            </span>
          </button>

          {open && (
            <div className="absolute right-0 z-40 mt-2 w-[300px] animate-rise rounded-2xl border border-slate-200 bg-white p-3 shadow-2xl dark:border-white/10 dark:bg-ink-800">
              <div className="mb-2 flex items-center justify-between">
                <span className="text-[11px] font-semibold uppercase tracking-wider text-slate-400">
                  Filter corridors
                </span>
                <div className="flex gap-1.5 text-[11px] font-semibold">
                  <button
                    type="button"
                    onClick={() => onChange({ ...state, segmentIds: SEGMENTS.map((s) => s.id) })}
                    className="text-indigo-600 hover:underline dark:text-indigo-300"
                  >
                    All
                  </button>
                  <span className="text-slate-300 dark:text-slate-600">/</span>
                  <button
                    type="button"
                    onClick={() => onChange({ ...state, segmentIds: [SEGMENTS[0].id] })}
                    className="text-slate-500 hover:underline dark:text-slate-400"
                  >
                    Single
                  </button>
                </div>
              </div>

              <div className="mb-2 flex flex-wrap gap-1.5">
                {DISTRICTS.map((d) => (
                  <button
                    key={d}
                    type="button"
                    onClick={() => toggleDistrict(d)}
                    className="chip border-slate-200 text-slate-500 hover:border-indigo-300 hover:text-indigo-600 dark:border-white/10 dark:text-slate-400 dark:hover:text-indigo-300"
                  >
                    {d}
                  </button>
                ))}
              </div>

              <div className="max-h-[240px] space-y-1 overflow-y-auto pr-1">
                {SEGMENTS.map((s) => {
                  const checked = state.segmentIds.includes(s.id);
                  return (
                    <label
                      key={s.id}
                      className="flex cursor-pointer items-center gap-2.5 rounded-xl px-2 py-1.5 transition-colors hover:bg-slate-100 dark:hover:bg-white/[0.06]"
                    >
                      <span
                        className={cn(
                          "flex h-4 w-4 items-center justify-center rounded-[5px] border transition-all",
                          checked
                            ? "border-indigo-600 bg-indigo-600 text-white"
                            : "border-slate-300 bg-white dark:border-slate-600 dark:bg-transparent",
                        )}
                      >
                        {checked && (
                          <svg viewBox="0 0 24 24" className="h-3 w-3" fill="none" stroke="currentColor" strokeWidth={3.4} strokeLinecap="round" strokeLinejoin="round">
                            <path d="m5 13 4 4L19 7" />
                          </svg>
                        )}
                      </span>
                      <input
                        type="checkbox"
                        className="sr-only"
                        checked={checked}
                        onChange={() => toggleSegment(s.id)}
                      />
                      <span className="min-w-0 flex-1">
                        <span className="block truncate text-xs font-medium text-slate-700 dark:text-slate-200">
                          {s.name}
                        </span>
                        <span className="block text-[10px] text-slate-400 dark:text-slate-500">
                          {s.district} · {s.kind} · {fmtCompact(s.baseVolume)} veh/day
                        </span>
                      </span>
                    </label>
                  );
                })}
              </div>
            </div>
          )}
        </div>

        <button
          type="button"
          onClick={onReset}
          className="inline-flex items-center gap-1.5 rounded-xl border border-transparent px-2.5 py-1.5 text-[11px] font-semibold text-slate-400 transition-colors hover:bg-slate-100 hover:text-slate-700 dark:hover:bg-white/[0.06] dark:hover:text-slate-200"
        >
          <svg viewBox="0 0 24 24" className="h-3.5 w-3.5" fill="none" stroke="currentColor" strokeWidth={2} strokeLinecap="round" strokeLinejoin="round">
            <path d="M3 12a9 9 0 1 0 3-6.7M3 4v5h5" />
          </svg>
          Reset
        </button>
      </div>
    </div>
  );
}
