import { useEffect, useState, type ReactNode } from "react";
import { cn } from "../utils/cn";

/** Self-contained ticking clock so the rest of the dashboard doesn't re-render. */
export function LiveClock() {
  const [now, setNow] = useState(() => new Date());
  useEffect(() => {
    const t = setInterval(() => setNow(new Date()), 1000);
    return () => clearInterval(t);
  }, []);
  return (
    <span className="hidden text-[11px] font-semibold text-slate-400 tnum sm:inline dark:text-slate-500">
      {now.toLocaleTimeString("en-US", { hour12: false })}
    </span>
  );
}

/* ------------------------------- Panel ------------------------------- */

export function Panel({
  children,
  className,
  padded = true,
}: {
  children: ReactNode;
  className?: string;
  padded?: boolean;
}) {
  return (
    <section className={cn("panel panel-hover", padded && "p-4 sm:p-5", className)}>{children}</section>
  );
}

export function PanelHeader({
  title,
  subtitle,
  right,
  className,
}: {
  title: string;
  subtitle?: string;
  right?: ReactNode;
  className?: string;
}) {
  return (
    <header className={cn("flex flex-wrap items-start justify-between gap-3", className)}>
      <div className="min-w-0">
        <h3 className="text-[15px] font-semibold tracking-tight text-slate-900 dark:text-slate-100">
          {title}
        </h3>
        {subtitle && (
          <p className="mt-0.5 text-xs text-slate-500 dark:text-slate-400">{subtitle}</p>
        )}
      </div>
      {right && <div className="flex shrink-0 items-center gap-2">{right}</div>}
    </header>
  );
}

/* ------------------------------- Badge ------------------------------- */

export function Delta({
  value,
  invert = false,
  suffix = "",
  className,
}: {
  value: number;
  invert?: boolean;
  suffix?: string;
  className?: string;
}) {
  const flat = Math.abs(value) < 0.05;
  const good = invert ? value < 0 : value > 0;
  const tone = flat
    ? "bg-slate-100 text-slate-500 dark:bg-white/5 dark:text-slate-400"
    : good
      ? "bg-emerald-50 text-emerald-600 dark:bg-emerald-500/10 dark:text-emerald-300"
      : "bg-rose-50 text-rose-600 dark:bg-rose-500/10 dark:text-rose-300";
  const Arrow = flat
    ? "M9.5 9h5"
    : value > 0
      ? "M12 15V9m0 0-2.5 2.5M12 9l2.5 2.5"
      : "M12 9v6m0 0 2.5-2.5M12 15l-2.5-2.5";

  return (
    <span
      className={cn(
        "inline-flex items-center gap-0.5 rounded-full px-1.5 py-0.5 text-[11px] font-semibold tnum",
        tone,
        className,
      )}
    >
      <svg viewBox="0 0 24 24" className="h-3 w-3" fill="none" stroke="currentColor" strokeWidth={2.4} strokeLinecap="round" strokeLinejoin="round">
        <path d={Arrow} />
      </svg>
      {Math.abs(value).toFixed(1)}%{suffix}
    </span>
  );
}

/* ---------------------------- Segmented ----------------------------- */

export function Segmented<T extends string>({
  options,
  value,
  onChange,
  size = "md",
}: {
  options: { key: T; label: string }[];
  value: T;
  onChange: (v: T) => void;
  size?: "sm" | "md";
}) {
  return (
    <div className="inline-flex rounded-xl border border-slate-200 bg-slate-100/70 p-0.5 dark:border-white/10 dark:bg-white/[0.04]">
      {options.map((o) => {
        const active = o.key === value;
        return (
          <button
            key={o.key}
            type="button"
            onClick={() => onChange(o.key)}
            className={cn(
              "relative rounded-[10px] font-semibold transition-all duration-200",
              size === "sm" ? "px-2.5 py-1 text-[11px]" : "px-3 py-1.5 text-xs",
              active
                ? "bg-white text-slate-900 shadow-sm dark:bg-white/[0.12] dark:text-white"
                : "text-slate-500 hover:text-slate-700 dark:text-slate-400 dark:hover:text-slate-200",
            )}
          >
            {o.label}
          </button>
        );
      })}
    </div>
  );
}

/* ------------------------------ Toggle ------------------------------ */

export function ThemeToggle({ dark, onToggle }: { dark: boolean; onToggle: () => void }) {
  return (
    <button
      type="button"
      onClick={onToggle}
      aria-label={dark ? "Switch to light mode" : "Switch to dark mode"}
      title={dark ? "Switch to light mode" : "Switch to dark mode"}
      className="group relative inline-flex h-9 w-[76px] items-center rounded-full border border-slate-200 bg-slate-100 px-1 transition-colors duration-300 hover:border-indigo-300 dark:border-white/10 dark:bg-white/[0.06] dark:hover:border-indigo-400/40"
    >
      <span className="absolute right-3 text-[10px] font-bold tracking-wider text-slate-400 dark:hidden">
        DAY
      </span>
      <span className="absolute left-2.5 hidden text-[10px] font-bold tracking-wider text-slate-400 dark:inline">
        NIGHT
      </span>
      <span
        className={cn(
          "relative flex h-7 w-7 items-center justify-center rounded-full bg-white text-indigo-600 shadow-md transition-transform duration-300 ease-out dark:bg-indigo-500 dark:text-white",
          dark ? "translate-x-[42px]" : "translate-x-0",
        )}
      >
        {dark ? (
          <svg viewBox="0 0 24 24" className="h-4 w-4" fill="currentColor">
            <path d="M21 12.8A9 9 0 1 1 11.2 3a7 7 0 0 0 9.8 9.8Z" />
          </svg>
        ) : (
          <svg viewBox="0 0 24 24" className="h-4 w-4" fill="none" stroke="currentColor" strokeWidth={2} strokeLinecap="round">
            <circle cx="12" cy="12" r="4" />
            <path d="M12 2v2m0 16v2M2 12h2m16 0h2M4.9 4.9l1.4 1.4m11.4 11.4 1.4 1.4M19.1 4.9l-1.4 1.4M6.3 17.7l-1.4 1.4" />
          </svg>
        )}
      </span>
    </button>
  );
}

/* ------------------------------ Tooltip ----------------------------- */

export interface TooltipDatum {
  label: string;
  value: string;
  color?: string;
  swatch?: "line" | "dot" | "square";
}

export function ChartTooltip({
  x,
  y,
  title,
  rows,
  width,
  footer,
}: {
  x: number;
  y: number;
  title: string;
  rows: TooltipDatum[];
  width: number;
  footer?: ReactNode;
}) {
  const flip = x > width - 190;
  return (
    <div
      className="pointer-events-none absolute z-30 animate-fade rounded-xl border border-slate-200 bg-white/95 px-3 py-2 text-xs shadow-xl backdrop-blur dark:border-white/10 dark:bg-ink-800/95"
      style={{
        left: flip ? undefined : x + 14,
        right: flip ? width - x + 14 : undefined,
        top: Math.max(4, y - 10),
        minWidth: 158,
      }}
    >
      <div className="mb-1.5 text-[11px] font-semibold uppercase tracking-wider text-slate-400 dark:text-slate-500">
        {title}
      </div>
      <div className="space-y-1">
        {rows.map((r) => (
          <div key={r.label} className="flex items-center justify-between gap-4">
            <span className="flex items-center gap-1.5 text-slate-500 dark:text-slate-400">
              {r.color && (
                <span
                  className="h-2 w-2 shrink-0 rounded-full"
                  style={{ background: r.color, boxShadow: `0 0 0 3px ${r.color}22` }}
                />
              )}
              {r.label}
            </span>
            <span className="font-semibold text-slate-900 tnum dark:text-slate-100">{r.value}</span>
          </div>
        ))}
      </div>
      {footer && <div className="mt-1.5 border-t border-slate-200/70 pt-1.5 text-[11px] text-slate-500 dark:border-white/10 dark:text-slate-400">{footer}</div>}
    </div>
  );
}

/* ------------------------------ Legend ------------------------------ */

export function Legend({
  items,
  onToggle,
  hidden,
}: {
  items: { key: string; label: string; color: string; dashed?: boolean }[];
  onToggle?: (key: string) => void;
  hidden?: Set<string>;
}) {
  return (
    <div className="flex flex-wrap items-center gap-x-4 gap-y-1.5">
      {items.map((it) => {
        const off = hidden?.has(it.key);
        return (
          <button
            key={it.key}
            type="button"
            onClick={() => onToggle?.(it.key)}
            className={cn(
              "group inline-flex items-center gap-1.5 text-[11px] font-medium transition-opacity",
              off ? "opacity-35" : "opacity-100",
              onToggle && "cursor-pointer hover:opacity-80",
            )}
          >
            {it.dashed ? (
              <svg width="16" height="6">
                <line x1="0" y1="3" x2="16" y2="3" stroke={it.color} strokeWidth="2" strokeDasharray="3 3" />
              </svg>
            ) : (
              <span className="h-2 w-4 rounded-full" style={{ background: it.color }} />
            )}
            <span className="text-slate-600 dark:text-slate-300">{it.label}</span>
          </button>
        );
      })}
    </div>
  );
}
