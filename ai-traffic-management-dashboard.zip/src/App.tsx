import { useMemo, useState } from "react";
import {
  DAY_META,
  RECORDS,
  SEGMENTS,
  SEGMENT_MAP,
  VEHICLE_TYPES,
  activeDays,
  corridorRows,
  dailySeries,
  filterRecords,
  fmtCompact,
  fmtDateRange,
  fmtInt,
  fmtPct,
  hourlySeries,
  pct,
  previousWindow,
  rangeToDates,
  summarize,
  type VehicleKey,
} from "./data/trafficData";
import { useTheme } from "./hooks/useChartHooks";
import { FilterBar, type FilterState } from "./components/FilterBar";
import { KpiCard, type KpiDef } from "./components/KpiCard";
import { DataTable } from "./components/DataTable";
import { CongestionHeatmap } from "./components/CongestionHeatmap";
import { AiControlPlane, CorridorRanking } from "./components/InsightPanels";
import { LineChart } from "./components/charts/LineChart";
import { BarChart } from "./components/charts/BarChart";
import { DonutChart } from "./components/charts/DonutChart";
import { Delta, LiveClock, Panel, PanelHeader, Segmented, ThemeToggle } from "./components/ui";
import { SignalControl } from "./components/signals/SignalControl";

const ALL_IDS = SEGMENTS.map((s) => s.id);
const initial = rangeToDates(30);

const Icon = {
  cars: (
    <svg viewBox="0 0 24 24" className="h-[18px] w-[18px]" fill="none" stroke="currentColor" strokeWidth={1.9} strokeLinecap="round" strokeLinejoin="round">
      <path d="M5 17h14M4 17v-4l2-5h12l2 5v4M4 13h16" />
      <circle cx="7.5" cy="17.5" r="1.6" />
      <circle cx="16.5" cy="17.5" r="1.6" />
    </svg>
  ),
  speed: (
    <svg viewBox="0 0 24 24" className="h-[18px] w-[18px]" fill="none" stroke="currentColor" strokeWidth={1.9} strokeLinecap="round" strokeLinejoin="round">
      <path d="M4 18a8 8 0 1 1 16 0" />
      <path d="m12 14 4-4" />
      <circle cx="12" cy="18" r="1.4" />
    </svg>
  ),
  clock: (
    <svg viewBox="0 0 24 24" className="h-[18px] w-[18px]" fill="none" stroke="currentColor" strokeWidth={1.9} strokeLinecap="round" strokeLinejoin="round">
      <circle cx="12" cy="12" r="8.5" />
      <path d="M12 7.5V12l3 2" />
    </svg>
  ),
  cpu: (
    <svg viewBox="0 0 24 24" className="h-[18px] w-[18px]" fill="none" stroke="currentColor" strokeWidth={1.9} strokeLinecap="round" strokeLinejoin="round">
      <rect x="6.5" y="6.5" width="11" height="11" rx="2.5" />
      <path d="M10 3v3.5M14 3v3.5M10 17.5V21M14 17.5V21M3 10h3.5M3 14h3.5M17.5 10H21M17.5 14H21" />
    </svg>
  ),
  alert: (
    <svg viewBox="0 0 24 24" className="h-[18px] w-[18px]" fill="none" stroke="currentColor" strokeWidth={1.9} strokeLinecap="round" strokeLinejoin="round">
      <path d="M12 4.5 3.5 19h17L12 4.5Z" />
      <path d="M12 10v4M12 16.6v.2" />
    </svg>
  ),
  leaf: (
    <svg viewBox="0 0 24 24" className="h-[18px] w-[18px]" fill="none" stroke="currentColor" strokeWidth={1.9} strokeLinecap="round" strokeLinejoin="round">
      <path d="M20 4c0 8-5 12-11 12H5c0-7 5-11 11-11h4Z" />
      <path d="M4 20c2-5 6-8 11-9" />
    </svg>
  ),
};

const CORRIDOR_PALETTE = ["#6366f1", "#22d3ee", "#f59e0b", "#fb7185", "#a855f7", "#10b981"];

export default function App() {
  const { dark, toggle } = useTheme();
  const [view, setView] = useState<"overview" | "signals">("overview");
  const [vscodeGuideOpen, setVscodeGuideOpen] = useState(false);
  const [copiedCmd, setCopiedCmd] = useState(false);
  const [filters, setFilters] = useState<FilterState>({
    startISO: initial.startISO,
    endISO: initial.endISO,
    segmentIds: ALL_IDS,
    vehicle: "all",
  });

  const patch = (next: Partial<FilterState>) => setFilters((f) => ({ ...f, ...next }));

  const data = useMemo(() => {
    const days = activeDays(filters.startISO, filters.endISO);
    const prev = previousWindow(filters.startISO, filters.endISO);
    const current = filterRecords(RECORDS, {
      startISO: filters.startISO,
      endISO: filters.endISO,
      segmentIds: filters.segmentIds,
    });
    const previous = filterRecords(RECORDS, {
      startISO: prev.startISO,
      endISO: prev.endISO,
      segmentIds: filters.segmentIds,
    });
    const vehicle: "all" | VehicleKey = filters.vehicle;
    const cur = summarize(current, vehicle);
    const before = summarize(previous, vehicle);
    const series = dailySeries(current, vehicle);
    const hourly = hourlySeries(current, vehicle);
    const rows = corridorRows(current, previous, vehicle);
    // full catalogue (every corridor) so the ranking can offer excluded rows back
    const currentAll = filterRecords(RECORDS, {
      startISO: filters.startISO,
      endISO: filters.endISO,
      segmentIds: SEGMENTS.map((s) => s.id),
    });
    const previousAll = filterRecords(RECORDS, {
      startISO: prev.startISO,
      endISO: prev.endISO,
      segmentIds: SEGMENTS.map((s) => s.id),
    });
    const rowsAll = corridorRows(currentAll, previousAll, vehicle);

    // volume-weighted free-flow speed for the active selection
    let freeFlowW = 0;
    let volW = 0;
    const bySeg = new Map<string, number>();
    for (const r of current) {
      bySeg.set(r.segmentId, (bySeg.get(r.segmentId) ?? 0) + r.vehicles);
    }
    for (const [id, v] of bySeg) {
      const seg = SEGMENT_MAP[id];
      if (!seg) continue;
      freeFlowW += seg.freeFlow * v;
      volW += v;
    }
    const attainment = volW ? freeFlowW / volW : 1;

    const topOf = (from: number, to: number, count: number) =>
      hourly.waitBefore
        .slice(from, to)
        .map((v, i) => ({ v, i: i + from }))
        .sort((a, b) => b.v - a.v)
        .slice(0, count)
        .map((x) => x.i)
        .sort((a, b) => a - b);
    const amPeak = topOf(5, 12, 2);
    const pmPeak = topOf(14, 21, 3);
    const peakHours = [...amPeak, ...pmPeak];
    const peakRanges: [number, number][] =
      amPeak.length && pmPeak.length
        ? [
            [amPeak[0], amPeak[amPeak.length - 1]],
            [pmPeak[0], pmPeak[pmPeak.length - 1]],
          ]
        : [];
    const peakBefore = peakHours.reduce((a, h) => a + hourly.waitBefore[h], 0) / (peakHours.length || 1);
    const peakAfter = peakHours.reduce((a, h) => a + hourly.waitAfter[h], 0) / (peakHours.length || 1);

    const busiest = [...series].sort((a, b) => b.vehicles - a.vehicles)[0];

    return {
      days,
      current,
      previous,
      cur,
      before,
      series,
      hourly,
      rows,
      rowsAll,
      attainment,
      peakHours,
      peakRanges,
      peakBefore,
      peakAfter,
      busiest,
      prevWindow: prev,
    };
  }, [filters]);

  const {
    days,
    cur,
    before,
    series,
    hourly,
    rows,
    attainment,
    peakHours,
    peakRanges,
    peakBefore,
    peakAfter,
    busiest,
  } = data;

  const labels = series.map((d) => d.label);

  const kpis: KpiDef[] = [
    {
      key: "volume",
      label: "Vehicles managed",
      value: cur.vehicles,
      format: (n) => fmtCompact(n),
      delta: pct(before.vehicles, cur.vehicles),
      spark: series.map((d) => d.vehicles),
      color: "#6366f1",
      icon: Icon.cars,
      sub: (
        <>
          ≈ {fmtCompact(cur.vehicles / Math.max(1, days.length))}/day · peak {busiest?.label ?? "—"}
        </>
      ),
    },
    {
      key: "speed",
      label: "Avg network speed",
      value: cur.avgSpeed,
      format: (n) => `${n.toFixed(1)}`,
      delta: pct(before.avgSpeed, cur.avgSpeed),
      spark: series.map((d) => d.avgSpeed),
      color: "#22d3ee",
      icon: Icon.speed,
      sub: <>{(attainment * 100).toFixed(0)}% of free-flow target · {cur.avgSpeed > 0 ? `${fmtCompact((cur.vehicles * cur.travelTime) / 60)} veh-h on road` : "—"}</>,
    },
    {
      key: "delay",
      label: "Delay avoided",
      value: cur.delaySavedSec,
      format: (n) => `${n.toFixed(0)} s`,
      delta: pct(before.delaySavedSec, cur.delaySavedSec),
      spark: series.map((d) => d.delaySec),
      color: "#34d399",
      icon: Icon.clock,
      sub: <>{fmtCompact(cur.vehicleHoursSaved)} vehicle-hours handed back to drivers</>,
    },
    {
      key: "ai",
      label: "AI signal actions",
      value: cur.interventions,
      format: (n) => fmtCompact(n),
      delta: pct(before.interventions, cur.interventions),
      spark: series.map((d) => d.interventions),
      color: "#a855f7",
      icon: Icon.cpu,
      sub: <>{(cur.interventions / Math.max(1, days.length * filters.segmentIds.length)).toFixed(1)} per corridor/day · {cur.accuracy ? `${(cur.accuracy * 100).toFixed(1)}% model accuracy` : ""}</>,
    },
    {
      key: "incidents",
      label: "Incidents cleared",
      value: cur.resolved,
      format: (n) => fmtInt(n),
      delta: pct(before.resolved, cur.resolved),
      invert: false,
      spark: series.map((d) => d.incidents),
      color: "#fb7185",
      icon: Icon.alert,
      sub: <>{(cur.resolutionRate * 100).toFixed(0)}% clearance rate · {fmtInt(cur.incidents)} reported</>,
    },
    {
      key: "co2",
      label: "CO₂ avoided",
      value: cur.co2SavedKg / 1000,
      format: (n) => `${n.toFixed(1)} t`,
      delta: pct(before.co2SavedKg, cur.co2SavedKg),
      spark: series.map((d) => d.co2SavedKg),
      color: "#10b981",
      icon: Icon.leaf,
      sub: <>≈ {fmtCompact(cur.co2SavedKg / 4.6)} petrol-car days of emissions offset</>,
    },
  ];

  const congested = [...rows].sort((a, b) => b.congestion - a.congestion).slice(0, 4);
  const waitReduction = peakBefore ? ((peakBefore - peakAfter) / peakBefore) * 100 : 0;
  const donutData = VEHICLE_TYPES.map((v) => ({
    key: v.key,
    label: v.label,
    color: v.color,
    value: cur.mix[v.key] ?? 0,
  }));

  const healthScore = Math.max(
    0,
    Math.min(
      100,
      100 -
        cur.congestion * 0.75 +
        Math.min(1, cur.delaySavedSec / 300) * 15 +
        (cur.resolutionRate - 0.7) * 40,
    ),
  );

  const healthTone =
    healthScore > 72
      ? "text-emerald-600 dark:text-emerald-400"
      : healthScore > 55
        ? "text-amber-600 dark:text-amber-400"
        : "text-rose-600 dark:text-rose-400";

  return (
    <div className="min-h-screen bg-gradient-to-b from-slate-100 via-ink-50 to-slate-100 pb-14 dark:from-ink-950 dark:via-ink-950 dark:to-ink-900">
      {/* ambient glow */}
      <div className="pointer-events-none fixed inset-0 overflow-hidden">
        <div className="absolute -left-40 -top-40 h-[420px] w-[420px] rounded-full bg-indigo-400/15 blur-[120px] dark:bg-indigo-600/15" />
        <div className="absolute -right-32 top-40 h-[380px] w-[380px] rounded-full bg-cyan-300/15 blur-[120px] dark:bg-cyan-500/10" />
      </div>

      {/* header */}
      <header className="sticky top-0 z-40 border-b border-slate-200/70 bg-white/80 backdrop-blur-xl dark:border-white/[0.06] dark:bg-ink-950/80">
        <div className="mx-auto flex max-w-[1560px] items-center justify-between gap-4 px-4 py-3 sm:px-6">
          <div className="flex min-w-0 items-center gap-3">
            <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-gradient-to-br from-indigo-500 via-indigo-600 to-cyan-500 text-white shadow-lg shadow-indigo-500/25">
              <svg viewBox="0 0 24 24" className="h-5 w-5" fill="none" stroke="currentColor" strokeWidth={2} strokeLinecap="round" strokeLinejoin="round">
                <circle cx="6" cy="5" r="2" fill="currentColor" stroke="none" />
                <circle cx="6" cy="12" r="2" fill="currentColor" stroke="none" />
                <circle cx="6" cy="19" r="2" fill="currentColor" stroke="none" />
                <path d="M13 5h8M13 12h5M13 19h8M10 5h1M10 12h1M10 19h1" />
              </svg>
            </span>
            <div className="min-w-0">
              <h1 className="truncate text-[15px] font-bold tracking-tight text-slate-900 dark:text-white">
                FlowGrid <span className="font-medium text-slate-400 dark:text-slate-500">/ Traffic AI</span>
              </h1>
              <p className="truncate text-[11px] text-slate-500 dark:text-slate-400">
                Network control center · {filters.segmentIds.length} of {SEGMENTS.length} corridors ·{" "}
                {days.length} days
              </p>
            </div>
          </div>

          <nav className="hidden lg:flex">
            <Segmented
              options={[
                { key: "overview", label: "Analytics overview" },
                { key: "signals", label: "Signal management" },
              ]}
              value={view}
              onChange={(v) => setView(v)}
            />
          </nav>

          <div className="flex items-center gap-2 sm:gap-3">
            <LiveClock />
            <div className="hidden items-center gap-2.5 rounded-xl border border-slate-200 bg-white/70 px-3 py-1.5 md:flex dark:border-white/10 dark:bg-white/[0.04]">
              <span className="relative flex h-2 w-2">
                <span className="live-dot absolute h-full w-full rounded-full bg-emerald-400" />
                <span className="relative h-2 w-2 rounded-full bg-emerald-500" />
              </span>
              <span className="text-[11px] font-medium text-slate-500 dark:text-slate-400">
                Adaptive control{" "}
                <span className={`font-bold tnum ${healthTone}`}>{healthScore.toFixed(0)}/100</span>
              </span>
            </div>
            <button
              type="button"
              onClick={() => setVscodeGuideOpen(true)}
              title="How to run in VS Code"
              className="inline-flex items-center gap-1.5 rounded-xl border border-slate-200 bg-slate-100/80 px-2.5 py-1.5 text-[11px] font-semibold text-slate-700 transition-colors hover:border-indigo-300 hover:text-indigo-600 dark:border-white/10 dark:bg-white/[0.06] dark:text-slate-200 dark:hover:border-indigo-400/40 dark:hover:text-indigo-300"
            >
              <svg viewBox="0 0 24 24" className="h-3.5 w-3.5 text-indigo-500" fill="currentColor">
                <path d="M17.5 0h-9L7 1.5V6H2.5L1 7.5v9L2.5 18H7v4.5l1.5 1.5h9l1.5-1.5v-21L17.5 0ZM16 21H8.5v-3H16v3Zm0-6H8.5V9H16v6Zm0-9H8.5V3H16v3Z" />
              </svg>
              VS Code Run
            </button>
            <ThemeToggle dark={dark} onToggle={toggle} />
          </div>
        </div>
      </header>

      {/* VS Code Quick-Run Guide Modal */}
      {vscodeGuideOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 p-4 backdrop-blur-sm animate-fade">
          <div className="w-full max-w-lg rounded-2xl border border-slate-200 bg-white p-5 shadow-2xl dark:border-white/10 dark:bg-ink-900">
            <div className="flex items-center justify-between border-b border-slate-200/70 pb-3 dark:border-white/10">
              <div className="flex items-center gap-2.5">
                <span className="flex h-9 w-9 items-center justify-center rounded-xl bg-indigo-600 text-white shadow-md">
                  <svg viewBox="0 0 24 24" className="h-4 w-4" fill="currentColor">
                    <path d="M23.15 2.587L18.21.21a1.494 1.494 0 0 0-1.705.29l-9.46 8.63-4.12-3.128a.999.999 0 0 0-1.276.057L.327 7.261A1 1 0 0 0 .326 8.74L3.899 12 .326 15.26a1 1 0 0 0 .001 1.479L1.65 17.94a.999.999 0 0 0 1.276.057l4.12-3.128 9.46 8.63a1.492 1.492 0 0 0 1.704.29l4.942-2.377A1.5 1.5 0 0 0 24 20.06V3.939a1.5 1.5 0 0 0-.85-1.352zm-5.146 14.861L10.826 12l7.178-5.448v10.896z" />
                  </svg>
                </span>
                <div>
                  <h3 className="text-sm font-bold text-slate-900 dark:text-white">
                    Open &amp; Run in Visual Studio Code
                  </h3>
                  <p className="text-[11px] text-slate-500 dark:text-slate-400">
                    Full React + TypeScript project or Single-File HTML
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setVscodeGuideOpen(false)}
                className="rounded-lg p-1 text-slate-400 hover:bg-slate-100 dark:hover:bg-white/10"
              >
                ✕
              </button>
            </div>

            <div className="mt-4 space-y-3.5 text-xs">
              <div className="rounded-xl border border-indigo-200/80 bg-indigo-50/60 p-3 dark:border-indigo-400/20 dark:bg-indigo-500/10">
                <div className="font-bold text-indigo-900 dark:text-indigo-200">
                  Method 1 · Run Vite Dev Server in VS Code Terminal (Recommended)
                </div>
                <p className="mt-1 text-[11px] text-indigo-700/90 dark:text-indigo-300/80">
                  Open the folder in VS Code, press <code className="rounded bg-black/10 px-1 py-0.5 font-mono dark:bg-white/10">Ctrl + `</code> to open the Integrated Terminal, then run:
                </p>
                <div className="mt-2 flex items-center justify-between rounded-lg bg-slate-900 px-3 py-2 font-mono text-[11px] text-emerald-300">
                  <span>npm install &amp;&amp; npm run dev</span>
                  <button
                    type="button"
                    onClick={() => {
                      navigator.clipboard?.writeText("npm install && npm run dev");
                      setCopiedCmd(true);
                      setTimeout(() => setCopiedCmd(false), 2000);
                    }}
                    className="rounded bg-white/10 px-2 py-0.5 text-[10px] font-sans font-bold text-white hover:bg-white/20"
                  >
                    {copiedCmd ? "Copied ✓" : "Copy"}
                  </button>
                </div>
              </div>

              <div className="rounded-xl border border-slate-200 bg-slate-50 p-3 dark:border-white/10 dark:bg-white/[0.03]">
                <div className="font-bold text-slate-800 dark:text-slate-100">
                  Method 2 · Single Self-Contained HTML File (<code className="font-mono text-xs text-indigo-500">dist/index.html</code>)
                </div>
                <p className="mt-1 text-[11px] leading-relaxed text-slate-500 dark:text-slate-400">
                  Running <code className="rounded bg-slate-200/70 px-1 font-mono dark:bg-white/10">npm run build</code> generates <b className="text-slate-700 dark:text-slate-200">dist/index.html</b> with all CSS, React code, and SVG traffic visuals inlined into a single file via <code className="font-mono text-indigo-500">vite-plugin-singlefile</code>.
                </p>
                <ul className="mt-2 list-disc space-y-1 pl-4 text-[11px] text-slate-600 dark:text-slate-300">
                  <li>Right-click <code className="font-mono">dist/index.html</code> in VS Code → <b>Open with Live Server</b></li>
                  <li>Or double-click <code className="font-mono">dist/index.html</code> in your file explorer to open in Chrome/Edge/Safari offline</li>
                </ul>
              </div>

              <div className="rounded-xl border border-slate-200 bg-slate-50 p-3 dark:border-white/10 dark:bg-white/[0.03]">
                <div className="font-bold text-slate-800 dark:text-slate-100">
                  Entry File Open in VS Code
                </div>
                <p className="mt-1 text-[11px] text-slate-500 dark:text-slate-400">
                  Entry component: <code className="font-mono text-indigo-500">src/App.tsx</code> · Signal engine: <code className="font-mono text-indigo-500">src/data/signals.ts</code> · Analytics data: <code className="font-mono text-indigo-500">src/data/trafficData.ts</code>
                </p>
              </div>
            </div>

            <div className="mt-4 flex justify-end">
              <button
                type="button"
                onClick={() => setVscodeGuideOpen(false)}
                className="rounded-xl bg-indigo-600 px-4 py-1.5 text-xs font-bold text-white shadow hover:bg-indigo-500"
              >
                Got it
              </button>
            </div>
          </div>
        </div>
      )}

      <main className="relative mx-auto max-w-[1560px] space-y-4 px-4 pt-4 sm:px-6">
        <FilterBar
          state={filters}
          onChange={setFilters}
          onReset={() =>
            setFilters({ startISO: initial.startISO, endISO: initial.endISO, segmentIds: ALL_IDS, vehicle: "all" })
          }
        />

        {/* view switch (mobile) */}
        <nav className="flex justify-center lg:hidden">
          <Segmented
            options={[
              { key: "overview", label: "Analytics" },
              { key: "signals", label: "Signal control" },
            ]}
            value={view}
            onChange={(v) => setView(v)}
          />
        </nav>

        {view === "signals" ? (
          <SignalControl records={data.current} />
        ) : (
          <>
        {/* KPI grid */}
        <div className="grid grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-3 2xl:grid-cols-6">
          {kpis.map((k, i) => (
            <KpiCard key={k.key} kpi={k} delay={i * 55} />
          ))}
        </div>

        {/* row B */}
        <div className="grid grid-cols-1 gap-4 xl:grid-cols-3">
          <Panel className="xl:col-span-2">
            <PanelHeader
              title="Network throughput & flow efficiency"
              subtitle={`${fmtDateRange(filters.startISO, filters.endISO)} · volume-weighted across active corridors`}
              right={
                <div className="flex items-center gap-2">
                  <span className="hidden rounded-lg bg-slate-100 px-2 py-1 text-[10px] font-semibold text-slate-500 sm:inline dark:bg-white/[0.06] dark:text-slate-400">
                    {fmtCompact(cur.vehicles)} vehicles
                  </span>
                  <Delta value={pct(before.vehicles, cur.vehicles)} />
                </div>
              }
            />
            <div className="mt-4">
              <LineChart
                labels={labels}
                height={296}
                leftUnit="veh/day"
                rightUnit="km/h"
                leftFormat={(v) => fmtCompact(v)}
                rightFormat={(v) => v.toFixed(0)}
                series={[
                  {
                    key: "volume",
                    label: "Vehicles managed",
                    color: "#6366f1",
                    values: series.map((d) => d.vehicles),
                    format: (v) => `${fmtInt(v)} veh`,
                  },
                  {
                    key: "speed",
                    label: "Avg speed",
                    color: "#22d3ee",
                    values: series.map((d) => d.avgSpeed),
                    axis: "right",
                    kind: "line",
                    format: (v) => `${v.toFixed(1)} km/h`,
                  },
                ]}
              />
            </div>
          </Panel>

          <Panel>
            <PanelHeader
              title="Road-user mix"
              subtitle="Share of managed traffic volume"
              right={<span className="rounded-lg bg-slate-100 px-2 py-1 text-[10px] font-semibold text-slate-500 dark:bg-white/[0.06] dark:text-slate-400">{filters.vehicle === "all" ? "all users" : filters.vehicle}</span>}
            />
            <div className="mt-4">
              <DonutChart
                data={donutData}
                size={188}
                thickness={24}
                centerLabel="Total vehicles"
                valueFormat={(v) => fmtCompact(v)}
                subFormat={() => "in selected window"}
              />
            </div>
            <p className="mt-4 rounded-xl bg-indigo-50/70 px-3 py-2 text-[11px] leading-relaxed text-indigo-700 dark:bg-indigo-500/10 dark:text-indigo-200">
              Transit + micro-mobility carry{" "}
              <b className="tnum">
                {(((cur.mix.transit ?? 0) + (cur.mix.micro ?? 0)) / Math.max(1, cur.vehicles) * 100).toFixed(1)}%
              </b>{" "}
              of volume — AI priority phases moved{" "}
              <b className="tnum">{fmtCompact((cur.mix.transit ?? 0) * 0.18)}</b> transit passengers through
              signals with less dwell.
            </p>
          </Panel>
        </div>

        {/* row C */}
        <div className="grid grid-cols-1 gap-4 xl:grid-cols-3">
          <Panel className="xl:col-span-2">
            <PanelHeader
              title="Signal wait time · baseline vs AI-managed"
              subtitle="Average seconds of delay per vehicle by hour of day"
              right={
                <div className="flex items-center gap-2">
                  <span className="rounded-lg bg-emerald-50 px-2 py-1 text-[10px] font-bold text-emerald-700 dark:bg-emerald-500/10 dark:text-emerald-300 tnum">
                    −{waitReduction.toFixed(1)}% peak wait
                  </span>
                  <Delta value={pct(before.delaySavedSec, cur.delaySavedSec)} />
                </div>
              }
            />
            <div className="mt-4">
              <BarChart
                labels={Array.from({ length: 24 }, (_, h) => `${String(h).padStart(2, "0")}:00`)}
                height={272}
                unit="sec"
                peakRanges={peakRanges}
                valueFormat={(v) => `${v.toFixed(1)} s`}
                axisFormat={(v) => v.toFixed(0)}
                series={[
                  {
                    key: "before",
                    label: "Pre-AI baseline",
                    color: "#94a3b8",
                    values: hourly.waitBefore,
                  },
                  {
                    key: "after",
                    label: "AI-managed",
                    color: "#6366f1",
                    values: hourly.waitAfter,
                  },
                ]}
              />
            </div>
          </Panel>

          <Panel>
            <PanelHeader
              title="Corridor impact ranking"
              subtitle="Click a row to filter the dashboard"
            />
            <div className="mt-4">
              <CorridorRanking
                rows={rows}
                allRows={data.rowsAll}
                activeIds={filters.segmentIds}
                onToggle={(id) => {
                  const has = filters.segmentIds.includes(id);
                  const next = has ? filters.segmentIds.filter((s) => s !== id) : [...filters.segmentIds, id];
                  if (next.length) patch({ segmentIds: next });
                }}
              />
            </div>
          </Panel>
        </div>

        {/* row D */}
        <div className="grid grid-cols-1 gap-4 xl:grid-cols-3">
          <Panel className="xl:col-span-2">
            <PanelHeader
              title="Congestion index by corridor"
              subtitle="Highest-load corridors vs network average (0–100)"
              right={
                <span className="rounded-lg bg-slate-100 px-2 py-1 text-[10px] font-semibold text-slate-500 dark:bg-white/[0.06] dark:text-slate-400 tnum">
                  network {cur.congestion.toFixed(0)}
                </span>
              }
            />
            <div className="mt-4">
              <LineChart
                labels={labels}
                height={264}
                leftFormat={(v) => v.toFixed(0)}
                series={[
                  ...congested.map((r, i) => ({
                    key: r.id,
                    label: r.short,
                    color: CORRIDOR_PALETTE[i % CORRIDOR_PALETTE.length],
                    values: (() => {
                      const buckets = new Map<string, { c: number; v: number }>();
                      for (const rec of data.current) {
                        if (rec.segmentId !== r.id) continue;
                        const b = buckets.get(rec.dateISO) ?? { c: 0, v: 0 };
                        b.c += rec.congestion * rec.vehicles;
                        b.v += rec.vehicles;
                        buckets.set(rec.dateISO, b);
                      }
                      return series.map((d) => {
                        const b = buckets.get(d.dateISO);
                        return b && b.v ? b.c / b.v : 0;
                      });
                    })(),
                    kind: "line" as const,
                    format: (v: number) => `${v.toFixed(1)} idx`,
                  })),
                  {
                    key: "avg",
                    label: "Network average",
                    color: "#94a3b8",
                    values: series.map((d) => d.congestion),
                    kind: "line" as const,
                    dashed: true,
                    format: (v: number) => `${v.toFixed(1)} idx`,
                  },
                ]}
              />
            </div>
          </Panel>

          <Panel className="flex flex-col">
            <PanelHeader title="AI control plane" subtitle="Model quality & live decisions" />
            <div className="mt-4 flex-1">
              <AiControlPlane
                accuracy={cur.accuracy}
                resolutionRate={cur.resolutionRate}
                delaySavedSec={cur.delaySavedSec}
                interventions={cur.interventions}
                corridors={rows}
                dayCount={Math.max(1, days.length)}
              />
            </div>
          </Panel>
        </div>

        {/* heatmap */}
        <Panel>
          <PanelHeader
            title="Weekly congestion surface"
            subtitle="Where and when the network slows — aggregated across active corridors"
            right={
              <div className="flex flex-wrap items-center gap-2">
                {peakHours.map((h) => (
                  <span key={h} className="chip border-amber-200 bg-amber-50 text-amber-700 dark:border-amber-400/25 dark:bg-amber-400/10 dark:text-amber-200">
                    peak {String(h).padStart(2, "0")}:00
                  </span>
                ))}
              </div>
            }
          />
          <div className="mt-4">
            <CongestionHeatmap records={data.current} />
          </div>
        </Panel>

        {/* table */}
        <Panel>
          <PanelHeader
            title="Corridor performance ledger"
            subtitle={`${rows.length} corridors · compared with ${fmtDateRange(data.prevWindow.startISO, data.prevWindow.endISO)}`}
            right={
              <span className="hidden rounded-lg bg-slate-100 px-2 py-1 text-[10px] font-semibold text-slate-500 sm:inline dark:bg-white/[0.06] dark:text-slate-400">
                click any header to sort
              </span>
            }
          />
          <div className="mt-4">
            <DataTable rows={rows} />
          </div>
        </Panel>

          </>
        )}

        <footer className="flex flex-wrap items-center justify-between gap-2 px-1 pt-2 text-[11px] text-slate-400 dark:text-slate-500">
          <span>
            FlowGrid analytics · {fmtInt(RECORDS.length)} synthetic telemetry records ·{" "}
            {DAY_META.length}-day horizon · generated in-browser, no network calls
          </span>
          <span className="tnum">
            {fmtPct(pct(before.vehicles, cur.vehicles))} volume vs previous period · streaming healthy
          </span>
        </footer>
      </main>
    </div>
  );
}
